%% Controller synthesis for the reachability specification on the ship model
% With additional safety conditions of staying in the bounded state space
% and unsafe/obstacle sets within the state space.

% The obstacle avoidance is fully handled by skipping obstacle symbols in
% the loop of symbols to explore, thus ensuring that no obstacle symbol is
% ever added to the expanded list of target symbols.
% HUSSEIN: adding X_low and X_up as parameters since the successor in
% Symbolic_reduced is now an interval and the output of find_frame is an
% (list of?) interval instead of a list of symbols. Same goes for targets 
% and obstacles. They have to be changed from intervals to symbols. The
% same goes to targets and obstacles.
function Controller = Reach_avoid_synthesis_sets(Symbolic_reduced,unsafe_trans,sym_x,sym_u,state_dimensions,Target_low,Target_up,Obstacle_low,Obstacle_up, X_low, X_up, U_low, U_up)


tic
n = numel(state_dimensions);
matrix_dim_full = [prod(sym_x),prod(sym_u),2*n];
sym_x_reduced = sym_x.*state_dimensions' + ~state_dimensions';
if range(sym_u)==0
    sym_u = sym_u(1);
    ui_values = 1:sym_u;
    U_discrete = Gray(ui_values,size(U_low,1),sym_u);
    U_discrete = repmat(U_low,1,sym_u^size(U_low,1)) + (U_discrete-1).*repmat((U_up-U_low)/(sym_u-1),1,sym_u^size(U_low,1));
else
    error('Non-homogeneous input discretization cannot be handled yet')
end
matrix_dim_reduced = [prod(sym_x_reduced),size(U_discrete,2),2*n];

% HUSSEIN: since in the new implementation we go backwards by finding the
% set of frames that will make the transformed version of the successor of 
% a symbol in the reduced coordinates belong to the target, that set of
% frames will be a new target set of states (after excluding obstacles) for
% the following synthesis iterations.
% Since target is updated in the loop, parallel execution of the code might
% be affected. This has to be rethought.
% targets = [Target_low Target_up];
% Target_low = [Target_low];
% Target_up  = [Target_up];
symbol_step = (X_up-X_low)./sym_x;

% HUSSEIN: pasting these two blocks of code from Ship_main.m. Commenting
% the targets again, since we do not need the discretized values (or symbols
% of the targets, in contrast with the previous implementation.
%% Target symbol indices
% % Target_low = ceil(1+(Target_low-X_low)./symbol_step);
% % Target_up = floor((Target_up-X_low)./symbol_step);

% Convert obstacle interval to the set of symbols it intersects
Obstacle_low_ind = zeros(size(Obstacle_low));
Obstacle_up_ind = zeros(size(Obstacle_up));
% Hussein: subtracting and adding symbol_step to compensate for the change
% in Ship_main
for i=1:size(Obstacle_up,2)
    Obstacle_low_ind(:,i) = floor(1+(Obstacle_low(:,i) -X_low)./symbol_step);
    Obstacle_up_ind(:,i) = ceil(1 + (Obstacle_up(:,i) -X_low)./symbol_step);
end

% Extract subscripts (on each dimension) for the corresponding target symbols
% % Target_width = Target_up - Target_low + ones(n,1);
% % target_subscripts = cell(n,1);
% % [target_subscripts{:}] = ind2sub(Target_width',1:prod(Target_width));
% % target_subscripts = cell2mat(target_subscripts);
% % target_subscripts = bsxfun(@plus, target_subscripts, Target_low-ones(n,1));

% Convert 3D subscripts into 1D indices
% % target_indices = sub2ind(sym_x',target_subscripts(1,:),target_subscripts(2,:),target_subscripts(3,:));

%% Obstacle symbol indices

obstacle_indices = [];
for i=1:size(Obstacle_up,2)
    % Extract subscripts (on each dimension) for the corresponding obstacles symbols
    Obstacle_width = Obstacle_up_ind(:,i) - Obstacle_low_ind(:,i); %  + ones(n,1)
    obstacle_subscripts = cell(n,1);
    [obstacle_subscripts{:}] = ind2sub(Obstacle_width',1:prod(Obstacle_width));
    obstacle_subscripts = cell2mat(obstacle_subscripts);
    obstacle_subscripts = bsxfun(@plus, obstacle_subscripts, Obstacle_low_ind(:,i)-ones(n,1));
    
    % Convert 3D subscripts into 1D indices
    obstacle_indices = [obstacle_indices sub2ind(sym_x',obstacle_subscripts(1,:),obstacle_subscripts(2,:),obstacle_subscripts(3,:))];
end

%% Main synthesis loop

% Initialization of the controller (0 = not controllable or in target)
Controller = zeros(matrix_dim_full(1),1);

Covering = {}; % containers.Map(zeros(matrix_dim_full(1),1), []*matrix_dim_full(1));

Target_low_ind = ceil(1+(Target_low-X_low)./(symbol_step)); % [1,1,1.5]' .* 
Target_up_ind = floor((Target_up-X_low)./(symbol_step)); % [1,1,1.5]' .* 
Target_width = Target_up_ind - Target_low_ind + ones(n,1);

iterations_before_break = 0;

targets = [];
% for i = 1:Target_width(3)
%     targets = cat(3, targets, [[Target_low(1),Target_low(2), ...
%         Target_low(3) + 1.5 * symbol_step(3) * (i-1)];[Target_up(1),Target_up(2), ...
%         Target_low(3) + 1.5 * symbol_step(3) * i]]);
% end

% Hussein: TODO: remove the other redundant target
targets = [[Target_low'; Target_up'];[Target_low'; Target_up']];

% Loop for the reachability synthesis
fprintf('\n%s\tStart of the control synthesis\n',num2str(datestr(now)))
targets_temp = [];
points = [];
for k = 1:size(targets,3)
    points = cat(1,points, rectangle_to_vertices(targets(:,:,k)));
end
shp = alphaShape(points(:,1),points(:,2),points(:,3));
while 1
    % Loop on all symbols to explore (not an obstacle, and not yet in the (expanded) target set)
    % TODO: HUSSEIN: here is a bottleneck, iteration over all symbols 
    % in the global model, it should be only over the reduced/abstract one. 
    % I'm commenting the next couple of lines to loop only over symbols of
    % the reduced model.
    % symbols_to_explore = setdiff(1:matrix_dim_full(1),target_indices);
    % symbols_to_explore = setdiff(symbols_to_explore,obstacle_indices);
    % symbols_to_explore = 1:matrix_dim_reduced(1);
    % Controller_temp = zeros(numel(symbols_to_explore),1);
    % HUSSEIN: initializing the targets_temp and Controller_temp at each
    % iteration
    targets_temp = []; % Combine_rects(targets_temp);
    % 'Size of target indices'
    % size(target_indices)
    % Controller_temp = [];
    progress_indicator = 0;
    partial_progress_indicator = 0;
    partially_covered_indices_set = [];

    'targets size'
    size(targets)
    points = [];%  shp.Points;
    for k = 1:size(targets,3)
        points = cat(1,points, rectangle_to_vertices(targets(:,:,k)));
    end
    shp = alphaShape(points(:,1),points(:,2),points(:,3));
    n_regions = numRegions(shp);
    targets = [];
    for reg_ind = 1:n_regions
        tri = alphaTriangulation(shp,reg_ind);
        idx = unique(tri(:));
        reg_points = shp.Points(idx,:);
        % convhulln(reg_points);
        % cvx_hulls = cat(1,cvx_hulls,convhulln(reg_points));
        targets = cat(3,targets,get_bounding_box(reg_points));
    end
    % parfor
    for s_ind = 1:matrix_dim_reduced(1) % numel(symbols_to_explore)
%     for s_ind = 1:numel(symbols_to_explore)
        % s = symbols_to_explore(s_ind);
        % Loop on the control inputs
        for u = 1:matrix_dim_reduced(2) %matrix_dim_full(2)
            % u = U_discrete(:,k);
            % Convert 1D s index to 3D subscript
            % [s1,s2,s3] = ind2sub(sym_x',s);
            % s_subscript = [s1;s2;s3];

            % Get corresponding 1D index in the reduced model
            % HUSSEIN: have to change the following to get 1D index in the
            % generalized model. Actually, the index is already for the
            % reduced model, so we will comment this line since it was
            % transforming the index in the original model to the reduced
            % one.
            % s_reduced_ind = 1+(s-s_subscript(1)-(s_subscript(2)-1)*sym_x(1))/(sym_x(1)*sym_x(2));
            
            % Discard pair (s,u) if it leads outside of the state space
            % on the states in state_dimensions
            % HUSSEIN
            % I commented the following if-condition since as in the
            % centralized_abstraction.m file, the angle is now reduced
            % with the model.
            % if unsafe_trans(s_reduced_ind,u)
            %    continue
            % end

            % Get successor interval in the global model
            % HUSSEIN: I will comment the next couple of lines since we
            % will go backwards in our synthesis
            % We will get the successor interval for the current symbol in
            % the reduced system. Then, we will get the state in the global
            % model such that the succ_up is aligned with the up of the
            % target. Similarly 
            % succ_low = shiftdim(Symbolic_reduced(s_reduced_ind,u,1:n),2) + (s_subscript-1).*(~state_dimensions');
            % succ_up = shiftdim(Symbolic_reduced(s_reduced_ind,u,n+1:end),2) + (s_subscript-1).*(~state_dimensions');
            % targets_size = size(targets);

            for target_ind = 1:size(targets,3) % target_indices % targets_size(1)
                % % s = target_indices(target_ind);
                % % [s1,s2,s3] = ind2sub(sym_x',s);
                % s_subscript = [s1;s2;s3];
                Target_low = targets(1, :, target_ind); % X_low'+symbol_step'.*([s1,s2,s3]-1);
                Target_up = targets(2, :, target_ind);  % X_low'+symbol_step'.*[s1,s2,s3];
                % Target_low =  % targets(target_ind,1:n);
                % Target_up = % targets(target_ind,n+1:end);
                % [curr_low,curr_up] =
                rects_curr = find_frame(Symbolic_reduced(s_ind,u,1:n), Symbolic_reduced(s_ind,u,n+1:end), Target_low, Target_up, symbol_step);
                itr = 1;
                threshold = 1;
                % candidate_indices = [];
                % if ~any(isnan(curr_low))
                    % candidate_indices = Range_to_indices(curr_low, curr_up, symbol_step, X_low, X_up, sym_x, n, 1);
                % end
                % Hussein: having curr_low = NaN might happen because the
                % target is too small. In the following block of code, we
                % check if it can be enlarged.
%                 if any(isnan(curr_low))
%                     'iteration begin'
%                     itr
%                     Target_low
%                     Target_up
%                 end
                succ = 0;
                
                while  itr <= threshold && any(any(any(isnan(rects_curr)))) % || any(rect_curr - curr_low < 2 * symbol_step))
                      
%                     if ~any(isnan(curr_low))
%                         candidate_indices = Range_to_indices( ...
%                                 curr_low, curr_up, ...
%                                 symbol_step, X_low, X_up, sym_x, n, 0);
%                         if all(Controller(candidate_indices) ~=0)
%                             break
%                         end
%                     end
%                     'before enlarging'
%                     Target_low
%                     Target_up
%                     curr_low
%                     curr_up
%                     if ~any(isnan(curr_low)) && 
% 
%                     else
                     % if any(isnan(curr_low)) && any(curr_up - curr_low < symbol_step)
%                         for pos = 1:-1:0
%                             [Target_low, Target_up, succ_temp] = Enlarge_target(Target_low, Target_up, Controller, symbol_step, 3, pos, X_up, X_low,sym_x, n);
%                             if succ_temp
%                                 succ = 1;
%                             end
%                         end
                    % elseif any(curr_up - curr_low < symbol_step)
                        for pos = 1:-1:0
                            for dim = 1:1:3 % if any(isnan(curr_low))
                                % [Target_low, Target_up, succ_temp] = Enlarge_target(Target_low, Target_up, Controller, symbol_step, dim, pos, X_up, X_low,sym_x, n, targets_temp);
                                
                                [Target_low, Target_up, succ_temp] = Enlarge_target(Target_low, Target_up, symbol_step, dim, pos, X_up, X_low, sym_x, n, shp);
                                
                                if succ_temp
                                    succ = 1;
                                end
                                % else
                                
    %                             [Target_low, Target_up, succ] = Enlarge_target(Target_low, Target_up, Controller, symbol_step, dim, pos, X_up, X_low,sym_x, n);
    %                             if succ
    %                                 [curr_low,curr_up] = find_frame(Symbolic_reduced(s_ind,u,1:n), Symbolic_reduced(s_ind,u,n+1:end), Target_low, Target_up);
    %                             end
    %                             if succ && ~any(isnan(curr_low)) % && all(curr_up - curr_low >= symbol_step)
    %                                 break
    %                             end
                               % end
                            end
    %                         if succ && ~any(isnan(curr_low)) % && all(curr_up - curr_low >= symbol_step)
    %                             break
    %                         end
                        end
                     % end
%                      if ~any(isnan(curr_low)) && all(Symbolic_reduced(s_ind,u,n+1:end) - Symbolic_reduced(s_ind,u,1:n) <= 2 * (Target_up(3) - Target_low(3))) % (curr_up(3) - curr_low(3) >= 2 * symbol_step(3))
%                         Target_up_temp = Target_up;
%                         Target_up_temp(3) = (Target_low(3) + Target_up(3))/2;
%                         targets_temp = cat(3, targets_temp, [Target_low;Target_up_temp]);
%                         Target_low(3) = Target_up_temp(3);
%                      end
                    if succ
                       % [curr_low,curr_up] = 
                       rects_curr = find_frame(Symbolic_reduced(s_ind,u,1:n), Symbolic_reduced(s_ind,u,n+1:end), Target_low, Target_up, symbol_step);
                    end
%                     if succ
%                         'after enlarging'
%                         Target_low
%                         Target_up
%                         curr_low
%                         curr_up
%                     end
                    itr = itr + 1;
                end
                
                if ~isnan(rects_curr)% curr_low)
                    % targets_temp = [targets_temp; [curr_low curr_up]];
                    % HUSSEIN: these were copy-pasted from below, but they
                    % assume that the Symbolic_reduced store the symbols
                    % not intervals. That has to be fixed. Bringing the
                    % following statement (adjusted to be curr instead of
                    % succ) from Centralized_abstraction.m
                    for rect_ind = 1:size(rects_curr,3)
                        rect_curr = rects_curr(:,:,rect_ind);
                        curr_low = max(rect_curr(1,:)', X_low); % max(curr_low, X_low); % making sure curr is in X
                        curr_low = min(curr_low, X_up);
                        curr_up = min(rect_curr(2,:)', X_up);
                        curr_up = max(curr_up, X_low);
                        rect_curr = [curr_low'; curr_up'];
                        rect_i = [];
                        i = 1;
                        while i <= size(Obstacle_up,2) && ~isempty(rect_curr)
                            rect_obs = [Obstacle_low(:,i)'; Obstacle_up(:,i)'];
                            rect_c = [];
                            for j=1:size(rect_curr,3)
                                % Hussein: TODO: here we need to check if
                                % the reachable sets intersect the
                                % unsafe sets as well.
                                if Do_rects_inter(rect_curr(:,:,j), rect_obs)
                                    [rect_c_temp, rect_i] = Get_rects_inter(rect_curr(:,:,j), rect_obs);
                                    if ~isempty(rect_c_temp)
                                        rect_c = cat(3, rect_c, rect_c_temp);
                                    end
                                else
                                    rect_c = cat(3, rect_c, rect_curr(:,:,j));
                                end
                            end
                            rect_curr = rect_c;
                            i = i + 1;
                        end
               
                    
                        rect_curr_not_useful_indices = [];
                        if ~isempty(rect_curr) % length(size(rect_curr)) > 2 &&
                            for j=1:size(rect_curr,3)
                                useful = 0;
%                                 [candidate_indices, partially_covered_indices, rect_curr_j_low_temp, rect_curr_j_up_temp] = Range_to_indices( ...
%                                     rect_curr(1,:,j), rect_curr(2,:,j), ...
%                                     symbol_step, X_low, X_up, sym_x, n, 1);
                                rect_low = rect_curr(1,:,j);
                                rect_up = rect_curr(2,:,j);
                                [subscripts] = Range_to_subscripts(rect_low, rect_up, symbol_step, X_low, X_up, sym_x, n);
%                                 if ~isempty(candidate_indices)
%                                     rect_curr(1,:,j) = rect_curr_j_low_temp;
%                                     rect_curr(2,:,j) = rect_curr_j_up_temp;
%                                 end
    %                             candidate_indices_temp = setdiff(candidate_indices, obstacle_indices);
    %                             if length(candidate_indices) ~= length(candidate_indices_temp)
    %                                 % 'curr includes obstacles!'
    %                                 rect_obs = [Obstacle_low(:,1)'; Obstacle_up(:,1)'];
    %                                 rects_intersect = Do_rects_inter(rect_curr(:,:,j), rect_obs);
    %                                 if rects_intersect
    %                                     Target_low_temp
    %                                     Target_up_temp
    %                                     Obstacle_up
    %                                     Obstacle_low
    %                                     [rect_c, rect_i] = Get_rects_inter(rect_curr(:,:,j), rect_obs)
    %                                 end
    %                                 rect_obs = [Obstacle_low(:,2)'; Obstacle_up(:,2)'];
    %                                 rects_intersect = Do_rects_inter(rect_curr(:,:,j), rect_obs);
    %                                 if rects_intersect
    %                                     Target_low_temp
    %                                     Target_up_temp
    %                                     Obstacle_up
    %                                     Obstacle_low
    %                                     [rect_c, rect_i] = Get_rects_inter(rect_curr(:,:,j), rect_obs)
    %                                 end
    %                             end
%                                 for k = 1:length(partially_covered_indices)
%                                     if size(Covering,2) < partially_covered_indices(k)
%                                         Covering(partially_covered_indices(k)).rectangles = rect_curr(:,:,j);
%                                     else
%                                         Covering(partially_covered_indices(k)).rectangles = cat(3, Covering(partially_covered_indices(k)).rectangles, rect_curr(:,:,j));
%                                     end
%                                 end
                                
                                for k = 1:size(subscripts,2)
                                    cell_rect_low = (subscripts(:,k) - 1) .* symbol_step + X_low;
                                    cell_rect_up = subscripts(:,k) .* symbol_step + X_low;
                                    index = sub2ind(sym_x',subscripts(1,k),subscripts(2,k), subscripts(3,k));
                                    if all(cell_rect_low' >= rect_low) && all(cell_rect_up' <= rect_up)
                                        if Controller(index) == 0 || Controller(index) == 999
                                            Controller(index) = u;
                                            progress_indicator = progress_indicator + 1;
                                            useful = 1;
                                        end
                                    else
                                        if Controller(index) == 0 
                                            Controller(index) = 999;
                                            partial_progress_indicator = partial_progress_indicator + 1;
                                            useful = 1;
                                        end
                                    end
                                end
%                                 for k = 1:length(candidate_indices)
%                                     if Controller(candidate_indices(k)) == 0 ||  Controller(candidate_indices(k)) == 999
%                                         % curr_indices_temp = [curr_indices_temp candidate_indices(k)];
%                                         Controller(candidate_indices(k)) = u;
%                                         % curr_indices = [curr_indices candidate_indices(k)];
%                                         progress_indicator = progress_indicator + 1;
%                                         useful = 1;
%                                     end
%                                 end
%                                 for k = 1:length(partially_covered_indices)
%                                     if Controller(partially_covered_indices(k)) == 0
%                                         curr_indices_temp = [curr_indices_temp candidate_indices(k)];
%                                         Controller(partially_covered_indices(k)) = 999;
%                                         curr_indices = [curr_indices candidate_indices(k)];
%                                         partial_progress_indicator = partial_progress_indicator + 1;
%                                         useful = 1;
%                                     end
%                                 end
                                
%                                 if ~useful
%                                     partially_covered_indices = setdiff(partially_covered_indices, partially_covered_indices_set); 
%                                     if any(Controller(partially_covered_indices)==0)
%                                         useful = 1;
%                                         partially_covered_indices_set = [partially_covered_indices_set partially_covered_indices];
%                                     end
%                                 end
                                if useful == 0
                                    rect_curr_not_useful_indices = [rect_curr_not_useful_indices j];
    %                             else
    %                                 for pos = 1:-1:0
    %                                     for dim = 1:1:3 % if any(isnan(curr_low))
    %                                         [rect_curr(1,:,j), rect_curr(2,:,j), succ_temp] = Enlarge_target(rect_curr(1,:,j), rect_curr(2,:,j), Controller, symbol_step, dim, pos, X_up, X_low,sym_x, n, targets_temp);
    %                                     end
    %                                 end
    %                             else 
    %                                 extension_indices = Range_to_indices( ...
    %                                     rect_curr(2,:,j), rect_curr(2,:,j) ...
    %                                     + [0 , 0, 2 * symbol_step(3)], ...
    %                                     symbol_step, X_low, X_up, sym_x, n);
    %                                 itr = 2;
    %                                 if ~isempty(extension_indices) && all(Controller(extension_indices) ~= 0)
    %                                     rect_curr(2,:,j) = rect_curr(2,:,j) + [0 , 0, 2 * symbol_step(3)];
    %                                     extension_indices = Range_to_indices( ...
    %                                         rect_curr(2,:,j) + [0 , 0, ...
    %                                         itr * symbol_step(3)], rect_curr(2,:,j) ...
    %                                         + [0 , 0, symbol_step(3)], ...
    %                                         symbol_step, X_low, X_up, sym_x, n);
    %                                     itr = itr + 1;
    %                                 end
                                end
                            end
    %                     elseif ~isempty(rect_curr)
    %                         useful = 0;
    % %                         for i = 1:size(Obstacle_up,2)
    % %                             if Do_rects_inter(rect_curr, [Obstacle_low(:,i)'; Obstacle_up(:,i)'])
    % %                                 rect_curr
    % %                                 Obstacle_low(:,i)'
    % %                                 Obstacle_up(:,i)'
    % %                                 'Attention!! intersecting obstacle 2'
    % %                             end
    % %                         end
    %                         [candidate_indices, rect_curr_low_temp, rect_curr_up_temp] = Range_to_indices( ...
    %                                 rect_curr(1,:), rect_curr(2,:), ...
    %                                 symbol_step, X_low, X_up, sym_x, n, 1);
    %                         if ~isempty(candidate_indices)
    %                             rect_curr(1,:) = rect_curr_low_temp;
    %                             rect_curr(2,:) = rect_curr_up_temp;
    %                         end
    % %                         candidate_indices_temp = setdiff(candidate_indices, obstacle_indices);
    % %                         if length(candidate_indices) ~= length(candidate_indices_temp)
    % %                             % 'curr includes obstacles!'
    % %                             rect_obs = [Obstacle_low(:,1)'; Obstacle_up(:,1)'];
    % %                             rects_intersect = Do_rects_inter(rect_curr, rect_obs);
    % %                             if rects_intersect
    % %                                 Target_low_temp
    % %                                 Target_up_temp
    % %                                 Obstacle_up
    % %                                 Obstacle_low
    % %                                 [rect_c, rect_i] = Get_rects_inter(rect_curr, rect_obs)
    % %                             end
    % %                             rect_obs = [Obstacle_low(:,2)'; Obstacle_up(:,2)'];
    % %                             rects_intersect = Do_rects_inter(rect_curr, rect_obs);
    % %                             if rects_intersect
    % %                                 Target_low_temp
    % %                                 Target_up_temp
    % %                                 Obstacle_up
    % %                                 Obstacle_low
    % %                                 [rect_c, rect_i] = Get_rects_inter(rect_curr, rect_obs)
    % %                             end
    % %                         end
    %                         for k = 1:length(candidate_indices)
    %                             if Controller(candidate_indices(k)) == 0
    %                                 % curr_indices_temp = [curr_indices_temp candidate_indices(k)];
    %                                 Controller(candidate_indices(k)) = u;
    %                                 % curr_indices = [curr_indices candidate_indices(k)];
    %                                 progress_indicator = progress_indicator + 1;
    %                                 useful = 1;
    %                             end
    %                         end
    %                         if useful == 0
    %                             % rect_curr_not_useful_indices = [rect_curr_not_useful_indices j];
    %                             rect_curr = [];
    % %                         else
    % %                             for pos = 1:-1:0
    % %                                 for dim = 1:1:3 % if any(isnan(curr_low))
    % %                                     [rect_curr(1,:), rect_curr(2,:), succ_temp] = Enlarge_target(rect_curr(1,:), rect_curr(2,:), Controller, symbol_step, dim, pos, X_up, X_low,sym_x, n, targets_temp);
    % %                                 end
    % %                             end
    % %                         else
    % %                             extension_indices = Range_to_indices( ...
    % %                                 rect_curr(2,:), rect_curr(2,:) ...
    % %                                 + [0 , 0, 2 * symbol_step(3)], ...
    % %                                 symbol_step, X_low, X_up, sym_x, n);
    % %                             itr = 2;
    % %                             if ~isempty(extension_indices) && all(Controller(extension_indices) > 0)
    % %                                 rect_curr(2,:) = rect_curr(2,:) + [0 , 0, 2 * symbol_step(3)];
    % %                                 extension_indices = Range_to_indices( ...
    % %                                     rect_curr(2,:), rect_curr(2,:) ...
    % %                                     + [0 , 0, symbol_step(3)], ...
    % %                                     symbol_step, X_low, X_up, sym_x, n);
    % %                                 itr = itr + 1;
    % %                             end
    %                             
    %                         end
                        end
                        
                        % getting the symbols => this can be more improved
                        % later to not consider symbols at all.
    %                     curr_low = ceil((curr_low - X_low) ./ symbol_step);
    %                     curr_up = ceil((curr_up - X_low) ./ symbol_step);
    %                     % [curr_low;curr_up] = ceil(([curr_low;curr_up]-[X_low;X_low])./[symbol_step;symbol_step])
    %                     curr_width = curr_up - curr_low + ones(n,1); 
    %                     curr_subscripts = cell(n,1); 
    %                     [curr_subscripts{:}] = ind2sub(curr_width',1:prod(curr_width));
    %                     curr_subscripts = cell2mat(curr_subscripts);
    %                     curr_subscripts = bsxfun(@plus, curr_subscripts, curr_low - ones(n,1)); %  
    %                     % transforming the subscripts to indices
    %                     % 'before_sub2ind'
    %                     % curr_subscripts(1,:)
    %                     % curr_subscripts(2,:)
    %                     % curr_subscripts(3,:)
    %                     for i = 1:size(curr_subscripts,1)
    %                         for j = 1:size(curr_subscripts,2)
    %                             if curr_subscripts(i,j) < 1
    %                                 curr_subscripts(i,j) = 1;
    %                             elseif curr_subscripts(i,j) > sym_x(i)
    %                                 curr_subscripts(i,j) = sym_x(i);
    %                             end
    %                         end
    %                     end
    %                     curr_indices_temp = sub2ind(sym_x',curr_subscripts(1,:),curr_subscripts(2,:),curr_subscripts(3,:));
                        % 'length_curr_indices'
                        % length(curr_indices)
                        % 'after_sub2ind'
                        % removing the indices that correspond to obstacles.
                        % curr_indices_temp = setdiff(curr_indices_temp, obstacle_indices);
    %                     curr_indices = [];
                        %'length of curr_indices_temp'
                        %length(curr_indices_temp)
    %                     for curr_index_ind = 1:length(curr_indices_temp)
    %                         curr_index_temp = curr_indices_temp(curr_index_ind);
    %                         % if not(ismember(curr_index)) % all(ismember(succ_indices,target_indices))
    %                         % Add current control to controller
    %                         % HUSSEIN: commenting the following line and adding
    %                         % an edited one
    %                         % Controller_temp(s_ind) = u;
    %                         if Controller(curr_index_temp) == 0
    %                             Controller(curr_index_temp) = u;
    %                             curr_indices = [curr_indices curr_index_temp];
    %                             progress_indicator = progress_indicator + 1;
    %                             % Controller_temp = [Controller_temp; [curr_index u]];
    %                         end
    %                         % Controller(s) = u;
    %                         % HUSSEIN: DON'T Stop looking at other control
    %                         % inputs since they might reveal other controllable
    %                         % states => commenting the break
    %                         % break
    %                         % end
    %                     end
                        % targets_temp = [targets_temp curr_indices];
                        % targets_temp = setdiff(targets_temp, target_indices);
                        % 'length(rect_curr_not_useful_indices)'
                        % length(rect_curr_not_useful_indices)
                        if  ~isempty(rect_curr) % length(size(rect_curr)) > 2 &&
                            rect_curr(:,:,rect_curr_not_useful_indices) = [];
                        end
                        if ~isempty(rect_curr)
                            targets_temp = cat(3, targets_temp, rect_curr);
                        end
                    end

                end
            end
            % Discard pair (s,u) if it leads outside of the state space
            % on the states NOT in state_dimensions
            % TODO: HUSSEIN: commenting the following if-condition since
            % the frame is defined so that the successor is in target.
            % if any(succ_low(~state_dimensions)<1 | succ_up(~state_dimensions)>sym_x(~state_dimensions))
            %    continue
            % end
            
            % HUSSEIN: commenting this code block and moving a modified
            % version of it up to get the symbols of the current set of
            % states instead of the successor.
            % Extract subscripts for the covered symbols
            % succ_width = succ_up - succ_low + ones(n,1);
            % succ_subscripts = cell(n,1);
            % [succ_subscripts{:}] = ind2sub(succ_width',1:prod(succ_width));
            % succ_subscripts = cell2mat(succ_subscripts);
            % succ_subscripts = bsxfun(@plus, succ_subscripts, succ_low-ones(n,1));
            
            % Convert 3D subscripts into 1D indices
            % succ_indices = sub2ind(sym_x',succ_subscripts(1,:),succ_subscripts(2,:),succ_subscripts(3,:));
            
            % Check if the pair fully goes into the target set
            % HUSSEIN: commenting the following code.
            % if all(ismember(succ_indices,target_indices))
                % Add current control to controller
            %    Controller_temp(s_ind) = u;
                % Stop looking at other control inputs
            %    break
            % end
        end
    end

%     for i = 1:size(Covering,2)
%         if ~isempty(Covering(i).rectangles)
%             [ind1,ind2,ind3] = ind2sub(sym_x,i);
%             rect_low = ([ind1,ind2,ind3] - 1).*symbol_step' + X_low';
%             rect_up = ([ind1,ind2,ind3]).*symbol_step' + X_low';
%             rects_c = [rect_low; rect_up];
%             for j = 1:size(Covering(i).rectangles,3)
%                 % Hussein: this is dependent on the dimension being 3, change
%                 % it in the future to support arbitrary dimensions.
%                 rects_c_temp = [];
%                 for h = 1:size(rects_c,3)
%                     [rect_c_temp, rect_i] = Get_rects_inter(rects_c(:,:,h), Covering(i).rectangles(:,:,j));
%                     if ~isempty(rect_c_temp)
%                         rects_c_temp = cat(3, rects_c_temp, rect_c_temp);
%                     end
%                 end
%                 if isempty(rects_c_temp)
%                     Controller(i) = 1;
%                     break;
%                 else
%                     rects_c = rects_c_temp;
%                 end
%             end
%         end
%     end
    
    % Check if the synthesis progressed during this iteration
    % HUSSEIN: changing the following check
    if progress_indicator || partial_progress_indicator % ~isempty(Controller_temp) % any(Controller_temp)
        fprintf('%s\t%d new controllable states have been found in this synthesis iteration\n',num2str(datestr(now)), progress_indicator) % nnz(Controller_temp)
        % HUSSEIN: adding the following line, at each iteration of the
        % while loop, new rectangles are added. No need to explore old
        % targets that have already been explored.
        % target_indices = targets_temp;
%         points = [];
%         for k = 1:size(targets_temp,3)
%             points = cat(1,points, rectangle_to_vertices(targets_temp(:,:,k)));
%         end
%         shp = alphaShape(points(:,1),points(:,2),points(:,3));
%         % targets_temp = convhulln(points);
%         for k = 1:size(targets_temp,3)
%             targets_temp(:,:,k) = Enlarge_target_alphashape(targets_temp(1,:,k), targets_temp(2,:,k), shp);
% %             for k2 = 1:size(targets_temp,3)
% %                 points = rectangle_to_vertices(Combine_rects(cat(3,targets_temp(:,:,k1), targets_temp(:,:,k2))));
% %                 for p_ind = 1:size(points,1)
% %                     if 
% %                 end
% %             end
%         end
%         for ind1 = 1:size(targets_temp,3)
%             for ind2 = 1:size(targets_temp,3)
%                 for dim = 1:size(targets_temp,2)
%                     if targets_temp(1,dim,ind1) > targets_temp(1,dim,ind2) && 
%                     end
%                 end
%             end
%         end
        targets = targets_temp;
        % Controller_temp_size = size(Controller_temp);
        % for ind = 1:Controller_temp_size(1) % s_ind = 1:numel(symbols_to_explore)
            % if Controller_temp(s_ind)
            % s = symbols_to_explore(s_ind);
            % Write the obtained results in the Controller variable
            % Controller(s) = Controller_temp(s_ind);
        %    Controller(Controller_temp(ind,1)) = Controller_temp(ind,2);
            % Controller_temp(s_ind);
            % And update the indices of target symbols
            % HUSSEIN: commented the following line since targets is
            % updated above.
            % target_indices = [target_indices, s];
            % end
        % end
    else
        % If not, stop the while loop (no more progress can be obtained)
        fprintf('%s\tNo new controllable state has been found in this synthesis iteration\n',num2str(datestr(now)))
        if any(Controller(obstacle_indices)~=0)
            'hits the obstacles!!'
        end
        if iterations_before_break > 0
            targets = targets_temp;
            iterations_before_break = iterations_before_break -1;
        else
            break
        end
    end
end

disp(['Controller synthesis for reach-avoid specification: ' num2str(toc) ' seconds'])
controllable_states = nnz(Controller);
if controllable_states
    fprintf('%d of %d symbols are controllable to satisfy the reach-avoid specification\n',controllable_states,matrix_dim_full(1))
else
    fprintf('The reach-avoid specification cannot be satisfied from any initial state\n')
end
end

%% Check that the controller has been created properly
% %     this test needs to be modified, now that the target symbols are 0 instead of -1
% for s = 1:numel(Controller)
%     u = Controller(s);
%     if u > 0
%         % Convert 1D s index to 6D subscript
%         [s1,s2,s3,s4,s5,s6] = ind2sub(sym_x',s);
%         s_subscript = [s1;s2;s3;s4;s5;s6];
% 
%         % Get corresponding 1D index in the reduced model
%         s_reduced_ind = 1+(s-s_subscript(1)-(s_subscript(2)-1)*sym_x(1))/(sym_x(1)*sym_x(2));
% 
%         % Get successor interval in the global model
%         succ_low = shiftdim(Symbolic_reduced(s_reduced_ind,u,1:n),2) + s_subscript.*(~state_dimensions');
%         succ_up = shiftdim(Symbolic_reduced(s_reduced_ind,u,n+1:end),2) + s_subscript.*(~state_dimensions');
%         
%         % Extract subscripts for the covered symbols
%         succ_width = succ_up - succ_low + ones(n,1);
%         succ_subscripts = cell(n,1);
%         [succ_subscripts{:}] = ind2sub(succ_width',1:prod(succ_width));
%         succ_subscripts = cell2mat(succ_subscripts);
%         succ_subscripts = bsxfun(@plus, succ_subscripts, succ_low-ones(n,1));
%         
%         % Convert 6D subscripts into 1D indices
%         succ_indices = sub2ind(sym_x',succ_subscripts(1,:),succ_subscripts(2,:),succ_subscripts(3,:),succ_subscripts(4,:),succ_subscripts(5,:),succ_subscripts(6,:));
%         
%         % Check that all successors are controllable
%         if any(Controller(succ_indices) == 0)
%             error('Synthesized controller does not satisfy the specifications')
%         end
%     end
% end

%% Wrapping on state 3

% Skip safety on orientation:
%     % no safety condition on the orientation (state 3)
%     if any(succ_low([1:2,4:end])<1 | succ_up([1:2,4:end])>sym_x([1:2,4:end]))
%         continue
%     end

% removing safety on psi means that the sub2ind or ind2sub might not work !!
%   if "unsafe" only on the psi dimension
%   => need to shift/wrap before ??

% rename the 3rd dimension of the symbol to one in the bounds ?
%   PB: we might not have an interval anymore, but 2!

% should it be done before converting to symbols ?
% if there is wrapping, this might give weird stuff ???
%   depending on sym_x(3), wrapped symbols might not match the real symbols

% Make something independant of what is considered for the reference/psi_low => so that we can adapt psi_low to the specs
% replace +/- pi by X_low(3) and X_up(3) ?

% % Bring the resulting angles (3rd dimension) to [-pi,pi]
% mod_low = mod(Succ_low(3)+pi,2*pi)-pi;
% mod_up = mod(Succ_up(3)+pi,2*pi)-pi;
% bool_disjoint_modulo = 0;
% if Succ_up(3) - Succ_low(3) >= 2*pi     % Covers the whole interval [-pi,pi]
%     Succ_low(3) = -pi;
%     Succ_up(3) = pi;
% elseif mod_low < mod_up                 % Just shift the successors to [-pi,pi]
%     Succ_low(3) = mod_low;
%     Succ_up(3) = mod_up;
% else                                    % Results in 2 disjoint intervals [-pi mod_up] and [mod_low pi]
%     bool_disjoint_modulo = 1;
%     Succ_low(3) = mod_low;
%     Succ_up(3) = mod_up;
% end

%% Generation of possible values with (k,n)-Gray Code
function x = Gray(xi,n,k)
% From: Guan, Dah-Jyh (1998). "Generalized Gray Codes with Applications". 
% Proc. Natl. Sci. Counc. Repub. Of China (A) 22: 841???848. 
% http://nr.stpi.org.tw/ejournal/ProceedingA/v22n6/841-848.pdf.

x = zeros(n,k^n);   % The matrix with all combinations
a = zeros(n+1,1);   % The current combination following (k,n)-Gray code
b = ones(n+1,1);    % +1 or -1
c = k*ones(n+1,1);  % The maximum for each digit
j=1;
while (a(n+1)==0)
    % Write current combination in the output
    x(:,j) = xi(a(1:n)+1);     
    j = j + 1;
    
    % Compute the next combination
    i = 1;
    l = a(1)+b(1);
    while (l>=c(i)) || (l<0)
        b(i) = -b(i);
        i = i+1;
        l = a(i)+b(i);
    end
    a(i) = l;
end
end

% Hussein
% A function that takes two axes-aligned 3D rectangles and returns a list of rectangles
% representing rect1\rect2 and rectangle representing rect1 \cap rect2
function empty = check_rect_empty(rect, allow_zero_dim)
    if allow_zero_dim && all(rect(1, :) <= rect(2, :)) && any(rect(1, :) < rect(2, :))
        empty = 0;
    elseif ~allow_zero_dim && all(rect(1, :) < rect(2, :))
        empty = 0;
    else
        empty = 1;
    end
end 

function rect2_contains_rect1 = does_rect_contain(rect1, rect2)
    rect2_contains_rect1 = 1;
    for i=1:size(rect1,2)
        if rect1(1,i) < rect2(1,i) || rect1(2,i) > rect2(2,i)
            rect2_contains_rect1 = 0;
            return;
        end
    end
end


function rects_intersect = Do_rects_inter(rect1, rect2)
    if check_rect_empty(rect1, 1) || check_rect_empty(rect2, 1)
        rect1
        rect2
        "Do not pass empty rectangles to intersect function"
        rects_intersect = 0;
    else
        for i = 1:size(rect1,2)
            if rect1(1, i) >= rect2(2, i) || rect1(2, i) <= rect2(1, i)
                rects_intersect = 0;
                return
            end
        end
        rects_intersect = 1;
    end
end

function combined_rect = Combine_rects(rects)
    if any(size(rects)==0)
        combined_rect = [];
        return
    end
    combined_rect = rects(:,:,1);
    for rect_ind = 1:size(rects,3)
        combined_rect = [min(combined_rect(1, :), rects(1,:,rect_ind));
            max(combined_rect(2, :), rects(2,:,rect_ind))];
    end
end

function rect = get_bounding_box(points)
    if isempty(points)
        rect = [];
        return
    end
    rect = [points(1,:);points(1,:)];
    for p_ind = 2:size(points,1)
        rect = [min(points(p_ind, :), rect(1,:));
            max(points(p_ind, :), rect(2,:))];
    end
end

function [rect_c, rect_i] = Get_rects_inter(rect1, rect2)
    rect_i = [max(rect1(1, :), rect2(1, :))];
    rect_i = [rect_i; min(rect1(2, :), rect2(2, :))];
    rect_c = [];
    area_c = 0;
    area_i = prod(rect_i(2,:) - rect_i(1,:));
    area1 = prod(rect1(2,:) - rect1(1,:));
    area_c_max = area1 - area_i;
    for dim = 1:size(rect1,2)
        rect_temp = rect_i;
        if rect1(1,dim) < rect_i(1,dim)
            rect_temp(1,dim) = rect1(1,dim);
            rect_temp(2,dim) = rect_i(1,dim);
            rect_c = cat(3,rect_c, rect_temp);
            area_c = area_c + prod(rect_temp(2,:) - rect_temp(1,:));
        end
        rect_temp = rect_i;
        if rect1(2,dim) > rect_i(2,dim)
            rect_temp(1,dim) = rect_i(2,dim);
            rect_temp(2,dim) = rect1(2,dim);
            rect_c = cat(3,rect_c, rect_temp);
            area_c = area_c + prod(rect_temp(2,:) - rect_temp(1,:));
        end
        % TODO: Hussein: should add the two cases where both are correct
    end
    if area_c < area_c_max
        for dim1 = 1:size(rect1,2)
            for dim2 = 1:size(rect1,2)
                rect_temp = rect1;
                if rect1(1,dim1) < rect_i(1,dim1) && rect1(1,dim2) < rect_i(1,dim2)
                    rect_temp(2,dim1) = rect_i(1,dim1);
                    rect_temp(2,dim2) = rect_i(1,dim2);
                    rect_c = cat(3,rect_c, rect_temp);
                    area_c = area_c + prod(rect_temp(2,:) - rect_temp(1,:));
                end
                rect_temp = rect1;
                if rect1(2,dim1) > rect_i(2,dim1) && rect1(2,dim2) > rect_i(2,dim2)
                    rect_temp(1,dim1) = rect_i(2,dim1);
                    rect_temp(1,dim2) = rect_i(2,dim2);
                    rect_c = cat(3,rect_c, rect_temp);
                    area_c = area_c + prod(rect_temp(2,:) - rect_temp(1,:));
                end
            end
        end
    end
    if area_c < area_c_max
        for dim1 = 1:size(rect1,2)
            for dim2 = 1:size(rect1,2)
                for dim3 = 1:size(rect1,2)
                    rect_temp = rect1;
                    if rect1(1,dim1) < rect_i(1,dim1) && rect1(1,dim2) < rect_i(1,dim2) && rect1(1,dim3) < rect_i(1,dim3)
                        rect_temp(2,dim1) = rect_i(1,dim1);
                        rect_temp(2,dim2) = rect_i(1,dim2);
                        rect_temp(2,dim3) = rect_i(1,dim3);
                        rect_c = cat(3,rect_c, rect_temp);
                    end
                    rect_temp = rect1;
                    if rect1(2,dim1) > rect_i(2,dim1) && rect1(2,dim2) > rect_i(2,dim2) && rect1(2,dim3) > rect_i(2,dim3)
                        rect_temp(1,dim1) = rect_i(2,dim1);
                        rect_temp(1,dim2) = rect_i(2,dim2);
                        rect_temp(1,dim3) = rect_i(2,dim3);
                        rect_c = cat(3,rect_c, rect_temp);
                    end
                end
            end
        end
    end
    %if length(rect_c) == 0
    %    rect_c = rect1;
    %end
end

function [subscripts] = Range_to_subscripts(rect_low, rect_up, symbol_step, X_low, X_up, sym_x, n)
    rect_low = rect_low';
    rect_up = rect_up';
    rect_low = max(rect_low, X_low); % making sure curr is in X
    rect_low = min(rect_low, X_up);
    rect_up = min(rect_up, X_up);
    rect_up = max(rect_up, X_low);
    curr_low_over = floor(1 + (rect_low - X_low) ./ symbol_step);
    curr_up_over = ceil(1 + (rect_up - X_low) ./ symbol_step);
    no_partially_covered_indices = 0;
    if check_rect_empty([curr_low_over';curr_up_over'], 1)
        subscripts = [];
        no_partially_covered_indices = 1;
    end
    if ~no_partially_covered_indices
        [curr_low_over, curr_up_over] = keep_in_range(curr_low_over,curr_up_over, sym_x);
        curr_width_over = curr_up_over - curr_low_over; % + ones(n,1)
        curr_subscripts_over = cell(n,1); 
        [curr_subscripts_over{:}] = ind2sub(curr_width_over',1:prod(curr_width_over));
        curr_subscripts_over = cell2mat(curr_subscripts_over);
        subscripts = bsxfun(@plus, curr_subscripts_over, curr_low_over  - ones(n,1));
    end
end

function [indices, partially_covered_indices, quantized_rect_low, quantized_rect_up] = Range_to_indices(rect_low, rect_up, symbol_step, X_low, X_up, sym_x, n, under_approx)
    
    rect_low = rect_low';
    rect_up = rect_up';
    rect_low = max(rect_low, X_low); % making sure curr is in X
    rect_low = min(rect_low, X_up);
    rect_up = min(rect_up, X_up);
    rect_up = max(rect_up, X_low);
    quantized_rect_low = [];
    quantized_rect_up = [];
    partially_covered_indices = [];
    if all(rect_up - rect_low == 0)
        indices = [];
        return
    end
    no_indices = 0;
    no_partially_covered_indices = 0;
    if under_approx
        curr_low = ceil(1 + (rect_low - X_low) ./ symbol_step);
        curr_up = floor(1 + (rect_up - X_low) ./ symbol_step);
        if check_rect_empty([curr_low';curr_up'], 0)
            indices = [];
            no_indices = 1;
        end
%     else
%         curr_low = floor(1 + (rect_low - X_low) ./ symbol_step);
%         curr_up = ceil(1 + (rect_up - X_low) ./ symbol_step);
%         if check_rect_empty([curr_low';curr_up'], 1)
%             indices = [];
%             no_indices = 1;
%         end
    end
    if ~no_indices && under_approx
        [curr_low, curr_up] = keep_in_range(curr_low,curr_up, sym_x);
        curr_width = curr_up - curr_low; % + ones(n,1)
        curr_subscripts = cell(n,1); 
        [curr_subscripts{:}] = ind2sub(curr_width',1:prod(curr_width));
        curr_subscripts = cell2mat(curr_subscripts);
        curr_subscripts = bsxfun(@plus, curr_subscripts, curr_low  - ones(n,1));
        indices = sub2ind(sym_x',curr_subscripts(1,:),curr_subscripts(2,:),curr_subscripts(3,:));
    end
    curr_low_over = floor(1 + (rect_low - X_low) ./ symbol_step);
    curr_up_over = ceil(1 + (rect_up - X_low) ./ symbol_step);
    if check_rect_empty([curr_low_over';curr_up_over'], 1)
        partially_covered_indices = [];
        no_partially_covered_indices = 1;
    end
    if ~no_partially_covered_indices
        [curr_low_over, curr_up_over] = keep_in_range(curr_low_over,curr_up_over, sym_x);
        curr_width_over = curr_up_over - curr_low_over; % + ones(n,1)
        curr_subscripts_over = cell(n,1); 
        [curr_subscripts_over{:}] = ind2sub(curr_width_over',1:prod(curr_width_over));
        curr_subscripts_over = cell2mat(curr_subscripts_over);
        curr_subscripts_over = bsxfun(@plus, curr_subscripts_over, curr_low_over  - ones(n,1));
        partially_covered_indices = sub2ind(sym_x',curr_subscripts_over(1,:),curr_subscripts_over(2,:),curr_subscripts_over(3,:));
    end
    if ~under_approx
        indices = partially_covered_indices;
    else
        partially_covered_indices = setdiff(partially_covered_indices,indices);
    end
%     for l = 1:size(curr_subscripts,1)
%         for h = 1:size(curr_subscripts,2)
%             if curr_subscripts(l,h) < 1
%                 curr_subscripts(l,h) = 1;
%             elseif curr_subscripts(l,h) > sym_x(l)
%                 curr_subscripts(l,h) = sym_x(l);
%             end
%         end
%     end
    %quantized_rect_low = (curr_low - 1) .* symbol_step + X_low;
    %quantized_rect_up = (curr_up - 1) .* symbol_step + X_low;
    %quantized_rect_low = quantized_rect_low';
    %quantized_rect_up = quantized_rect_up';

%     if under_approx
%         original_rect = [rect_low';rect_up'];
%         quantized_rect = [quantized_rect_low; quantized_rect_up];
%         [rect_c, rect_i] = Get_rects_inter(original_rect, quantized_rect);
%         for j=1:size(rect_c,3)
%             curr_low = rect_c(1,:,j)';
%             curr_up = rect_c(2,:,j)';
%             curr_low = floor(1 + (curr_low - X_low) ./ symbol_step);
%             curr_up = ceil(1 + (curr_up - X_low) ./ symbol_step);
%             [curr_low, curr_up] = keep_in_range(curr_low,curr_up, sym_x);
%             curr_width = curr_up - curr_low; % + ones(n,1)
%             curr_subscripts = cell(n,1); 
%             [curr_subscripts{:}] = ind2sub(curr_width',1:prod(curr_width));
%             curr_subscripts = cell2mat(curr_subscripts);
%             curr_subscripts = bsxfun(@plus, curr_subscripts, curr_low  - ones(n,1));
%             indices_temp = sub2ind(sym_x',curr_subscripts(1,:),curr_subscripts(2,:),curr_subscripts(3,:));
%             partially_covered_indices = [partially_covered_indices indices_temp];
%         end
%     end 

    quantized_rect_low = rect_low';
    quantized_rect_up = rect_up';
    % partially_covered_indices
    %rect_low
    %rect_up
    %curr_low
    %curr_up
    %curr_subscripts
    
    
end

function [curr_low, curr_up] = keep_in_range(curr_low,curr_up, sym_x)
    for dim = 1:length(curr_up)
            if curr_low(dim) < 1
                curr_low(dim) = 1;
            elseif curr_low(dim) > sym_x(dim)
                curr_low(dim) = sym_x(dim); 
            end
            if curr_up(dim) < 1
                curr_up(dim) = 1;
            elseif curr_up(dim) > sym_x(dim)
                curr_up(dim) = sym_x(dim); 
            end
    end
end 

function rect = Enlarge_target_alphashape(Target_low, Target_up, shp)
    for dim = 1:size(Target_low,2)
        points = rectangle_to_vertices([Target_low; Target_up]);
        for p_ind = 1:size(points,1)
            [shp_p_ind,distance] = nearestNeighbor(shp,points(p_ind,1),points(p_ind,2),points(p_ind,3));
            if distance > 0
                'points(p_ind,:)', points(p_ind,:)
                'shp.Points(p_ind,:)', shp.Points(shp_p_ind,:)
                new_rect = get_bounding_box(cat(1,points,shp.Points(shp_p_ind,:)));
                new_points = rectangle_to_vertices(new_rect);
                valid_point = 1;
                for p_ind_new = 1:size(new_points,1)
                    if ~inShape(shp,new_points(p_ind_new,1),new_points(p_ind_new,2),new_points(p_ind_new,3))
                        valid_point = 0;
                        break
                    end
                end
                if valid_point
                    new_rect
                    distance
                    'before'
                    Target_low
                    Target_up
                    Target_low = new_rect(1,:);
                    Target_up = new_rect(2,:);
                    points = new_points;
                    'after'
                    Target_low
                    Target_up
                end
            end
        end
    end
    rect = [Target_low; Target_up];
end

% function [Target_low, Target_up, succ] = Enlarge_target(Target_low, Target_up, Controller, symbol_step, dim, pos, X_up, X_low, sym_x, n, targets_temp)
function [Target_low, Target_up, succ] = Enlarge_target(Target_low, Target_up, symbol_step, dim, pos, X_up, X_low, sym_x, n, shp)
    succ = 0;   
    Target_low_temp = Target_low;
    Target_up_temp = Target_up;
    max_itr = 1;
    step = Target_up(dim) - Target_low(dim)+ symbol_step(dim);
    % update_controller = 1;
    while max_itr >= 0
        if pos
            if Target_up_temp(dim) < X_up(dim)
                Target_low_temp(dim) = Target_up_temp(dim);
                Target_up_temp(dim) = min(Target_up_temp(dim) + step, X_up(dim));
                % multiplier*symbol_step(dim)
            else
                break
            end
        else
            if Target_low_temp(dim) > X_low(dim)
                Target_up_temp(dim) = Target_low_temp(dim);
                Target_low_temp(dim) = max(Target_low_temp(dim) - step, X_low(dim));
            else
                break
            end
        end
%         if 0 && ~isempty(targets_temp)
%             for target_ind = 1:size(targets_temp,3)
%                 target = targets_temp(:,:,target_ind);
%                 target_contains_Target_temp = does_rect_contain([Target_low_temp; Target_up_temp], target);
%                 if target_contains_Target_temp
% %                     'enlarging [Target_low_temp; Target_up_temp] from'
% %                     Target_low
% %                     Target_up
%                     succ_target = 1;
%                     if pos
%                         Target_low_temp(dim) = Target_up_temp(dim);
%                         Target_up_temp(dim) = target(2,dim);
% %                         'to'
% %                         Target_low
% %                         Target_up_temp
%                     else
%                         Target_up_temp(dim) = Target_low_temp(dim);
%                         Target_low_temp(dim) = target(1,dim);
% %                         'to'
% %                         Target_low_temp
% %                         Target_up
%                     end
%                     
%                     %break
% %                     'taken!!'
% %                     Target_low_temp
% %                     Target_up_temp
% %                     target
%                 end
%             end
%         end
        % if 1 || succ_target == 0
            % [extension_indices, redundant_temp1, redundant_temp2] 
%             [extension_indices, partially_covered_indices, quantized_rect_low, quantized_rect_up] = Range_to_indices( ...
%                 Target_low_temp, Target_up_temp, ...
%                 symbol_step, X_low, X_up, sym_x, n, 0);
        %         extension_intersects_obstacles = 0;
        %         for i = 1:size(Obstacle_up,2)
        %             if Do_rects_inter([Target_low_temp; Target_up_temp], [Obstacle_low(:,i)'; Obstacle_up(:,i)'])
        %                 extension_intersects_obstacles = 1;
        %                 break
        %             end
        %         end
            % if ~isempty(extension_indices) && all(Controller(extension_indices) ~= 0) % && ~extension_intersects_obstacles 
        new_points = rectangle_to_vertices([Target_low_temp; Target_up_temp]);
        succ_target = 1;
        for p_ind_new = 1:size(new_points,1)
            if ~inShape(shp,new_points(p_ind_new,1),new_points(p_ind_new,2),new_points(p_ind_new,3))
                succ_target = 0;
                break
            end
        end
%             if valid_point
%                 succ_target = 1;
%             else
%                 if succ_target
%                     'Conflict!!'
%                     Controller(extension_indices)
%                     Target_low_temp
%                     Target_up_temp
%                     target
%                 end
%                 % "Enlarged!!!!!"
%             end
        %end
        if succ_target
            if pos
                Target_up = Target_up_temp;
            else
                Target_low = Target_low_temp;
            end
            step = step * 2;
            succ = 1;
        elseif step <= symbol_step(dim)
            break
        else
            if pos
                Target_up_temp = Target_up;
            else
                Target_low_temp = Target_low;
            end
            step = step / 2;
        end
        max_itr = max_itr - 1;
    end

end

function [points] = rectangle_to_vertices(rect)
    points = [];
    for i = 1:2
        for j = 1:2
            for k = 1:2
                points = cat(1,points,[rect(i,1),rect(j,2),rect(k,3)]);
            end
        end
    end
end
