%% Look for the right pair of partition and sampling parameters
close all
clear
addpath(genpath('./TIRA'))  % Add access to reachability toolbox folder
addpath(genpath('./multipoly'))  % Add access to reachability toolbox folder
load('SOS_outputs_disturbances.mat','e1lbval','e1ubval','e2lbval','e2ubval','e3lbval','e3ubval','e4lbval','e4ubval','e5lbval','e5ubval','e6lbval','e6ubval','Vval','err','gamma_list','kval','uhat')
% load('SOS_outputs.mat','e1lbval','e1ubval','e2lbval','e2ubval','e3lbval','e3ubval','e4lbval','e4ubval','e5lbval','e5ubval','e6lbval','e6ubval','Vval','err','gamma_list','kval','uhat')

%% Initializations
X_up = [10;6.5;pi];
X_low = [0;0;-pi];
n_x = numel(X_up);
U_up = [0.18;0.1;0.1];
U_low = [-0.18;-0.1;-0.1];
n_u = numel(U_up);
W_up = [0.01;0.01;0.01];
W_low = -W_up;
n_w = numel(W_up);

% State space partition
sym_x = 30*ones(n_x,1);

% Input set discretization
sym_u = 9*ones(n_u,1);
ui_values = 1:sym_u(1);
U_discrete = Gray(ui_values,n_u,sym_u(1));
U_discrete = repmat(U_low,1,sym_u(1)^n_u) + (U_discrete-1).*repmat((U_up-U_low)/(sym_u(1)-1),1,sym_u(1)^n_u);
    
% Time step
time_step = 5;    % seconds

%% Shrunk state space
% Error bounds induced by the model reduction
error_6D_up = [e1ubval;e2ubval;e3ubval;e4ubval;e5ubval;e6ubval];
error_6D_low = [e1lbval;e2lbval;e3lbval;e4lbval;e5lbval;e6lbval];
error_6D = max(abs(error_6D_low),abs(error_6D_up));

% Shrunk 3D state space
X_3D_shrunk_up = X_up - error_6D(1:3);
X_3D_shrunk_low = X_low + error_6D(1:3);
symbol_step = (X_3D_shrunk_up-X_3D_shrunk_low)./sym_x;

%% Trajectories from each symbol/input pairs
% RS = zeros(sym_x(3),prod(sym_u),2);
% 
% for s_ind = 1:sym_x(3)
%     % Convert 1D s index to 3D subscript
%     s_subscript = [1;1;s_ind]
%     
%     % Interval of the source symbol
%     symbol_low = X_low+symbol_step.*(s_subscript-1);
%     symbol_up = X_low+symbol_step.*s_subscript;
%     
%     for u_ind = 1:prod(sym_u)
%         u = U_discrete(:,u_ind);
%         
%         % Reachability analysis
%         [J_x_low,J_x_up,J_p_low,J_p_up] = UP_Jacobian_Bounds(0,time_step,symbol_low,symbol_up,[u;W_low],[u;W_up]);
%         [succ_low,succ_up] = OA_3_CT_Mixed_Monotonicity2(0,time_step,symbol_low,symbol_up,[u;W_low],[u;W_up],J_x_low,J_x_up,J_p_low,J_p_up);
%         
%         RS(s_ind,u_ind,1) = norm(symbol_low-succ_low);
%         RS(s_ind,u_ind,2) = norm(symbol_up-succ_up);
%         
%     end
% end

    
%% Trajectories from random points for various time steps

tic 
samples = 30;
tau_step = 0.1;
tau_set = 0:tau_step:10;
Succ = zeros(prod(sym_u),size(tau_set,2));

for u_ind = 1:prod(sym_u)
    u = U_discrete(:,u_ind);
    distances = zeros(samples,size(tau_set,2));
    for i = 1:samples
        x0 = X_low + rand(n_x,1).*(X_up-X_low);
        w = W_low + rand(n_w,1).*(W_up-W_low);
        [x_time,x_traj] = ode45(@(t,x) System_description(t,x,[u;w]),tau_set,x0);
        for t = 1:size(tau_set,2)
            distances(i,t) = norm(x_traj(t,:)-x0');
        end
    end
    Succ(u_ind,:) = mean(distances);
end
toc
Succ_summary = [min(Succ);mean(Succ);max(Succ)];

% Comparison with the symbolic_steps for various sizes
sym_x_set = 5:5:50;
symbol_step = zeros(3,numel(sym_x_set));
for i = 1:numel(sym_x_set)
    symbol_step(:,i) = (X_3D_shrunk_up-X_3D_shrunk_low)/sym_x_set(i);
end
symbol_step_summary = [min(symbol_step);sqrt(sum(symbol_step.^2))];


% % We want that the average distance traveled is about 2 symbolic_steps
% output = [tau_set;mean(Succ);zeros(1,numel(tau_set))];
% average_2_sym_steps = 2*mean(symbol_step_summary);
% for i = 1:numel(tau_set)
%     [~,b] = min(abs(average_2_sym_steps-output(2,i)));
%     output(3,i) = sym_x_set(b);
% end
% disp('Time steps')
% disp('Averaged travelled distance')
% disp('Closest partition parameter')
% output

% Pick time step so that the average distance travelled
% is between 2 and 3 symbolic steps
average_sym_step = mean(symbol_step_summary);
output = [sym_x_set;zeros(2,numel(sym_x_set))];
for i = 1:numel(sym_x_set)
    [~,b] = min(abs(mean(Succ)-2*average_sym_step(i)));
    output(2,i) = tau_set(b);
    [~,b] = min(abs(mean(Succ)-3*average_sym_step(i)));
    output(3,i) = tau_set(b);
end
disp('Partition parameter')
disp('Closest time sampling for 2*Averaged symbol size')
disp('Closest time sampling for 3*Averaged symbol size')
output


