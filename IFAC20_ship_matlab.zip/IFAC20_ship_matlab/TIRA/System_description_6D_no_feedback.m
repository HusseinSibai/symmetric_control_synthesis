%% Cybership 3 model
% Maneuvering model (without disturbance or parameter uncertainty)

% List of inputs
%   t: time
%   x: state
%   tau: surge/sway/yaw inputs

% List of outputs
%   dx: vector field evaluated at time t, state x and input p

function dx = System_description_6D_no_feedback(t,x,tau)

%% Persistent variables
persistent M D L Kp_delta Kp_U

if isempty(Kp_U)
    %% Load vessel parameters - these are fullscale from ShipX
    load CS3_20181102.mat
    load CS3ABC_20181102.mat

    %% Scale down to model-scale - CS3
    % Scale of model
    lambda =  1/30; 

    % Scaling matrix for scaling mass and damping matrices, from dimensional
    % analysis
    Lambda = [lambda^3*ones(3), lambda^4*ones(3);
              lambda^4*ones(3), lambda^5*ones(3)];

    % Rigid body mass
    M_RB_m = Lambda.*vessel.MRB;
    Modelvessel.MRB = M_RB_m;

    % Hydrodynamic coefficients
    Bv_m = Lambda.*vessel.Bv;
    Modelvessel.Bv = Bv_m;
    
    %% Inertia variables
    % Rigid body inertia and added mass
    Mrb = [Modelvessel.MRB(1,1), 0 , 0 ;
        0, Modelvessel.MRB(2,2), Modelvessel.MRB(2,6);
        0, Modelvessel.MRB(6,2) ,Modelvessel.MRB(6,6)];

    Ma = [2.2997 0 0; ...
           0 13.1880 2.4827; ...
           0 2.4827 3.5574];

    M = Mrb + Ma;
    
    %% Damping variables 
    % Linear potential damping and viscous damping - Fossen (2011) p. 115
    
    Bv = diag([Modelvessel.Bv(1,1),Modelvessel.Bv(2,2),Modelvessel.Bv(6,6)]);
    
    D_L = [4.2151 0 0; ...
           0 24.1719 2.6573; ...
           0 2.6573 6.7726];% zero frequency for DP
    
    D = Bv + D_L;
    D(3,3)=2*D(3,3);
    
    %% Coriolis force linearized about surge speed - same expression in maneuvering and DP
    L = [0 0 0;
         0 0 1;
         0 0 0];

    %% Controller
%     Kp_delta = 0.1*M(3,3);
    Kp_delta = 0.05*M(3,3);
    Kp_U = 1*M(1,1);
end

%% Coriolis force linearized about surge speed - same expression in maneuvering and DP
C = x(4)*M*L ;   % With velocity

% Maneuvering equations of motion
dx = [cos(x(3))*x(4)-sin(x(3))*x(5) ; sin(x(3))*x(4)+cos(x(3))*x(5) ; x(6) ; M\(-(C+D)*x(4:6) + tau)];       

