%% Cybership 3 model
% reduced to 3 dimensions of the positions
% assuming the 3 velocities as control inputs

% List of inputs
%   t: time
%   x: state (N,E,psi)
%   u: input value (u,v,r) and disturbances (w1,w2,w3)

% List of outputs
%   dx: vector field evaluated at time t, state x and input p

function dx = System_description(t,x,u)

% dx = [u(1)*cos(x(3))-u(2)*sin(x(3)); ...
%       u(1)*sin(x(3))+u(2)*cos(x(3)); ...
%       u(3)];

dx = [u(1)*cos(x(3))-u(2)*sin(x(3))+u(4); ...
      u(1)*sin(x(3))+u(2)*cos(x(3))+u(5); ...
      u(3)+u(6)];