%% User-provided function returning bounds on the Jacobian matrices
% The user can either provider global bounds, or a function of the input
% arguments (t_init,t_final,x_low,x_up,p_low,p_up) returning local bounds
% Jacobian definitions:
%   to states:  J_x(t) = d(System_description(t,x,p))/dx
%   to inputs:  J_p(t) = d(System_description(t,x,p))/dp

% List of inputs
%   t_init: initial time
%   t_final: time at which the reachable set is approximated (for continuous-time system only)
%       for discrete-time system, a dummy value can be provided
%   [x_low,x_up]: interval of initial states (at time t_init)
%   [p_low,p_up]: interval of allowed input values

% List of outputs
%   [J_x_low,J_x_up]: bounds of the Jacobian with respect to the state
%   [J_p_low,J_p_up]: bounds of the Jacobian with respect to the input

% Created as a copy of UP_Jacobian_Bounds.m by Hussein Sibai (June 11th,
% 2022). The aim is to generate a full reachable set instead of just 
% the last one. Actually this is not necessary. Sorry :). Bye. 

function [J_x_low,J_x_up,J_p_low,J_p_up] = UP_Jacobian_Bounds(t_init,t_final,x_low,x_up,p_low,p_up)
n_x = length(x_low);
n_p  = length(p_low);

% Initialization
J_x_low = zeros(n_x);
J_x_up = zeros(n_x);
J_p_low = zeros(n_x,n_p);
J_p_up = zeros(n_x,n_p);

%% Ship model with u in R^6 containing 3 control inputs and 3 disturbances
J_p_low(3,3) = 1;
J_p_low(1,4) = 1;
J_p_low(2,5) = 1;
J_p_low(3,6) = 1;
J_p_up = J_p_low;

if isequal(p_low(1:3),p_up(1:3))
    %% Complex case based on possible orientation values
    u = p_low;
    time_step = t_final-t_init;

    % Possible orientation values over the next sampling period
    psi_low = x_low(3) + min(0,time_step*(u(3)+p_low(6)));
    psi_up = x_up(3) + max(0,time_step*(u(3)+p_up(6)));

    % Min/Max for cosine
    psi_min_cos = pi;
    if psi_low>-pi && psi_up<pi
        psi_min_cos = max(abs(psi_low),abs(psi_up));
    end
    psi_max_cos = 0;
    if (psi_low>0 || psi_up<0) && psi_up<2*pi && psi_low>-2*pi
        psi_max_cos = min(abs(mod(psi_low+pi,2*pi)-pi),abs(mod(psi_up+pi,2*pi)-pi));
    end

    % Min/Max for sine
    psi_min_sin = 3*pi/2;
    if psi_low>-pi/2 && psi_up<3*pi/2
        psi_min_sin = max(abs(psi_low-pi/2),abs(psi_up-pi/2)) + pi/2;
    end
    psi_max_sin = pi/2;
    if (psi_low>pi/2 || psi_up<pi/2) && psi_up<5*pi/2 && psi_low>-3*pi/2
        psi_max_sin = min(abs(mod(psi_low-pi/2+pi,2*pi)-pi),abs(mod(psi_up-pi/2+pi,2*pi)-pi)) + pi/2;
    end

    % Bounds of the state Jacobian
    if u(1) > 0
        J_x_low(1,3) = -u(1)*sin(psi_max_sin);
        J_x_up(1,3) = -u(1)*sin(psi_min_sin);
        J_x_low(2,3) = u(1)*cos(psi_min_cos);
        J_x_up(2,3) = u(1)*cos(psi_max_cos);
    else
        J_x_low(1,3) = -u(1)*sin(psi_min_sin);
        J_x_up(1,3) = -u(1)*sin(psi_max_sin);
        J_x_low(2,3) = u(1)*cos(psi_max_cos);
        J_x_up(2,3) = u(1)*cos(psi_min_cos); 
    end
    if u(2) > 0
        J_x_low(1,3) = J_x_low(1,3) - u(2)*cos(psi_max_cos);
        J_x_up(1,3) = J_x_up(1,3) - u(2)*cos(psi_min_cos);
        J_x_low(2,3) = J_x_low(2,3) - u(2)*sin(psi_max_sin);
        J_x_up(2,3) = J_x_up(2,3) - u(2)*sin(psi_min_sin);
    else
        J_x_low(1,3) = J_x_low(1,3) - u(2)*cos(psi_min_cos);
        J_x_up(1,3) = J_x_up(1,3) - u(2)*cos(psi_max_cos);
        J_x_low(2,3) = J_x_low(2,3) - u(2)*sin(psi_min_sin);
        J_x_up(2,3) = J_x_up(2,3) - u(2)*sin(psi_max_sin); 
    end
    
    % Bounds of the input Jacobian
    J_p_low(1,1) = cos(psi_min_cos);
    J_p_up(1,1) = cos(psi_max_cos);
    J_p_low(1,2) = -sin(psi_max_sin);
    J_p_up(1,2) = -sin(psi_min_sin);
    J_p_low(2,1) = sin(psi_min_sin);
    J_p_up(2,1) = sin(psi_max_sin);
    J_p_low(2,2) = cos(psi_min_cos);
    J_p_up(2,2) = cos(psi_max_cos);
else
    %% Simple bounds, with all cos/sin between -1 and 1
    J_x_low(1,3) = min([p_low(1),-p_up(1)]) + min([p_low(2),-p_up(2)]);
    J_x_low(2,3) = min([p_low(1),-p_up(1)]) + min([p_low(2),-p_up(2)]);
    J_x_up(1,3) = max([p_up(1),-p_low(1)]) + max([p_up(2),-p_low(2)]);
    J_x_up(2,3) = max([p_up(1),-p_low(1)]) + max([p_up(2),-p_low(2)]);

    J_p_low(1:2,1:2) = -1;
    J_p_up(1:2,1:2) = 1;
end

