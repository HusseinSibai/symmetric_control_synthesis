%% Ship (continuous-time)
% Simplified maneuvering model from
% Thor I. Fossen, Morten Breivik and Roger Skjetne, "Line-of-sight 
% path following of underactuated marine craft". 6th IFAC 
% Conference on Manoeuvring and Control of Marine Craft, v. 36(21),
% pp. 211-216, 2003. DOI: 10.1016/S1474-6670(17)37809-6

% states:
%     x(1): x-coordinate on the water
%     x(2): y-coordinate on the water
%     x(3): heading of the ship, with x(3)=0 when it's 
%           facing (x(1),x(2))=(1,0) 
%     x(4): forward velocity relative to ship's heading (surge rate)
%     x(5): lateral velocity relative to ship's heading (sway rate)
%     x(6): angular velocity relative to ship's heading (yaw rate)

% inputs:
%     p(1): surge velocity forcing term
%     p(2): yaw velocity forcing term

function dx = System_description(t,x,p)

% Parameters
M = [25.8 0 0; ...
     0 33.8 1.0115; ...
     0 1.0115 2.16];
N = [2 0 0; ...
     0 7 0.1; ...
     0 0.1 0.5];
k1 = 25;
k2 = 2.5;
k3 = 5;

% Closed-loop dynamics
dx = [x(4)*cos(x(3)) - x(5)*sin(x(3)); ...
      x(4)*sin(x(3)) + x(5)*cos(x(3)); ...
      x(6); ...
      (p(1)-x(4))*k1/M(1,1); ...
      M(2:3,2:3)\([0;k2*(p(2)-x(3))-k3*x(6)] - N(2:3,2:3)*[x(5);x(6)])];
