%% Cybership 3 model
% Maneuvering model (with disturbances and parameter uncertainties)
% System_description_maneuvering

% List of inputs
%   t: time
%   x: state
%   x_d: input value (desired orientation and surge velocity)

% List of outputs
%   dx: vector field evaluated at time t, state x and input p

function dx = System_description(t,x,x_d)

%% Persistent variables
persistent tau_wind v_c beta_c mu_nom
persistent M D L Kp_delta Kp_U

if isempty(M)       
    %% Load vessel parameters - these are fullscale from ShipX
    load CS3_20181102.mat
    load CS3ABC_20181102.mat

    %% Scale down to model-scale - CS3
    % Scale of model
    lambda =  1/30; 

    % Scaling matrix for scaling mass and damping matrices, from dimensional
    % analysis
    Lambda = [lambda^3*ones(3), lambda^4*ones(3);
              lambda^4*ones(3), lambda^5*ones(3)];

    % Main particulars
    Modelvessel.Lpp = lambda*vessel.main.Lpp;
    Modelvessel.Lwl = lambda*vessel.main.Lwl;
    Modelvessel.B = lambda*vessel.main.B;
    Modelvessel.T = lambda*vessel.main.T;

    % Rigid body mass
    M_RB_m = Lambda.*vessel.MRB;
    Modelvessel.MRB = M_RB_m;

    % Hydrodynamic coefficients

    M_A0_m = Lambda.*vesselABC.MA_0;
    Sym_A0 = 0.5*(M_A0_m + M_A0_m');

    Modelvessel.MA_0 = Sym_A0;

    M_Ainf_m = Lambda.*vesselABC.MA_inf;
    Sym_Ainf = 0.5*(M_Ainf_m + M_Ainf_m');
    Modelvessel.MA_inf = Sym_Ainf;


    D0_m = Lambda.*vesselABC.B_0;  % vessel.B(:,:,35,5);
    Sym_D0 = 0.5*(D0_m + D0_m');
    Modelvessel.B_0 = Sym_D0;

    Dinf_m = Lambda.*vesselABC.B_inf;
    Sym_Dinf = 0.5*(Dinf_m + Dinf_m');
    Modelvessel.B_inf = Sym_Dinf;

    Bv_m = Lambda.*vessel.Bv;
    Modelvessel.Bv = Bv_m;
  
    %% Environment - current and wind
    % Wind 
    tau_wind = 1*0.1*[0 0.5 1]';
%         tau_wind = zeros(3,1);

    % Current
    v_c = 1*0.01*[1 0 0]';  % North East current
%         v_c = zeros(3,1);
    beta_c =  atan2(v_c(2),v_c(1));  % Current direction  0 towards North, 90 towards East, -90 towards west, 180 towards South

    % uncertainty bounds on parameters - not implemented...
    % Uncertainty is of the form p(1)*M, p(2)*D, p(3)*v_c, p(4)*tau_wind
    mu_low =[1 1 1 1]';
    mu_up = [1 1 1 1]'; 
    mu_nom = (mu_low+mu_up)/2;
    
    %% Inertia variables
    % Rigid body inertia and added mass
    Mrb = [Modelvessel.MRB(1,1), 0 , 0 ;
        0, Modelvessel.MRB(2,2), Modelvessel.MRB(2,6);
        0, Modelvessel.MRB(6,2) ,Modelvessel.MRB(6,6)];

    Ma = [2.2997 0 0; ...
           0 13.1880 2.4827; ...
           0 2.4827 3.5574];

    M = Mrb + Ma;
    
    %% Damping variables 
    % Linear potential damping and viscous damping - Fossen (2011) p. 115
    
    Bv = diag([Modelvessel.Bv(1,1),Modelvessel.Bv(2,2),Modelvessel.Bv(6,6)]);
    
    D_L = [4.2151 0 0; ...
           0 24.1719 2.6573; ...
           0 2.6573 6.7726];% zero frequency for DP
    
    D = Bv + D_L;
    
    %% Coriolis force linearized about surge speed - same expression in maneuvering and DP
    L = [0 0 0;
         0 0 1;
         0 0 0];

    %% Controller
    Kp_delta = 0.1*M(3,3);
    Kp_U = 1*M(1,1);
end

%% Rotation matrix
R =  [cos(x(3)),-sin(x(3)),0;
      sin(x(3)),cos(x(3)),0;
      0 , 0 , 1];
       
%% Coriolis force linearized about surge speed - same expression in maneuvering and DP
C = x(4)*mu_nom(1)*M*L ;   % With velocity

%% Controller
tau = [Kp_U*(x_d(2)-x(4));0;Kp_delta*(x_d(1)-x(3)-beta_c)];

%% Ship dynamics and state Jacobian
% DP equations of  motion - with nonlinear current drag
dx = [R*x(4:6) + mu_nom(3)*v_c; 
      (1/mu_nom(1))*M\(-(C + mu_nom(2)*D)*x(4:6) + tau + transpose(R)*mu_nom(4)*tau_wind)];  

