%% Reachable set over-approximation using second-order sensitivities
% Grid sample only, and scalar dispersion



% Authors:  
%   Pierre-Jean Meyer, <pjmeyer -AT- berkeley.edu>, EECS, UC Berkeley
% Date: 1st of February 2019

function [succ_low,succ_up,S_x_low,S_x_up,S_p_low,S_p_up] = Reachability_call_scalar_disp(t_init,t_final,x_low,x_up,p_low,p_up,sensi_sampling_number_x,sensi_sampling_number_p)
n_x = numel(x_low);
n_p = numel(p_low);

bool_plot = [0 0 0 0]; % S1RT, S2RS, S1RS, systemRS
sample_number = 200;

%% Initialization
% Ignore state or input sensitivity if the corresponding interval is a singleton
needed_sensitivies = 0;         % Default: need all 6 sensitivities
if isequal(x_low,x_up)
    needed_sensitivies = 2;     % Only compute S_p and S_pp
    S_x_low = zeros(n_x);
    S_x_up = zeros(n_x);
    S_px_low = zeros(n_x,n_x*n_p);
    S_px_up = zeros(n_x,n_x*n_p);
elseif isequal(p_low,p_up)
    needed_sensitivies = 1;     % Only compute S_x and S_xx
    S_p_low = zeros(n_x,n_p);
    S_p_up = zeros(n_x,n_p);
    S_xp_low = zeros(n_x,n_x*n_p);
    S_xp_up = zeros(n_x,n_x*n_p);
end

% Extract from Solver_parameters.m the method choices if not provided as input arguments of this function
run('Solver_parameters.m')
% if nargin <= 7
    sampling_sensitivity_solver = parameters.sampling_sensitivity_solver;
% end

%% User-provided inputs: bounds for the first- and second-order Jacobians

% First-order Jacobians
[J_x_low,J_x_up,J_p_low,J_p_up] = UP_Jacobian_Bounds(t_init,t_final,x_low,x_up,p_low,p_up);

% Second-order Jacobians
[J_xx_low,J_xx_up,J_xp_low,J_xp_up,J_pp_low,J_pp_up,J_px_low,J_px_up] = UP_Jacobian_2ndOrder_Bounds(t_init,t_final,x_low,x_up,p_low,p_up);

%% Over-approximate the reachable TUBE for first-order sensitivities
% using interval arithmetics
fprintf('\nOver-approximation of the reachable tube of the first-order sensitivities ...\n')
tic

% First-order sensitivity with respect to initial states
if needed_sensitivies ~= 2
    [S_x_RT_low,S_x_RT_up] = Affine_interval_system_reachability(t_init,t_final,eye(n_x),eye(n_x),J_x_low,J_x_up,zeros(n_x),zeros(n_x),1);
    
    if bool_plot(1)
        % Compare with random trajectories
        [RT1_x_low,RT1_x_up,rand_traj] = Random_traj_affine(t_init,t_final,eye(n_x),eye(n_x),J_x_low,J_x_up,zeros(n_x),zeros(n_x),1,sample_number);
        plot_dimensions = Subplot_ind(numel(S_x_RT_low));
        for i = 1:size(plot_dimensions,1)
            if ~isequal(S_x_RT_low(plot_dimensions(i,:)),S_x_RT_up(plot_dimensions(i,:)))
                figure(i);
                hold on

                % Plot the trajectories from random initial states
                for j = 1:sample_number
                    plot(rand_traj{j}(:,plot_dimensions(i,1)),rand_traj{j}(:,plot_dimensions(i,2)),'k');
                end
                % Plot 2D over-approximation interval
                x1_low = S_x_RT_low(plot_dimensions(i,1));
                x1_up = S_x_RT_up(plot_dimensions(i,1));
                x2_low = S_x_RT_low(plot_dimensions(i,2));
                x2_up = S_x_RT_up(plot_dimensions(i,2));
                plot([x1_low, x1_low, x1_up, x1_up, x1_low],[x2_low, x2_up, x2_up, x2_low, x2_low],'r')
                plot([x1_low, x1_low, x1_up, x1_up, x1_low],[x2_low, x2_up, x2_up, x2_low, x2_low],'r*')
            end
        end
        assert(all(S_x_RT_low(:)<=RT1_x_low(:) & S_x_RT_up(:)>=RT1_x_up(:)),'First-order reachable tube does not contain sample trajectories')
        pause
        close all
    end
end

% First-order sensitivity with respect to inputs
if needed_sensitivies ~= 1
    [S_p_RT_low,S_p_RT_up] = Affine_interval_system_reachability(t_init,t_final,zeros(n_x,n_p),zeros(n_x,n_p),J_x_low,J_x_up,J_p_low,J_p_up,1);
    
    if bool_plot(1)
        % Compare with random trajectories
        [RT1_p_low,RT1_p_up,rand_traj] = Random_traj_affine(t_init,t_final,zeros(n_x,n_p),zeros(n_x,n_p),J_x_low,J_x_up,J_p_low,J_p_up,1,sample_number);
        plot_dimensions = Subplot_ind(numel(S_p_RT_low));
        for i = 1:size(plot_dimensions,1)
            if ~isequal(S_p_RT_low(plot_dimensions(i,:)),S_p_RT_up(plot_dimensions(i,:)))
                figure(i);
                hold on

                % Plot the trajectories from random initial states
                for j = 1:sample_number
                    plot(rand_traj{j}(:,plot_dimensions(i,1)),rand_traj{j}(:,plot_dimensions(i,2)),'k');
                end
                % Plot 2D over-approximation interval
                x1_low = S_p_RT_low(plot_dimensions(i,1));
                x1_up = S_p_RT_up(plot_dimensions(i,1));
                x2_low = S_p_RT_low(plot_dimensions(i,2));
                x2_up = S_p_RT_up(plot_dimensions(i,2));
                plot([x1_low, x1_low, x1_up, x1_up, x1_low],[x2_low, x2_up, x2_up, x2_low, x2_low],'r')
                plot([x1_low, x1_low, x1_up, x1_up, x1_low],[x2_low, x2_up, x2_up, x2_low, x2_low],'r*')
            end
        end
        assert(all(S_p_RT_low(:)<=RT1_p_low(:) & S_p_RT_up(:)>=RT1_p_up(:)),'First-order reachable tube does not contain sample trajectories')
        pause
        close all
    end
end

toc

%% Over-approximate the reachable SET for second-order sensitivities
% using interval arithmetics
fprintf('\nOver-approximation of the reachable set of the second-order sensitivities ...\n')
tic

% Sensitivity with respect to initial states twice
if needed_sensitivies ~= 2
    [temp1_LB,temp1_UB] = rstp_ia(J_xx_low,J_xx_up,S_x_RT_low,S_x_RT_up);                           % J_xx*S_x with right STP
    [temp2_LB,temp2_UB] = stp_ia(temp1_LB,temp1_UB,S_x_RT_low,S_x_RT_up);                           % (J_xx*S_x)*S_x with left STP
    [S_xx_low,S_xx_up] = Affine_interval_system_reachability(t_init,t_final,zeros(n_x,n_x^2),zeros(n_x,n_x^2),J_x_low,J_x_up,temp2_LB,temp2_UB,0);
    
    if bool_plot(2)
        % Compare with random trajectories
        [RS2_xx_low,RS2_xx_up,rand_succ] = Random_traj_affine(t_init,t_final,zeros(n_x,n_x^2),zeros(n_x,n_x^2),J_x_low,J_x_up,temp2_LB,temp2_UB,0,sample_number);
        plot_dimensions = Subplot_ind(numel(S_xx_low));
        for i = 1:size(plot_dimensions,1)
            if ~isequal(S_xx_low(plot_dimensions(i,:)),S_xx_up(plot_dimensions(i,:)))
                figure(i);
                hold on

                % Plot the trajectories from random initial states
                for j = 1:sample_number
                    plot(rand_succ(plot_dimensions(i,1),j),rand_succ(plot_dimensions(i,2),j),'k.');
                end
                % Plot 2D over-approximation interval
                x1_low = S_xx_low(plot_dimensions(i,1));
                x1_up = S_xx_up(plot_dimensions(i,1));
                x2_low = S_xx_low(plot_dimensions(i,2));
                x2_up = S_xx_up(plot_dimensions(i,2));
                plot([x1_low, x1_low, x1_up, x1_up, x1_low],[x2_low, x2_up, x2_up, x2_low, x2_low],'r')
                plot([x1_low, x1_low, x1_up, x1_up, x1_low],[x2_low, x2_up, x2_up, x2_low, x2_low],'r*')
            end
        end
        assert(all(S_xx_low(:)<=RS2_xx_low(:) & S_xx_up(:)>=RS2_xx_up(:)),'Second-order reachable set does not contain sample successors')
        pause
        close all
    end
end

% Sensitivity with respect to initial states then inputs
if needed_sensitivies == 0
    [temp1_LB,temp1_UB] = rstp_ia(J_xx_low,J_xx_up,S_p_RT_low,S_p_RT_up);                   % J_xx*S_p with right STP
    [temp2_LB,temp2_UB] = Interval_matrix_sum(temp1_LB,temp1_UB,J_xp_low,J_xp_up);          % J_xx*S_p + J_xp
    [temp3_LB,temp3_UB] = stp_ia(temp2_LB,temp2_UB,S_x_RT_low,S_x_RT_up);                   % (J_xx*S_p + J_xp)*S_x with left STP
    [S_xp_low,S_xp_up] = Affine_interval_system_reachability(t_init,t_final,zeros(n_x,n_x*n_p),zeros(n_x,n_x*n_p),J_x_low,J_x_up,temp3_LB,temp3_UB,0);
    
    if bool_plot(2)
        % Compare with random trajectories
        [RS2_xp_low,RS2_xp_up,rand_succ] = Random_traj_affine(t_init,t_final,zeros(n_x,n_x*n_p),zeros(n_x,n_x*n_p),J_x_low,J_x_up,temp3_LB,temp3_UB,0,sample_number);
        plot_dimensions = Subplot_ind(numel(S_xp_low));
        for i = 1:size(plot_dimensions,1)
            if ~isequal(S_xp_low(plot_dimensions(i,:)),S_xp_up(plot_dimensions(i,:)))
                figure(i);
                hold on

                % Plot the trajectories from random initial states
                for j = 1:sample_number
                    plot(rand_succ(plot_dimensions(i,1),j),rand_succ(plot_dimensions(i,2),j),'k.');
                end
                % Plot 2D over-approximation interval
                x1_low = S_xp_low(plot_dimensions(i,1));
                x1_up = S_xp_up(plot_dimensions(i,1));
                x2_low = S_xp_low(plot_dimensions(i,2));
                x2_up = S_xp_up(plot_dimensions(i,2));
                plot([x1_low, x1_low, x1_up, x1_up, x1_low],[x2_low, x2_up, x2_up, x2_low, x2_low],'r')
                plot([x1_low, x1_low, x1_up, x1_up, x1_low],[x2_low, x2_up, x2_up, x2_low, x2_low],'r*')
            end
        end
        assert(all(S_xp_low(:)<=RS2_xp_low(:) & S_xp_up(:)>=RS2_xp_up(:)),'Second-order reachable set does not contain sample successors')
        pause
        close all
    end
end

% Sensitivity with respect to inputs twice
if needed_sensitivies ~= 1
    [temp1_LB,temp1_UB] = rstp_ia(J_xx_low,J_xx_up,S_p_RT_low,S_p_RT_up);                   % J_xx*S_p with right STP
    [temp2_LB,temp2_UB] = Interval_matrix_sum(temp1_LB,temp1_UB,J_xp_low,J_xp_up);          % J_xx*S_p + J_xp
    [temp3_LB,temp3_UB] = stp_ia(temp2_LB,temp2_UB,S_p_RT_low,S_p_RT_up);                   % (J_xx*S_p + J_xp)*S_p with left STP
    [temp4_LB,temp4_UB] = rstp_ia(J_px_low,J_px_up,S_p_RT_low,S_p_RT_up);                   % J_px*S_p with right STP
    [temp5_LB,temp5_UB] = Interval_matrix_sum(temp4_LB,temp4_UB,J_pp_low,J_pp_up);          % J_px*S_p + J_pp
    [temp6_LB,temp6_UB] = Interval_matrix_sum(temp3_LB,temp3_UB,temp5_LB,temp5_UB);         % (J_xx*S_p + J_xp)*S_p + J_px*S_p + J_pp
    [S_pp_low,S_pp_up] = Affine_interval_system_reachability(t_init,t_final,zeros(n_x,n_p^2),zeros(n_x,n_p^2),J_x_low,J_x_up,temp6_LB,temp6_UB,0);
    
    if bool_plot(2)
        % Compare with random trajectories
        [RS2_pp_low,RS2_pp_up,rand_succ] = Random_traj_affine(t_init,t_final,zeros(n_x,n_p^2),zeros(n_x,n_p^2),J_x_low,J_x_up,temp6_LB,temp6_UB,0,sample_number);
        plot_dimensions = Subplot_ind(numel(S_pp_low));
        for i = 1:size(plot_dimensions,1)
            if ~isequal(S_pp_low(plot_dimensions(i,:)),S_pp_up(plot_dimensions(i,:)))
                figure(i);
                hold on

                % Plot the trajectories from random initial states
                for j = 1:sample_number
                    plot(rand_succ(plot_dimensions(i,1),j),rand_succ(plot_dimensions(i,2),j),'k.');
                end
                % Plot 2D over-approximation interval
                x1_low = S_pp_low(plot_dimensions(i,1));
                x1_up = S_pp_up(plot_dimensions(i,1));
                x2_low = S_pp_low(plot_dimensions(i,2));
                x2_up = S_pp_up(plot_dimensions(i,2));
                plot([x1_low, x1_low, x1_up, x1_up, x1_low],[x2_low, x2_up, x2_up, x2_low, x2_low],'r')
                plot([x1_low, x1_low, x1_up, x1_up, x1_low],[x2_low, x2_up, x2_up, x2_low, x2_low],'r*')
            end
        end
        assert(all(S_pp_low(:)<=RS2_pp_low(:) & S_pp_up(:)>=RS2_pp_up(:)),'Second-order reachable set does not contain sample successors')
        pause
        close all
    end
end

% Sensitivity with respect to inputs then initial states
if needed_sensitivies == 0
    [temp1_LB,temp1_UB] = rstp_ia(J_xx_low,J_xx_up,S_x_RT_low,S_x_RT_up);                           % J_xx*S_x with right STP
    [temp2_LB,temp2_UB] = stp_ia(temp1_LB,temp1_UB,S_p_RT_low,S_p_RT_up);                           % (J_xx*S_x)*S_p with left STP
    [temp3_LB,temp3_UB] = rstp_ia(J_px_low,J_px_up,S_x_RT_low,S_x_RT_up);                           % J_px*S_x with right STP
    [temp4_LB,temp4_UB] = Interval_matrix_sum(temp2_LB,temp2_UB,temp3_LB,temp3_UB);                 % (J_xx*S_x)*S_p + J_px*S_x
    [S_px_low,S_px_up] = Affine_interval_system_reachability(t_init,t_final,zeros(n_x,n_x*n_p),zeros(n_x,n_x*n_p),J_x_low,J_x_up,temp4_LB,temp4_UB,0);
    
    if bool_plot(2)
        % Compare with random trajectories
        [RS2_px_low,RS2_px_up,rand_succ] = Random_traj_affine(t_init,t_final,zeros(n_x,n_x*n_p),zeros(n_x,n_x*n_p),J_x_low,J_x_up,temp4_LB,temp4_UB,0,sample_number);
        plot_dimensions = Subplot_ind(numel(S_px_low));
        for i = 1:size(plot_dimensions,1)
            if ~isequal(S_px_low(plot_dimensions(i,:)),S_px_up(plot_dimensions(i,:)))
                figure(i);
                hold on

                % Plot the trajectories from random initial states
                for j = 1:sample_number
                    plot(rand_succ(plot_dimensions(i,1),j),rand_succ(plot_dimensions(i,2),j),'k.');
                end
                % Plot 2D over-approximation interval
                x1_low = S_px_low(plot_dimensions(i,1));
                x1_up = S_px_up(plot_dimensions(i,1));
                x2_low = S_px_low(plot_dimensions(i,2));
                x2_up = S_px_up(plot_dimensions(i,2));
                plot([x1_low, x1_low, x1_up, x1_up, x1_low],[x2_low, x2_up, x2_up, x2_low, x2_low],'r')
                plot([x1_low, x1_low, x1_up, x1_up, x1_low],[x2_low, x2_up, x2_up, x2_low, x2_low],'r*')
            end
        end
        assert(all(S_px_low(:)<=RS2_px_low(:) & S_px_up(:)>=RS2_px_up(:)),'Second-order reachable set does not contain sample successors')
        pause
        close all
    end
end

toc

%% Over-approximate the reachable SET for first-order sensitivities
% by evaluating the first-order sensitivities for a few samples of the
% initial states and inputs, then using the bounds on the second-order
% sensitivities to obtained guaranteed bounds on the first-order ones.
fprintf('\nOver-approximation of the reachable set of the first-order sensitivities ...\n')
tic

% Number of samples per dimension
% sensi_sampling_number_x = 2*ones(n_x,1);
% sensi_sampling_number_p = 2*ones(n_p,1);
sensi_sampling_total = prod(sensi_sampling_number_x)*prod(sensi_sampling_number_p);

% Convert sample indices to subscripts on each dimension
x0_subscripts = cell(n_x,1);
[x0_subscripts{:}] = ind2sub(sensi_sampling_number_x',1:prod(sensi_sampling_number_x));
x0_subscripts = cell2mat(x0_subscripts);
p_subscripts = cell(n_p,1);
[p_subscripts{:}] = ind2sub(sensi_sampling_number_p',1:prod(sensi_sampling_number_p));
p_subscripts = cell2mat(p_subscripts);

% Compute componentwise dispersion for a uniform grid
%   the step between two samples is twice the dispersion
dispersion_x = (x_up-x_low)./(sensi_sampling_number_x*2);
dispersion_p = (p_up-p_low)./(sensi_sampling_number_p*2);

% Evaluate the first-order sensitivities
S_x_samples = NaN(n_x^2,sensi_sampling_total);
S_p_samples = NaN(n_x*n_p,sensi_sampling_total);
for x0_ind = 1:prod(sensi_sampling_number_x)
    x0_samples = x_low + dispersion_x + 2*dispersion_x.*(x0_subscripts(:,x0_ind)-1);
    for p_ind = 1:prod(sensi_sampling_number_p)
        p_samples = p_low + dispersion_p + 2*dispersion_p.*(p_subscripts(:,p_ind)-1);
        i = sub2ind([prod(sensi_sampling_number_x) prod(sensi_sampling_number_p)],x0_ind,p_ind);

        % Compute corresponding sensitivity values
        [S_x,S_p] = Sensitivity_solver(t_init,t_final,x0_samples,p_samples,needed_sensitivies,sampling_sensitivity_solver);
        S_x_samples(:,i) = S_x(:);
        S_p_samples(:,i) = S_p(:);
    end
end

% Convert to scalar dispersion and then form vectors
dispersion_x = ones(n_x,1)*norm(dispersion_x,Inf);
dispersion_p = ones(n_p,1)*norm(dispersion_p,Inf);


% Get the extrema of the sensitivitiy evaluations
S_x_sample_min = reshape(min(S_x_samples,[],2),n_x,n_x);
S_x_sample_max = reshape(max(S_x_samples,[],2),n_x,n_x);
S_p_sample_min = reshape(min(S_p_samples,[],2),n_x,n_p);
S_p_sample_max = reshape(max(S_p_samples,[],2),n_x,n_p);

if bool_plot(3) || bool_plot(4)
    % Compare with IA method applied to the first-order reachable set directly
    [S_x_IA_low,S_x_IA_up,S_p_IA_low,S_p_IA_up] = Sensitivity_interval_arithmetics(t_init,t_final,x_low,x_up,p_low,p_up,J_x_low,J_x_up,J_p_low,J_p_up);
end

% First-order sensitivity with respect to initial states
if needed_sensitivies ~= 2
    S_x_low = S_x_sample_min - rstp(max(abs(S_xx_low),abs(S_xx_up)),dispersion_x) - rstp(max(abs(S_xp_low),abs(S_xp_up)),dispersion_p);
    S_x_up = S_x_sample_max + rstp(max(abs(S_xx_low),abs(S_xx_up)),dispersion_x) + rstp(max(abs(S_xp_low),abs(S_xp_up)),dispersion_p);

    if bool_plot(3)
        % Compare with random trajectories
        [RS_Sx_LB,RS_Sx_UB,~,~,rand_Sx,~] = Random_traj_sensi(t_init,t_final,x_low,x_up,p_low,p_up,sample_number,needed_sensitivies);
        plot_dimensions = Subplot_ind(numel(S_x_low));
        for i = 1:size(plot_dimensions,1)
            figure(i);
            hold on

            % Plot the trajectories from random initial states
            for j = 1:sample_number
                plot(rand_Sx(plot_dimensions(i,1),j),rand_Sx(plot_dimensions(i,2),j),'k.');
            end
            % Plot 2D over-approximation interval
            x1_low = S_x_low(plot_dimensions(i,1));
            x1_up = S_x_up(plot_dimensions(i,1));
            x2_low = S_x_low(plot_dimensions(i,2));
            x2_up = S_x_up(plot_dimensions(i,2));
            plot([x1_low, x1_low, x1_up, x1_up, x1_low],[x2_low, x2_up, x2_up, x2_low, x2_low],'r')
            plot([x1_low, x1_low, x1_up, x1_up, x1_low],[x2_low, x2_up, x2_up, x2_low, x2_low],'r*')
            % Plot 2D over-approximation interval for IA method
            x1_low = S_x_IA_low(plot_dimensions(i,1));
            x1_up = S_x_IA_up(plot_dimensions(i,1));
            x2_low = S_x_IA_low(plot_dimensions(i,2));
            x2_up = S_x_IA_up(plot_dimensions(i,2));
            plot([x1_low, x1_low, x1_up, x1_up, x1_low],[x2_low, x2_up, x2_up, x2_low, x2_low],'b')
            plot([x1_low, x1_low, x1_up, x1_up, x1_low],[x2_low, x2_up, x2_up, x2_low, x2_low],'b*')
        end
%         assert(all(S_x_low(:)<=RS_Sx_LB(:) & S_x_up(:)>=RS_Sx_UB(:)),'First-order reachable set does not contain sample successors')
        pause
        close all
    end
end

% First-order sensitivity with respect to inputs
if needed_sensitivies ~= 1
    S_p_low = S_p_sample_min - rstp(max(abs(S_px_low),abs(S_px_up)),dispersion_x) - rstp(max(abs(S_pp_low),abs(S_pp_up)),dispersion_p);
    S_p_up = S_p_sample_max + rstp(max(abs(S_px_low),abs(S_px_up)),dispersion_x) + rstp(max(abs(S_pp_low),abs(S_pp_up)),dispersion_p);
        
    if bool_plot(3)
        % Compare with random trajectories
        [~,~,RS_Sp_LB,RS_Sp_UB,~,rand_Sp] = Random_traj_sensi(t_init,t_final,x_low,x_up,p_low,p_up,sample_number,needed_sensitivies);
        plot_dimensions = Subplot_ind(numel(S_p_low));
        for i = 1:size(plot_dimensions,1)
            figure(i);
            hold on

            % Plot the trajectories from random initial states
            for j = 1:sample_number
                plot(rand_Sp(plot_dimensions(i,1),j),rand_Sp(plot_dimensions(i,2),j),'k.');
            end
            % Plot 2D over-approximation interval
            x1_low = S_p_low(plot_dimensions(i,1));
            x1_up = S_p_up(plot_dimensions(i,1));
            x2_low = S_p_low(plot_dimensions(i,2));
            x2_up = S_p_up(plot_dimensions(i,2));
            plot([x1_low, x1_low, x1_up, x1_up, x1_low],[x2_low, x2_up, x2_up, x2_low, x2_low],'r')
            plot([x1_low, x1_low, x1_up, x1_up, x1_low],[x2_low, x2_up, x2_up, x2_low, x2_low],'r*')
            % Plot 2D over-approximation interval for IA method
            x1_low = S_p_IA_low(plot_dimensions(i,1));
            x1_up = S_p_IA_up(plot_dimensions(i,1));
            x2_low = S_p_IA_low(plot_dimensions(i,2));
            x2_up = S_p_IA_up(plot_dimensions(i,2));
            plot([x1_low, x1_low, x1_up, x1_up, x1_low],[x2_low, x2_up, x2_up, x2_low, x2_low],'b')
            plot([x1_low, x1_low, x1_up, x1_up, x1_low],[x2_low, x2_up, x2_up, x2_low, x2_low],'b*')
        end
%         assert(all(S_p_low(:)<=RS_Sp_LB(:) & S_p_up(:)>=RS_Sp_UB(:)),'First-order reachable set does not contain sample successors')
        pause
        close all
    end
end

toc

%% Sample-Data Mixed-Monotoniticy over-approximation of the reachable set
fprintf('\nOver-approximation of the reachable set of the initial system ...\n')
tic

% Reachable set over-approximations using the sensitivity bounds obtained
% from the new 3-step method
[succ_low,succ_up] = OA_4_CT_Sampled_data_MM(t_init,t_final,x_low,x_up,p_low,p_up,S_x_low,S_x_up,S_p_low,S_p_up);

if bool_plot(4)
    % Reachable set over-approximations using the sensitivity bounds obtained
    % from the old 1-step interval arithmetics method
    [succ_IA_low,succ_IA_up] = OA_4_CT_Sampled_data_MM(t_init,t_final,x_low,x_up,p_low,p_up,S_x_IA_low,S_x_IA_up,S_p_IA_low,S_p_IA_up);

    % Compute random trajectories
    [RS_LB,RS_UB,RT_LB,RT_UB,rand_traj] = Random_traj_nonlinear(t_init,t_final,x_low,x_up,p_low,p_up,sample_number);

    % Plot results
    plot_dimensions = Subplot_ind(n_x);
    for i = 1:size(plot_dimensions,1)
        figure(i);
        hold on
        % Plot the successors from random initial states
        for j = 1:sample_number
            plot(rand_traj{j}(end,plot_dimensions(i,1)),rand_traj{j}(end,plot_dimensions(i,2)),'k.');
        end
        % Plot 2D over-approximation interval
        x1_low = succ_low(plot_dimensions(i,1));
        x1_up = succ_up(plot_dimensions(i,1));
        x2_low = succ_low(plot_dimensions(i,2));
        x2_up = succ_up(plot_dimensions(i,2));
        plot([x1_low, x1_low, x1_up, x1_up, x1_low],[x2_low, x2_up, x2_up, x2_low, x2_low],'r')
        plot([x1_low, x1_low, x1_up, x1_up, x1_low],[x2_low, x2_up, x2_up, x2_low, x2_low],'r*')
        % Plot 2D over-approximation interval for IA method
        x1_low = succ_IA_low(plot_dimensions(i,1));
        x1_up = succ_IA_up(plot_dimensions(i,1));
        x2_low = succ_IA_low(plot_dimensions(i,2));
        x2_up = succ_IA_up(plot_dimensions(i,2));
        plot([x1_low, x1_low, x1_up, x1_up, x1_low],[x2_low, x2_up, x2_up, x2_low, x2_low],'b')
        plot([x1_low, x1_low, x1_up, x1_up, x1_low],[x2_low, x2_up, x2_up, x2_low, x2_low],'b*')
    end
    pause
    close all
    assert(all(succ_low(:)<=RS_LB(:) & succ_up(:)>=RS_UB(:)),'System reachable set does not contain sample successors')

    % Compare Jacobian bounds from initial set with those from reachable tube
    [J_x_RT_low,J_x_RT_up,J_p_RT_low,J_p_RT_up] = UP_Jacobian_Bounds(t_init,t_final,RT_LB,RT_UB,p_low,p_up);
    [J_xx_RT_low,J_xx_RT_up,J_xp_RT_low,J_xp_RT_up,J_pp_RT_low,J_pp_RT_up,J_px_RT_low,J_px_RT_up] = UP_Jacobian_2ndOrder_Bounds(t_init,t_final,RT_LB,RT_UB,p_low,p_up);
    assert(all(J_x_low(:)<=J_x_RT_low(:) & J_x_up(:)>=J_x_RT_up(:)),'J_x from interval of initial states does not contain J_x from sampled reachable tube')
    assert(all(J_p_low(:)<=J_p_RT_low(:) & J_p_up(:)>=J_p_RT_up(:)),'J_p from interval of initial states does not contain J_p from sampled reachable tube')
    assert(all(J_xx_low(:)<=J_xx_RT_low(:) & J_xx_up(:)>=J_xx_RT_up(:)),'J_xx from interval of initial states does not contain J_xx from sampled reachable tube')
    assert(all(J_xp_low(:)<=J_xp_RT_low(:) & J_xp_up(:)>=J_xp_RT_up(:)),'J_xp from interval of initial states does not contain J_xp from sampled reachable tube')
    assert(all(J_pp_low(:)<=J_pp_RT_low(:) & J_pp_up(:)>=J_pp_RT_up(:)),'J_pp from interval of initial states does not contain J_pp from sampled reachable tube')
    assert(all(J_px_low(:)<=J_px_RT_low(:) & J_px_up(:)>=J_px_RT_up(:)),'J_px from interval of initial states does not contain J_px from sampled reachable tube')
end

toc

end

%% Prepare figures for plotting (x(1)-x(2), x(3)-x(4), ...)
function plot_dimensions = Subplot_ind(n)
% Only plot if the system has between 2 and 20 dimensions (ie max 10 plots)
plot_dimensions = [];
if n > 1
    % Set indices of the subplots
    if ~mod(n,2)  
        % Even number of states
        plot_dimensions = [(1:2:n)' (2:2:n)'];
    else                
        % Odd number of states
        plot_dimensions = [(1:2:n-1)' (2:2:n)';n-1 n];
    end
end
end

%% Trajectories from random sample initial states for a matrix affine system
function [RS_LB,RS_UB,rand_succ] = Random_traj_affine(t_init,t_final,X0_LB,X0_UB,A_LB,A_UB,B_LB,B_UB,bool_RT,sample_number)
[n1,n2] = size(X0_LB);
RS_LB = NaN(n1,n2);
RS_UB = NaN(n1,n2);
if bool_RT
    rand_succ = cell(sample_number,1);
else
    rand_succ = NaN(n1*n2,sample_number);
end

for i=1:sample_number
    % Random matrices and initial state within intervals
    A = A_LB + rand(n1).*(A_UB-A_LB);
    B = B_LB + rand(n1,n2).*(B_UB-B_LB);
    X0 = X0_LB + rand(n1,n2).*(X0_UB-X0_LB);
    % Solve system
    A_block = [];
    for j = 1:n2
        A_block = blkdiag(A_block,A);
    end
    B = reshape(B,n1*n2,1);
    X0 = reshape(X0,n1*n2,1);
    [x_time,x_traj] = ode45(@(t,x) A_block*x+B,[t_init,t_final],X0);
    
    if bool_RT
        rand_succ{i} = x_traj;
        % Update reachable tube
        for t=1:length(x_time)
            RS_t = reshape(x_traj(t,:)',n1,n2);
            RS_LB = min(RS_LB,RS_t);
            RS_UB = max(RS_UB,RS_t);
        end
    else
        rand_succ(:,i) = x_traj(end,:)';
        % Update reachable set
        RS = reshape(x_traj(end,:)',n1,n2);
        RS_LB = min(RS_LB,RS);
        RS_UB = max(RS_UB,RS);
    end
end
end

%% Trajectories from random sample initial states for a nonlinear system
function [RS_LB,RS_UB,RT_LB,RT_UB,rand_traj] = Random_traj_nonlinear(t_init,t_final,x_low,x_up,p_low,p_up,sample_number)
n_x = numel(x_low);
n_p = numel(p_low);
RS_LB = NaN(n_x,1);
RS_UB = NaN(n_x,1);
RT_LB = NaN(n_x,1);
RT_UB = NaN(n_x,1);

rand_traj = cell(sample_number,1);
for i = 1:sample_number
    % Random initial states and disturbances
    x0 = x_low + rand(n_x,1).*(x_up-x_low);
    p = p_low + rand(n_p,1).*(p_up-p_low);
    % Compute trajectory
    [x_time,x_traj] = ode45(@(t,x) System_description(t,x,p),[t_init t_final],x0);
    rand_traj{i} = x_traj;
    % Update reachable tube
    RS_LB = min(RS_LB,x_traj(end,:)');
    RS_UB = max(RS_UB,x_traj(end,:)');
    % Update reachable tube
    for t=1:length(x_time)
        RT_LB = min(RT_LB,x_traj(t,:)');
        RT_UB = max(RT_UB,x_traj(t,:)');
    end
end
end

%% Trajectories from random sample initial states for the first order sensitivity systems (using Euler approximation)
function [RS_Sx_LB,RS_Sx_UB,RS_Sp_LB,RS_Sp_UB,rand_Sx,rand_Sp] = Random_traj_sensi(t_init,t_final,x_low,x_up,p_low,p_up,sample_number,needed_sensitivies)
n_x = numel(x_low);
n_p = numel(p_low);
RS_Sx_LB = NaN(n_x);
RS_Sx_UB = NaN(n_x);
RS_Sp_LB = NaN(n_x,n_p);
RS_Sp_UB = NaN(n_x,n_p);
rand_Sx = NaN(n_x^2,sample_number);
rand_Sp = NaN(n_x*n_p,sample_number);

for i=1:sample_number
    % Random initial states and inputs
    x0 = x_low + rand(n_x,1).*(x_up-x_low);
    p = p_low + rand(n_p,1).*(p_up-p_low);
    
    % Solve sensitivities
    [S_x,S_p] = Sensitivity_solver(t_init,t_final,x0,p,needed_sensitivies);
    rand_Sx(:,i) = S_x(:);
    rand_Sp(:,i) = S_p(:);
    
    % Update reachable set
    RS_Sx_LB = min(RS_Sx_LB,S_x);
    RS_Sx_UB = max(RS_Sx_UB,S_x);
    RS_Sp_LB = min(RS_Sp_LB,S_p);
    RS_Sp_UB = max(RS_Sp_UB,S_p);
end
end

%% Left Semi-Tensor Product of Matrices using Kronecker product
function C = lstp(A,B)
%   lstp(A,B) is to calculate the (left) semi-tensor  product of two matrices A and B.
%   The number of columns of A must be either a divisor or a multiple of the number of rows of B.

if ~(isa(A,'sym') || isa(A,'double'))
    A = double(A);
end
if ~(isa(B,'sym') || isa(B,'double'))
    B = double(B);
end

if (ndims(A) > 2) || (ndims(B) > 2)
    error('Input arguments must be 2-D.');
end

n = size(A,2); % get the number of columns
p = size(B,1); % get the number of rows
if n == p
    C = A*B;
elseif mod(n,p) == 0
    C = A*kron(B,eye(n/p));
elseif mod(p,n) == 0
    C = kron(A,eye(p/n))*B;
else
    error('The input arguments do not meet the multiple dimension matching condition.')
end
end


%% Right Semi-Tensor Product of Matrices using Kronecker product
function C = rstp(A,B)
%   rstp(A,B) is to calculate the right semi-tensor product of two matrices A and B.
%   The number of columns of A must be either a divisor or a multiple of the number of rows of B.

if ~(isa(A,'sym') || isa(A,'double'))
    A = double(A);
end
if ~(isa(B,'sym') || isa(B,'double'))
    B = double(B);
end

if (ndims(A) > 2) || (ndims(B) > 2)
    error('Input arguments must be 2-D.');
end

n = size(A,2);
p = size(B,1);
if n == p
    C = A*B;
elseif mod(n,p) == 0
    C = A*kron(eye(n/p),B);
elseif mod(p,n) == 0
    C = kron(eye(p/n),A)*B;
else
    error('The input arguments do not meet the multiple dimension matching condition.')
end
end

%% Sum of two interval matrices A+B
% Inputs. [A_LB,A_UB], [B_LB,B_UB]: two interval matrices A and B
% Outputs. [sum_LB,sum_UB]: interval matrix for the sum A+B
function [sum_LB,sum_UB] = Interval_matrix_sum(A_LB,A_UB,B_LB,B_UB)
sum_LB = A_LB+B_LB;
sum_UB = A_UB+B_UB;
end

%% Product of two interval matrices A*B
% Inputs. [A_LB,A_UB], [B_LB,B_UB]: two interval matrices A and B
% Outputs. [prod_LB,prod_UB]: interval matrix for the product A*B
function [prod_LB,prod_UB] = Interval_matrix_product(A_LB,A_UB,B_LB,B_UB)
prod_LB = zeros(size(A_LB,1),size(B_LB,2));
prod_UB = zeros(size(A_LB,1),size(B_LB,2));
for i = 1:size(A_LB,1)  % lines of A
    for j = 1:size(B_LB,2)  % columns of B
        prod_LB(i,j) = sum(min([A_LB(i,:)'.*B_LB(:,j) A_UB(i,:)'.*B_LB(:,j) A_LB(i,:)'.*B_UB(:,j) A_UB(i,:)'.*B_UB(:,j)],[],2));
        prod_UB(i,j) = sum(max([A_LB(i,:)'.*B_LB(:,j) A_UB(i,:)'.*B_LB(:,j) A_LB(i,:)'.*B_UB(:,j) A_UB(i,:)'.*B_UB(:,j)],[],2));
    end
end
end

%% Semi-Tensor Product of two interval matrices A*B
% Inputs. [A_LB,A_UB], [B_LB,B_UB]: two interval matrices A and B
%   The number of columns of A must be either a divisor or a multiple 
%   of the number of rows of B.
% Outputs. [prod_LB,prod_UB]: interval matrix for the product A*B
%   with the (Left) Semi-Tensor Product (using its Kronecker definition)
function [prod_LB,prod_UB] = stp_ia(A_LB,A_UB,B_LB,B_UB)

% Check input size consistency
if ~isequal(size(A_LB),size(A_UB))
    error('The lower and upper bounds of the first interval matrix do not have the same dimensions')
end
if ~isequal(size(B_LB),size(B_UB))
    error('The lower and upper bounds of the second interval matrix do not have the same dimensions')
end
if (ndims(A_LB) > 2) || (ndims(B_LB) > 2)
    error('Input arguments must be 2-D matrices.');
end

n = size(A_LB,2); % get the number of columns
p = size(B_LB,1); % get the number of rows
if n == p
    [prod_LB,prod_UB] = Interval_matrix_product(A_LB,A_UB,B_LB,B_UB);
elseif mod(n,p) == 0
    z = n/p;
    [prod_LB,prod_UB] = Interval_matrix_product(A_LB,A_UB,kron(B_LB,eye(z)),kron(B_UB,eye(z)));
elseif mod(p,n) == 0
    z = p/n;
    [prod_LB,prod_UB] = Interval_matrix_product(kron(A_LB,eye(z)),kron(A_UB,eye(z)),B_LB,B_UB);
else
    error('The input arguments do not meet the multiple dimension matching condition.')
end
end

%% Right Semi-Tensor Product of two interval matrices A*B
% Inputs. [A_LB,A_UB], [B_LB,B_UB]: two interval matrices A and B
%   The number of columns of A must be either a divisor or a multiple 
%   of the number of rows of B.
% Outputs. [prod_LB,prod_UB]: interval matrix for the product A*B
%   with the (Left) Semi-Tensor Product (using its Kronecker definition)
function [prod_LB,prod_UB] = rstp_ia(A_LB,A_UB,B_LB,B_UB)

% Check input size consistency
if ~isequal(size(A_LB),size(A_UB))
    error('The lower and upper bounds of the first interval matrix do not have the same dimensions')
end
if ~isequal(size(B_LB),size(B_UB))
    error('The lower and upper bounds of the second interval matrix do not have the same dimensions')
end
if (ndims(A_LB) > 2) || (ndims(B_LB) > 2)
    error('Input arguments must be 2-D matrices.');
end

n = size(A_LB,2); % get the number of columns
p = size(B_LB,1); % get the number of rows
if n == p
    [prod_LB,prod_UB] = Interval_matrix_product(A_LB,A_UB,B_LB,B_UB);
elseif mod(n,p) == 0
    z = n/p;
    [prod_LB,prod_UB] = Interval_matrix_product(A_LB,A_UB,kron(eye(z),B_LB),kron(eye(z),B_UB));
elseif mod(p,n) == 0
    z = p/n;
    [prod_LB,prod_UB] = Interval_matrix_product(kron(eye(z),A_LB),kron(eye(z),A_UB),B_LB,B_UB);
else
    error('The input arguments do not meet the multiple dimension matching condition.')
end
end
