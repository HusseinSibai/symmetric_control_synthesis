function Call_CDC2019()
%% Test file for the comparison of the 3 SDMM reachability analysis
close all
clear
addpath(genpath('./TIRA'))  % Add access to reachability toolbox folder
addpath(genpath('./multipoly'))  % Add access to reachability toolbox folder

% Load save file
% load('./Saves/Ship_abstraction8.mat','Controller','U_discrete','sym_x','time_step')
load('./Saves/Ship_abstraction9.mat','Controller','U_discrete','sym_x','time_step')
Controller = full(Controller);

% Load internal feedback from SOS
load('SOS_outputs.mat','e1lbval','e1ubval','e2lbval','e2ubval','e3lbval','e3ubval','e4lbval','e4ubval','e5lbval','e5ubval','e6lbval','e6ubval','Vval','err','gamma_list','kval','uhat')

%% Initialization

% State spaces
%   N/E for camera range: 10*6.5m
%   orientation range [-pi,pi] ; psi=0 is pointing North
%   surge velocity: [-0.18,0.18]m/s
%   sway velocity: [-0.1,0.1]m/s
%   yaw rate: [-0.1,0.1]rad/s
X_6D_up = [10;6.5;pi;0.18;0.1;0.1];
X_6D_low = [0;0;-pi;-0.18;-0.1;-0.1];
X_3D_up = X_6D_up(1:3);
X_3D_low = X_6D_low(1:3);

% Input spaces
U_3D_up = X_6D_up(4:6);
U_3D_low = X_6D_low(4:6);

% Disturbance spaces (no disturbance for now)
W_3D_up = [0.0183;0.0183;0.0183];
W_3D_low = -W_3D_up;
% W_3D_up = zeros(3,1);
% W_3D_low = zeros(3,1);

% Error bounds induced by the model reduction
error_6D_up = [e1ubval;e2ubval;e3ubval;e4ubval;e5ubval;e6ubval];
error_6D_low = [e1lbval;e2lbval;e3lbval;e4lbval;e5lbval;e6lbval];
error_6D = max(abs(error_6D_low),abs(error_6D_up));

% Shrunk 3D state space
X_3D_shrunk_up = X_3D_up - error_6D(1:3);
X_3D_shrunk_low = X_3D_low + error_6D(1:3);
step_3D = (X_3D_shrunk_up-X_3D_shrunk_low)./sym_x;

% Select random 3D symbol as initial set
s_3D = [randi(sym_x(1));randi(sym_x(2));randi(sym_x(3))];
x_up = X_3D_shrunk_low + step_3D.*s_3D;
x_low = x_up - step_3D;
n_x = length(x_up);

% Select random control input
u = U_3D_low + rand(3,1).*(U_3D_up-U_3D_low);
p_up = [u;W_3D_up];
p_low = [u;W_3D_low];
n_p = length(p_up);

% Time interval
t_init = 0;         % Initial time
t_final = time_step;        % Final time
        
% Sampling number
sample_number = 500;

%% New method using second-order sensitivity to bound the first-order sensitivity (with 3 different sampling grids)
Sx_sampling = repmat(1:3,n_x,1);
for i=1:n_x
    if x_low(i) == x_up(i)
        Sx_sampling(i,:) = 1;
    end
end
Sp_sampling = repmat(1:3,n_p,1);
for i=1:n_p
    if p_low(i) == p_up(i)
        Sp_sampling(i,:) = 1;
    end
end

tic1 = tic;
[succ_low1,succ_up1,S_x_low1,S_x_up1,S_p_low1,S_p_up1] = Reachability_call_scalar_disp(t_init,t_final,x_low,x_up,p_low,p_up,Sx_sampling(:,1),Sp_sampling(:,1));
toc(tic1)

tic2 = tic;
[succ_low2,succ_up2,S_x_low2,S_x_up2,S_p_low2,S_p_up2] = Reachability_call_scalar_disp(t_init,t_final,x_low,x_up,p_low,p_up,Sx_sampling(:,2),Sp_sampling(:,2));
toc(tic2)

tic3 = tic;
[succ_low3,succ_up3,S_x_low3,S_x_up3,S_p_low3,S_p_up3] = Reachability_call_scalar_disp(t_init,t_final,x_low,x_up,p_low,p_up,Sx_sampling(:,3),Sp_sampling(:,3));
toc(tic3)

%% One-step interval arithmetics methods
fprintf('\nOne-step interval arithmetics methods ...\n')
tic
% First-order Jacobians
[J_x_low,J_x_up,J_p_low,J_p_up] = UP_Jacobian_Bounds(t_init,t_final,x_low,x_up,p_low,p_up);
% Sensitivity bounds
[S_x_IA_low,S_x_IA_up,S_p_IA_low,S_p_IA_up] = Sensitivity_interval_arithmetics(t_init,t_final,x_low,x_up,p_low,p_up,J_x_low,J_x_up,J_p_low,J_p_up);
% Reachable set bounds
[succ_IA_low,succ_IA_up] = OA_4_CT_Sampled_data_MM(t_init,t_final,x_low,x_up,p_low,p_up,S_x_IA_low,S_x_IA_up,S_p_IA_low,S_p_IA_up);
toc

%% Sampling and falsification method
fprintf('\nSampling and falsification method ...\n')
tic
% Sampling
[S_x_SF_low,S_x_SF_up,S_p_SF_low,S_p_SF_up] = Sensitivity_sampling(t_init,t_final,x_low,x_up,p_low,p_up,0);
% Falsification
[S_x_SF_low,S_x_SF_up,S_p_SF_low,S_p_SF_up] = Sensitivity_falsification(t_init,t_final,x_low,x_up,p_low,p_up,S_x_SF_low,S_x_SF_up,S_p_SF_low,S_p_SF_up,0);
% Reachable set
[succ_SF_low,succ_SF_up] = OA_4_CT_Sampled_data_MM(t_init,t_final,x_low,x_up,p_low,p_up,S_x_SF_low,S_x_SF_up,S_p_SF_low,S_p_SF_up);
toc

%% Continuous-time mixed-monotonicity
fprintf('\nContinuous-time mixed-monotonicity ...\n')
tic
% First-order Jacobians
[J_x_low,J_x_up,J_p_low,J_p_up] = UP_Jacobian_Bounds(t_init,t_final,x_low,x_up,p_low,p_up);
% Reachable set bounds
[succ_CT_low,succ_CT_up] = OA_3_CT_Mixed_Monotonicity2(t_init,t_final,x_low,x_up,p_low,p_up,J_x_low,J_x_up,J_p_low,J_p_up);
toc

%% Compare sensitivity bounds

% Plotting parameters
method_names = {'Algorithm 1, N=1','Algorithm 1, N=2^n','Algorithm 1, N=3^n','Interval arithmetics from [11]','Sampling and falsification from [11]','CTMM'};
cs = {[228,26,28]/255, [55,126,184]/255, [77,175,74]/255,...
      [152,78,163]/255, [255,127,0]/255, [255,255,51]/255, [166,86,40]/255};
lss = {'--','-.','-',':','--','-.','-'};

% if needed_sensitivies~=2
%     % Compare with random trajectories
%     [~,~,~,~,rand_Sx,~] = Random_traj_sensi(t_init,t_final,x_low,x_up,p_low,p_up,sample_number,needed_sensitivies);
%     plot_dimensions = Subplot_ind(numel(S_x_low1));
%     for i = 1:size(plot_dimensions,1)
%         figure(i);
%         hold on
% 
%         % Plot the trajectories from random initial states
%         for j = 1:sample_number
%             plot(rand_Sx(plot_dimensions(i,1),j),rand_Sx(plot_dimensions(i,2),j),'k.');
%         end
% 
%         % Plot the over-approximations
%         OA_rect_handles = NaN(1, 5);
%         for method = 1:5
%             switch method
%                 case 1
%                     S_x_low = S_x_low1;
%                     S_x_up = S_x_up1;
%                 case 2
%                     S_x_low = S_x_low2;
%                     S_x_up = S_x_up2;
%                 case 3
%                     S_x_low = S_x_low3;
%                     S_x_up = S_x_up3;
%                 case 4
%                     S_x_low = S_x_IA_low;
%                     S_x_up = S_x_IA_up;
%                 case 5
%                     S_x_low = S_x_SF_low;
%                     S_x_up = S_x_SF_up;
%             end
%             % Plot 2D over-approximation interval for SF method
%             x1_low = S_x_low(plot_dimensions(i,1));
%             x1_up = S_x_up(plot_dimensions(i,1));
%             x2_low = S_x_low(plot_dimensions(i,2));
%             x2_up = S_x_up(plot_dimensions(i,2));
%             OA_rect_handles(method) = plot([x1_low, x1_low, x1_up, x1_up, x1_low], ...
%                                   [x2_low, x2_up, x2_up, x2_low, x2_low], ...
%                                   'DisplayName',method_names{method}, ...
%                                   'linewidth', 2,...
%                                   'linestyle',lss{method}, ... 
%                                   'color', cs{method});
%         end
%         legend(OA_rect_handles)
%         
%         % Add label
%         if i==4
%             xlabel('S^x_{1,3}','FontSize',14,'FontWeight','bold')
%             ylabel('S^x_{2,3}','FontSize',14,'FontWeight','bold')
%         end
%     end
%     pause
%     close all
% end
% 
% if needed_sensitivies~=1
%     % Compare with random trajectories
%     [~,~,~,~,~,rand_Sp] = Random_traj_sensi(t_init,t_final,x_low,x_up,p_low,p_up,sample_number,needed_sensitivies);
%     plot_dimensions = Subplot_ind(numel(S_p_low1));
%     for i = 1:size(plot_dimensions,1)
%         figure(i);
%         hold on
% 
%         % Plot the trajectories from random initial states
%         for j = 1:sample_number
%             plot(rand_Sp(plot_dimensions(i,1),j),rand_Sp(plot_dimensions(i,2),j),'k.');
%         end
%         
%         % Plot the over-approximations
%         OA_rect_handles = NaN(1, 5);
%         for method = 1:5
%             switch method
%                 case 1
%                     S_p_low = S_p_low1;
%                     S_p_up = S_p_up1;
%                 case 2
%                     S_p_low = S_p_low2;
%                     S_p_up = S_p_up2;
%                 case 3
%                     S_p_low = S_p_low3;
%                     S_p_up = S_p_up3;
%                 case 4
%                     S_p_low = S_p_IA_low;
%                     S_p_up = S_p_IA_up;
%                 case 5
%                     S_p_low = S_p_SF_low;
%                     S_p_up = S_p_SF_up;
%             end
%             % Plot 2D over-approximation interval for SF method
%             x1_low = S_p_low(plot_dimensions(i,1));
%             x1_up = S_p_up(plot_dimensions(i,1));
%             x2_low = S_p_low(plot_dimensions(i,2));
%             x2_up = S_p_up(plot_dimensions(i,2));
%             OA_rect_handles(method) = plot([x1_low, x1_low, x1_up, x1_up, x1_low], ...
%                                   [x2_low, x2_up, x2_up, x2_low, x2_low], ...
%                                   'DisplayName',method_names{method}, ...
%                                   'linewidth', 2,...
%                                   'linestyle',lss{method}, ... 
%                                   'color', cs{method});
%         end
%         legend(OA_rect_handles)
%     end
%     pause
%     close all
% end

%% Compare reachable set bounds

% Compute random trajectories
[~,~,~,~,rand_traj] = Random_traj_nonlinear(t_init,t_final,x_low,x_up,p_low,p_up,sample_number);

% Plot results
plot_dimensions = Subplot_ind(n_x);
for i = 1:size(plot_dimensions,1)
    figure(i);
    hold on
    % Plot the successors from random initial states
    for j = 1:sample_number
        plot(rand_traj{j}(end,plot_dimensions(i,1)),rand_traj{j}(end,plot_dimensions(i,2)),'k.');
    end
    
    % Plot the over-approximations
    OA_rect_handles = NaN(1, 6);
    for method = 1:6
        switch method
            case 1
                succ_low = succ_low1;
                succ_up = succ_up1;
            case 2
                succ_low = succ_low2;
                succ_up = succ_up2;
            case 3
                succ_low = succ_low3;
                succ_up = succ_up3;
            case 4
                succ_low = succ_IA_low;
                succ_up = succ_IA_up;
            case 5
                succ_low = succ_SF_low;
                succ_up = succ_SF_up;
            case 6
                succ_low = succ_CT_low;
                succ_up = succ_CT_up;
        end
        % Plot 2D over-approximation interval for SF method
        x1_low = succ_low(plot_dimensions(i,1));
        x1_up = succ_up(plot_dimensions(i,1));
        x2_low = succ_low(plot_dimensions(i,2));
        x2_up = succ_up(plot_dimensions(i,2));
        OA_rect_handles(method) = plot([x1_low, x1_low, x1_up, x1_up, x1_low], ...
                              [x2_low, x2_up, x2_up, x2_low, x2_low], ...
                              'DisplayName',method_names{method}, ...
                              'linewidth', 2,...
                              'linestyle',lss{method}, ... 
                              'color', cs{method});
    end
    legend(OA_rect_handles)

    % Add label
    if i==1
        xlabel('x_1','FontSize',14,'FontWeight','bold')
        ylabel('x_2','FontSize',14,'FontWeight','bold')
    else
        xlabel('x_2','FontSize',14,'FontWeight','bold')
        ylabel('x_3','FontSize',14,'FontWeight','bold')
    end
end

end

%% Trajectories from random sample initial states for a nonlinear system
function [RS_LB,RS_UB,RT_LB,RT_UB,rand_traj] = Random_traj_nonlinear(t_init,t_final,x_low,x_up,p_low,p_up,sample_number)
n_x = numel(x_low);
n_p = numel(p_low);
RS_LB = NaN(n_x,1);
RS_UB = NaN(n_x,1);
RT_LB = NaN(n_x,1);
RT_UB = NaN(n_x,1);

rand_traj = cell(sample_number,1);
for i = 1:sample_number
    % Random initial states and disturbances
    x0 = x_low + rand(n_x,1).*(x_up-x_low);
    p = p_low + rand(n_p,1).*(p_up-p_low);
    % Compute trajectory
    [x_time,x_traj] = ode45(@(t,x) System_description(t,x,p),[t_init t_final],x0);
    rand_traj{i} = x_traj;
    % Update reachable tube
    RS_LB = min(RS_LB,x_traj(end,:)');
    RS_UB = max(RS_UB,x_traj(end,:)');
    % Update reachable tube
    for t=1:length(x_time)
        RT_LB = min(RT_LB,x_traj(t,:)');
        RT_UB = max(RT_UB,x_traj(t,:)');
    end
end
end

%% Trajectories from random sample initial states for the first order sensitivity systems (using Euler approximation)
function [RS_Sx_LB,RS_Sx_UB,RS_Sp_LB,RS_Sp_UB,rand_Sx,rand_Sp] = Random_traj_sensi(t_init,t_final,x_low,x_up,p_low,p_up,sample_number,needed_sensitivies)
n_x = numel(x_low);
n_p = numel(p_low);
RS_Sx_LB = NaN(n_x);
RS_Sx_UB = NaN(n_x);
RS_Sp_LB = NaN(n_x,n_p);
RS_Sp_UB = NaN(n_x,n_p);
rand_Sx = NaN(n_x^2,sample_number);
rand_Sp = NaN(n_x*n_p,sample_number);

for i=1:sample_number
    % Random initial states and inputs
    x0 = x_low + rand(n_x,1).*(x_up-x_low);
    p = p_low + rand(n_p,1).*(p_up-p_low);
    
    % Solve sensitivities
    [S_x,S_p] = Sensitivity_solver(t_init,t_final,x0,p,needed_sensitivies);
    rand_Sx(:,i) = S_x(:);
    rand_Sp(:,i) = S_p(:);
    
    % Update reachable set
    RS_Sx_LB = min(RS_Sx_LB,S_x);
    RS_Sx_UB = max(RS_Sx_UB,S_x);
    RS_Sp_LB = min(RS_Sp_LB,S_p);
    RS_Sp_UB = max(RS_Sp_UB,S_p);
end
end

%% Prepare figures for plotting (x(1)-x(2), x(3)-x(4), ...)
function plot_dimensions = Subplot_ind(n)
% Only plot if the system has between 2 and 20 dimensions (ie max 10 plots)
plot_dimensions = [];
if n > 1
    % Set indices of the subplots
    if ~mod(n,2)  
        % Even number of states
        plot_dimensions = [(1:2:n)' (2:2:n)'];
    else                
        % Odd number of states
        plot_dimensions = [(1:2:n-1)' (2:2:n)';n-1 n];
    end
end
end