%% User-provided function returning bounds on the second-order Jacobian matrices
% The user can either provider global bounds, or a function of the input
% arguments (t_init,t_final,x_low,x_up,p_low,p_up) returning local bounds
% Given the first-order Jacobian definitions:
%   J_x(t,x,p) = d(System_description(t,x,p))/dx
%   J_p(t,x,p) = d(System_description(t,x,p))/dp
% the second-order Jacobian are defined by:
%   J_xx(t,x,p) = dJ_x(t,x,p)/dx
%   J_xp(t,x,p) = dJ_x(t,x,p)/dp
%   J_pp(t,x,p) = dJ_p(t,x,p)/dp
%   J_px(t,x,p) = dJ_p(t,x,p)/dx

% List of inputs
%   t_init: initial time
%   t_final: time at which the reachable set is approximated (for continuous-time system only)
%       for discrete-time system, a dummy value can be provided
%   [x_low,x_up]: interval of initial states (at time t_init)
%   [p_low,p_up]: interval of allowed input values

% List of outputs
%   bounds of the 4 second-order Jacobians described as 2D matrices
%       [J_xx_low,J_xx_up]: of dimensions (n_x,n_x^2) 
%       [J_xp_low,J_xp_up]: of dimensions (n_x,n_x*n_p) 
%       [J_pp_low,J_pp_up]: of dimensions (n_x,n_p^2) 
%       [J_px_low,J_px_up]: of dimensions (n_x,n_x*n_p) 

% Authors:  
%   Pierre-Jean Meyer, <pjmeyer -AT- berkeley.edu>, EECS, UC Berkeley
% Date: 1st of February 2019

function [J_xx_low,J_xx_up,J_xp_low,J_xp_up,J_pp_low,J_pp_up,J_px_low,J_px_up] = UP_Jacobian_2ndOrder_Bounds(t_init,t_final,x_low,x_up,p_low,p_up)
n_x = length(x_low);
n_p  = length(p_low);

%% User-provided second-order Jacobian bounds as 3D matrices, with:
%   size(J_xx_low) = [n_x,n_x,n_x] and J_xx_low(i,j,k) = dJ_x(i,j)/d_x(k)
%   size(J_xp_low) = [n_x,n_x,n_p] and J_xp_low(i,j,k) = dJ_x(i,j)/d_p(k)
%   size(J_pp_low) = [n_x,n_p,n_p] and J_pp_low(i,j,k) = dJ_p(i,j)/d_p(k)
%   size(J_px_low) = [n_x,n_p,n_x] and J_px_low(i,j,k) = dJ_p(i,j)/d_x(k)
% These 3D matrices will be automatically converted to the appropriate 2D 
%   form at the end of this file.

% Initialization
J_xx_low = zeros(n_x,n_x,n_x);
J_xp_low = zeros(n_x,n_x,n_p);
J_pp_low = zeros(n_x,n_p,n_p);
J_px_low = zeros(n_x,n_p,n_x);
J_xx_up = zeros(n_x,n_x,n_x);
J_xp_up = zeros(n_x,n_x,n_p);
J_pp_up = zeros(n_x,n_p,n_p);
J_px_up = zeros(n_x,n_p,n_x);

%% 3D ship model with u in R^6 containing 3 controls and 3 disturbances

if isequal(p_low(1:3),p_up(1:3))
    %% Complex case based on possible orientation values
    u = p_low;
    time_step = t_final-t_init;

    % Possible orientation values over the next sampling period
    psi_low = x_low(3) + min(0,time_step*(u(3)+p_low(6)));
    psi_up = x_up(3) + max(0,time_step*(u(3)+p_up(6)));

    % Min/Max for cosine
    psi_min_cos = pi;
    if psi_low>-pi && psi_up<pi
        psi_min_cos = max(abs(psi_low),abs(psi_up));
    end
    psi_max_cos = 0;
    if (psi_low>0 || psi_up<0) && psi_up<2*pi && psi_low>-2*pi
        psi_max_cos = min(abs(mod(psi_low+pi,2*pi)-pi),abs(mod(psi_up+pi,2*pi)-pi));
    end

    % Min/Max for sine
    psi_min_sin = 3*pi/2;
    if psi_low>-pi/2 && psi_up<3*pi/2
        psi_min_sin = max(abs(psi_low-pi/2),abs(psi_up-pi/2)) + pi/2;
    end
    psi_max_sin = pi/2;
    if (psi_low>pi/2 || psi_up<pi/2) && psi_up<5*pi/2 && psi_low>-3*pi/2
        psi_max_sin = min(abs(mod(psi_low-pi/2+pi,2*pi)-pi),abs(mod(psi_up-pi/2+pi,2*pi)-pi)) + pi/2;
    end

    % Bounds of Jxx
    if u(1) > 0
        J_xx_low(1,3,3) = -u(1)*cos(psi_max_cos);
        J_xx_up(1,3,3) = -u(1)*cos(psi_min_cos);
        J_xx_low(2,3,3) = -u(1)*sin(psi_max_sin);
        J_xx_up(2,3,3) = -u(1)*sin(psi_min_sin);
    else
        J_xx_low(1,3,3) = -u(1)*cos(psi_min_cos);
        J_xx_up(1,3,3) = -u(1)*cos(psi_max_cos);
        J_xx_low(2,3,3) = -u(1)*sin(psi_min_sin);
        J_xx_up(2,3,3) = -u(1)*sin(psi_max_sin);
    end
    if u(2) > 0
        J_xx_low(1,3,3) = J_xx_low(1,3,3) + u(2)*sin(psi_min_sin);
        J_xx_up(1,3,3) = J_xx_up(1,3,3) + u(2)*sin(psi_max_sin);
        J_xx_low(2,3,3) = J_xx_low(2,3,3) - u(2)*cos(psi_max_cos);
        J_xx_up(2,3,3) = J_xx_up(2,3,3) - u(2)*cos(psi_min_cos);
    else
        J_xx_low(1,3,3) = J_xx_low(1,3,3) + u(2)*sin(psi_max_sin);
        J_xx_up(1,3,3) = J_xx_up(1,3,3) + u(2)*sin(psi_min_sin);
        J_xx_low(2,3,3) = J_xx_low(2,3,3) - u(2)*cos(psi_min_cos);
        J_xx_up(2,3,3) = J_xx_up(2,3,3) - u(2)*cos(psi_max_cos);
    end
    
    % Bounds of Jxp
    J_xp_low(1,3,1) = -sin(psi_max_sin);
    J_xp_up(1,3,1) = -sin(psi_min_sin);
    J_xp_low(1,3,2) = -cos(psi_max_cos);
    J_xp_up(1,3,2) = -cos(psi_min_cos);
    J_xp_low(2,3,1) = cos(psi_min_cos);
    J_xp_up(2,3,1) = cos(psi_max_cos);
    J_xp_low(2,3,2) = -sin(psi_max_sin);
    J_xp_up(2,3,2) = -sin(psi_min_sin);
    
    % Bounds of Jpx
    J_px_low(1,1,3) = -sin(psi_max_sin);
    J_px_up(1,1,3) = -sin(psi_min_sin);
    J_px_low(1,2,3) = -cos(psi_max_cos);
    J_px_up(1,2,3) = -cos(psi_min_cos);
    J_px_low(2,1,3) = cos(psi_min_cos);
    J_px_up(2,1,3) = cos(psi_max_cos);
    J_px_low(2,2,3) = -sin(psi_max_sin);
    J_px_up(2,2,3) = -sin(psi_min_sin);
else
    %% Simple bounds, with all cos/sin between -1 and 1

    % Bounds of Jxx
    J_xx_low(1,3,3) = min([p_low(1),-p_up(1)]) + min([p_low(2),-p_up(2)]);
    J_xx_low(2,3,3) = min([p_low(1),-p_up(1)]) + min([p_low(2),-p_up(2)]);
    J_xx_up(1,3) = max([p_up(1),-p_low(1)]) + max([p_up(2),-p_low(2)]);
    J_xx_up(2,3) = max([p_up(1),-p_low(1)]) + max([p_up(2),-p_low(2)]);
    
    % Bounds of Jxp
    J_xp_low(1:2,3,1:2) = -1;
    J_xp_up(1:2,3,1:2) = 1;
    
    % Bounds of Jpx
    J_px_low(1:2,1:2,3) = -1;
    J_px_up(1:2,1:2,3) = 1;
end

%% Convert these 3D matrices to their corresponding 2D form:
%   size(J_xx_low) = [n_x,n_x^2]
%   size(J_xp_low) = [n_x,n_x*n_p]
%   size(J_pp_low) = [n_x,n_p^2]
%   size(J_px_low) = [n_x,n_x*n_p]
% and for example:
%   J_xx_low = [J_xx_low(:,1,:) , ... , J_xx_low(:,n_x,:)]
J_xx_low = reshape(permute(J_xx_low,[1,3,2]),[n_x,n_x^2]);
J_xx_up = reshape(permute(J_xx_up,[1,3,2]),[n_x,n_x^2]);
J_xp_low = reshape(permute(J_xp_low,[1,3,2]),[n_x,n_x*n_p]);
J_xp_up = reshape(permute(J_xp_up,[1,3,2]),[n_x,n_x*n_p]);
J_pp_low = reshape(permute(J_pp_low,[1,3,2]),[n_x,n_p^2]);
J_pp_up = reshape(permute(J_pp_up,[1,3,2]),[n_x,n_p^2]);
J_px_low = reshape(permute(J_px_low,[1,3,2]),[n_x,n_x*n_p]);
J_px_up = reshape(permute(J_px_up,[1,3,2]),[n_x,n_x*n_p]);
