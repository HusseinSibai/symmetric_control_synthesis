%% Compute the reachable set or tube of an affine interval system
% dz/dt = A*z + B, with matrices A and B bounded in intervals

% Source paper 1 (interval arithmetics for time-varying linear systems):
% M. Althoff, O. Stursberg and M. Buss, "Reachability analysis of linear 
% systems with uncertain parameters and inputs". 46th IEEE Conference on 
% Decision and Control, pp. 726-732, 2007. DOI: 10.1109/CDC.2007.4434084

% Source paper 2 (definition of basic operations for interval arithmetics):
% L. Jaulin, M. Kieffer, O. Didrit and E. Walter, "Applied interval 
% analysis: with examples in parameter and state estimation, robust control
% and robotics". Springer Science & Business Media, v. 1, 2001.

% List of inputs
%   t_init: initial time
%   t_final: time at which the reachable set is approximated
%   [z0_LB,z0_UB]: interval of initial states, with size(z) = [n1,n2]
%   [A_LB,A_UB]: bounds of the Jacobian matrix A, with size(A) = [n1,n1]
%   [B_LB,B_UB]: bounds of the input matrix B, with size(B) = [n1,n2]
%   bool_reachable_tube: choice of what to over-approximate:
%       0 for the reachable set at t_final
%       1 for the reachable tube over [t_init,t_final]
%   taylor_order: (optional) integer to impose a minimum order of the Taylor series

% List of outputs
%   [z_LB,z_UB]: interval over-approximation of the reachable set or tube

% Authors:  
%   Pierre-Jean Meyer, <pjmeyer -AT- berkeley.edu>, EECS, UC Berkeley
% Date: 1st of February 2019

function [z_LB,z_UB] = Affine_interval_system_reachability(t_init,t_final,z0_LB,z0_UB,A_LB,A_UB,B_LB,B_UB,bool_reachable_tube,taylor_order)
[n1,n2] = size(z0_LB);
T = t_final-t_init;     % Width of the time step

% Check consistency of user-provided inputs
assert(t_init<t_final,'Inconsistent time interval: need t_init<t_final')
assert(isequal(size(z0_LB),size(z0_UB)),'Inconsistent size of the interval of initial states: size(z0_LB)~=size(z0_UB)')
assert(isequal(size(A_LB),[n1,n1]),'Inconsistent size of the Jacobian interval matrix: need A_LB and A_UB to be square of dimension size(z0_LB,1)')
assert(isequal(size(A_LB),size(A_UB)),'Inconsistent size of the Jacobian interval matrix: size(A_LB)~=size(A_UB)')
assert(isequal(size(B_LB),size(z0_UB)),'Inconsistent size of the input interval matrix: need B_LB and B_UB to have the same size as z0_LB')
assert(isequal(size(B_LB),size(B_UB)),'Inconsistent size of the input interval matrix: size(B_LB)~=size(B_UB)')
assert(all(z0_LB(:)<=z0_UB(:)),'Inconsistent bounds of the initial state: need z0_LB <= z0_UB')
assert(all(A_LB(:)<=A_UB(:)),'Inconsistent bounds of the Jacobian matrix: need A_LB <= A_UB')
assert(all(B_LB(:)<=B_UB(:)),'Inconsistent bounds of the input matrix: need B_LB <= B_UB')

% Extract from Solver_parameters.m the parameters for Taylor series truncation
run('Solver_parameters.m')
if nargin < 10      % Only read 'taylor_order' from Solver_parameters.m if it is not provided as an input argument of this function
    taylor_order = parameters.taylor_order;         % Initial order for the truncation of the Taylor series (may be interatively increased if the results are not satisfactory)
end
taylor_tolerance = parameters.taylor_tolerance;     % Stopping condition: max relative error allowed between two iterations
taylor_increment = parameters.taylor_increment;     % Taylor order increase at each iteration

% Increase Taylor order if it is too low for the computations to hold
taylor_order = max(taylor_order,floor(Interval_matrix_norm(A_LB,A_UB)*T-2) + 1);

% Display the Taylor order to be initially used
% fprintf('Reachability analysis of an affine interval system using Interval Arithmetics and truncated Taylor series at order: ')
% tic_IA = tic;

%% Iterative computation of the reachable set with increasing Taylor orders until convergence
% To skip this (do a single iteration), set: 'parameters.taylor_tolerance = NaN' in Solver_parameters.m 

% Initial computation of the reachable set
[z_LB,z_UB] = Reachable_set_OA(T,taylor_order,z0_LB,z0_UB,A_LB,A_UB,B_LB,B_UB,bool_reachable_tube);

% Initialization of the internal variables for the loop update
z_LB_prev = zeros(n1,n2);
z_UB_prev = zeros(n1,n2);

% Loop stops when  interval [z_LB,z_UB] has not changed more than tolerance
% or if taylor_tolerance is undefined (NaN)
while ~isnan(taylor_tolerance) && ...
      (~all(all((abs(z_LB_prev-z_LB) <= abs(z_LB)*taylor_tolerance) & ...
                (abs(z_UB_prev-z_UB) <= abs(z_UB)*taylor_tolerance))))
    % Update previous reachable set/tube
    z_LB_prev = z_LB;
    z_UB_prev = z_UB;
    
    % Increase Taylor order
    taylor_order = taylor_order + taylor_increment;
    
    % Compute new reachable set/tube
    [z_LB,z_UB] = Reachable_set_OA(T,taylor_order,z0_LB,z0_UB,A_LB,A_UB,B_LB,B_UB,bool_reachable_tube);
end

% Display the Taylor order really used
% fprintf('%d\n',taylor_order)
% toc(tic_IA)

end


%% Computation of the reachable set or tube of the affine interval system
% Using truncated Taylor series and an over-approximation of its remainder

% This function computes, for system dz/dt=Az+B:
% - an over-approximation of the homogeneous solution after time T
% - an over-approximation of the particulate solution after time T
% - an over-approximation of the homogeneous solution over time range [0,T]
% - an over-approximation of the reachable set after time T by adding both
% homogeneous and particulate solutions after T
% - or an over-approximation of the reachable tube over time range [0,T] by
% adding the homogeneous solution over time range [0,T] with the
% particulate solution at time T.

% List of inputs
%   T: time step
%   taylor_order: truncation order of the Taylor series
%   [z0_LB,z0_UB]: interval of initial states
%   [A_LB,A_UB]: bounds of the Jacobian matrix A
%   [B_LB,B_UB]: bounds of the input matrix B
%   bool_reachable_tube: choice of what to over-approximate:
%       0 for the reachable set at t_final
%       1 for the reachable tube over [t_init,t_final]

% List of outputs
%   [z_LB,z_UB]: interval over-approximation of the reachable set or tube

function [z_LB,z_UB] = Reachable_set_OA(T,taylor_order,z0_LB,z0_UB,A_LB,A_UB,B_LB,B_UB,bool_reachable_tube)
[n1,n2] = size(z0_LB);

% Particular case if A is a singleton equal to the 0 matrix
if isequal(A_LB,A_UB) && ~any(A_LB(:))
    % Reachable set at the final time
    [z_LB,z_UB] = Interval_matrix_sum(z0_LB,z0_UB,B_LB*T,B_UB*T);
    
    % Reachable tube if necessary
    if bool_reachable_tube
        % Interval hull with the set of initial states
        z_LB = min(z0_LB,z_LB);
        z_UB = max(z0_UB,z_UB);
    end
    
    return
end


% Remainder of the Taylor series after truncation at taylor_order
[E_LB,E_UB] = Truncation_remainder(T,taylor_order,A_LB,A_UB);

%% Homogeneous solution (and sum component of the hull enlargement term)
if isequal(z0_LB,z0_UB) && ~any(z0_LB(:))
    % Skipped if the initial state interval is a singleton equal to 0
    hom_LB = zeros(n1,n2);
    hom_UB = zeros(n1,n2);
    HE_LB = zeros(n1,n2);
    HE_UB = zeros(n1,n2);
else    
    % Recursive definition of the truncated Taylor series for the interval 
    % matrix exponential exp(A*T)
    
    % Initialization of a single element in the sum (A*T)^i/i!
    sum_i_LB = eye(n1);
    sum_i_UB = eye(n1);
    % Initialization of the sum of the homogeneous solution (for order 0)
    hom_LB = eye(n1);
    hom_UB = eye(n1);
    % Initialization of the sum component of the hull enlargement term
    HE_LB = zeros(n1);
    HE_UB = zeros(n1);
    
    % Loop from 1 to taylor_order for the computation and sum of terms (A*T)^i/i!
    for i = 1:taylor_order
        % Computation of the new term (A*T)^i/i! based on the one at i-1
        [sum_i_LB,sum_i_UB] = Interval_matrix_product(sum_i_LB,sum_i_UB,A_LB*T/i,A_UB*T/i);
        % Update of the sum of the homogeneous solution
        [hom_LB,hom_UB] = Interval_matrix_sum(hom_LB,hom_UB,sum_i_LB,sum_i_UB);
        
        % Update of the sum of the hull enlargement (starts at i==2)
        % (skipped if the reachable tube does not need to be computed)
        if bool_reachable_tube && i>=2
            % Product [scalar_LB,0]*[sum_i_LB,sum_i_UB] for term i of the sum
            scalar_LB = i^(i/(1-i))-i^(1/(1-i));
            [temp_LB,temp_UB] = Interval_matrix_product_with_scalar(scalar_LB,0,sum_i_LB,sum_i_UB);
            % Update of the sum of the hull enlargement
            [HE_LB,HE_UB] = Interval_matrix_sum(HE_LB,HE_UB,temp_LB,temp_UB);
        end
    end

    % Over-approximation of the interval matrix exponential exp(A*T)
    [hom_LB,hom_UB] = Interval_matrix_sum(hom_LB,hom_UB,E_LB,E_UB);

    % Reachable set component from the homogeneous solution
    [hom_LB,hom_UB] = Interval_matrix_product(hom_LB,hom_UB,z0_LB,z0_UB);
    
    % Computations for reachable tube
    if bool_reachable_tube
        % Addition of the truncation remainder to the hull enlargement sum
        [HE_LB,HE_UB] = Interval_matrix_sum(HE_LB,HE_UB,E_LB,E_UB);
        % Final hull enlargement term
        [HE_LB,HE_UB] = Interval_matrix_product(HE_LB,HE_UB,z0_LB,z0_UB);
    end
end

%% Particulate solution (and hull enlargment term related to the input)

if isequal(B_LB,B_UB) && ~any(B_LB(:))
    % Skipped if the input interval is a singleton equal to 0
    par_LB = zeros(n1,n2);
    par_UB = zeros(n1,n2);
    par_center_LB = zeros(n1,n2);
    par_center_UB = zeros(n1,n2);
    HE_input_LB = zeros(n1,n2);
    HE_input_UB = zeros(n1,n2);
else   
    % Check if 0 belongs to the input set [B_LB,B_UB] (for reachable tube)
    if bool_reachable_tube && ~(all(B_LB(:)<=zeros(n1*n2,1)) && all(B_UB(:)>=zeros(n1*n2,1)))
        % If not, redefine [B_LB,B_UB] := [B_LB,B_UB] - B_center
        % so that 0 belongs to the new [B_LB,B_UB]
        B_center = (B_LB+B_UB)/2;
        [B_LB,B_UB] = Interval_matrix_sum(B_LB,B_UB,-B_center,-B_center);
        
        bool_zero_in_B = 0;     % This also implies bool_reachable_tube=1
        
        % Initialization of the hull enlargement
        HE_input_LB = zeros(n1);
        HE_input_UB = zeros(n1);
    else
        bool_zero_in_B = 1;     % This might mean that bool_reachable_tube=0
        % Set unnecessary variables to 0
        par_center_LB = zeros(n1,n2);
        par_center_UB = zeros(n1,n2);
        HE_input_LB = zeros(n1,n2);
        HE_input_UB = zeros(n1,n2);
    end

    % Recursive definition of the truncated Taylor series
    
    % Initialization of a single element in the sum (A*T)^i/(i+1)!
    par_i_LB = eye(n1);
    par_i_UB = eye(n1);
    % Initialization of a single element in the sum A^(i-1)*T^i/i!
    HE_input_i_LB = T*eye(n1);
    HE_input_i_UB = T*eye(n1);
    % Initialization of the sum
    par_LB = eye(n1);
    par_UB = eye(n1);

    % Loop from 1 to taylor_order for the computation and sum of terms 
    % (A*T)^i/(i+1)! and A^(i-1)*T^i/i!
    for i = 1:taylor_order
        % Computation of the new term (A*T)^i/(i+1)! based on the one at i-1
        [par_i_LB,par_i_UB] = Interval_matrix_product(par_i_LB,par_i_UB,A_LB*T/(i+1),A_UB*T/(i+1));
        % Update of the sum
        [par_LB,par_UB] = Interval_matrix_sum(par_LB,par_UB,par_i_LB,par_i_UB);
        
        % Update of the sum of the hull enlargement (starts at i==2)
        % only computed if the input set does not contain 0 
        % and if we want to compute the reachable tube
        if ~bool_zero_in_B && i>=2
            % Computation of the new term A^(i-1)*T^i/i! based on the one at i-1
            [HE_input_i_LB,HE_input_i_UB] = Interval_matrix_product(HE_input_i_LB,HE_input_i_UB,A_LB*T/i,A_UB*T/i);
            % Product [scalar_LB,0]*[HE_input_i_LB,HE_input_i_UB] for term i of the sum
            scalar_LB = i^(i/(1-i))-i^(1/(1-i));
            [temp_LB,temp_UB] = Interval_matrix_product_with_scalar(scalar_LB,0,HE_input_i_LB,HE_input_i_UB);
            % Update of the sum of the hull enlargement
            [HE_input_LB,HE_input_UB] = Interval_matrix_sum(HE_input_LB,HE_input_UB,temp_LB,temp_UB);
        end
    end

    % Addition of the remainder from the Taylor series truncation
    [par_LB,par_UB] = Interval_matrix_sum(par_LB,par_UB,E_LB,E_UB);

    % Computations for reachable tube with 0 not in the input set
    if ~bool_zero_in_B
        % Reachable set component from the center of the input set
        [par_center_LB,par_center_UB] = Interval_matrix_product(par_LB,par_UB,T*B_center,T*B_center);
        
        % Add error term for the input-related hull enlargment
        inf_norm = Interval_matrix_norm(A_LB,A_UB);
        [HE_input_LB,HE_input_UB] = Interval_matrix_sum(HE_input_LB,HE_input_UB,E_LB/inf_norm,E_UB/inf_norm);
        % Final input-related hull enlargement
        [HE_input_LB,HE_input_UB] = Interval_matrix_product(HE_input_LB,HE_input_UB,B_center,B_center);
    end

    % Reachable set component from the main or shifted input set
    [par_LB,par_UB] = Interval_matrix_product(par_LB,par_UB,T*B_LB,T*B_UB);
end

%% Resulting reachable set or reachable tube
if ~bool_reachable_tube
    % Final computations for the reachable set
    [z_LB,z_UB] = Interval_matrix_sum(hom_LB,hom_UB,par_LB,par_UB);
else
    % Final computations for the reachable tube
    
    % Homogeneous solution + influence of the input center
    [z_LB,z_UB] = Interval_matrix_sum(hom_LB,hom_UB,par_center_LB,par_center_UB);

    % Interval hull with the set of initial states
    z_LB = min(z0_LB,z_LB);
    z_UB = max(z0_UB,z_UB);

    % Enlargement of the hull related to the homogeneous solution
    [z_LB,z_UB] = Interval_matrix_sum(z_LB,z_UB,HE_LB,HE_UB);

    % Enlargement of the hull related to the input center
    [z_LB,z_UB] = Interval_matrix_sum(z_LB,z_UB,HE_input_LB,HE_input_UB);
    
    % Final reachable tube (after adding particulate solution)
    [z_LB,z_UB] = Interval_matrix_sum(z_LB,z_UB,par_LB,par_UB);
end
end

%% Over-approximation of the remainder of the truncated Taylor series
% List of inputs
%   T: time step
%   taylor_order: truncation order of the Taylor series
%   [A_LB,A_UB]: Jacobian interval matrix
% List of outputs
%   [E_LB,E_UB]: bounds of the remainder of the truncated Taylor series
function [E_LB,E_UB] = Truncation_remainder(T,taylor_order,A_LB,A_UB)
[n,~] = size(A_LB);
Jacobian_norm = Interval_matrix_norm(A_LB,A_UB)*T;
epsilon = Jacobian_norm/(taylor_order+2); 
E_UB = 1/(1-epsilon);
for i = 1:(taylor_order+1)
    E_UB = E_UB*Jacobian_norm/i;
end
E_UB = ones(n)*E_UB;
E_LB = -E_UB;
end

%% Infinity norm definition for an interval matrix
% Inputs. [A_LB,A_UB]: interval matrix A
% Output. inf_norm: infinity norm of interval matrix A
function inf_norm = Interval_matrix_norm(A_LB,A_UB)
inf_norm = norm(max(abs(A_LB),abs(A_UB)),Inf);
end

%% Sum of two interval matrices A+B
% Inputs. [A_LB,A_UB], [B_LB,B_UB]: two interval matrices A and B
% Outputs. [sum_LB,sum_UB]: interval matrix for the sum A+B
function [sum_LB,sum_UB] = Interval_matrix_sum(A_LB,A_UB,B_LB,B_UB)
sum_LB = A_LB+B_LB;
sum_UB = A_UB+B_UB;
end

%% Product of two interval matrices A*B
% Inputs. [A_LB,A_UB], [B_LB,B_UB]: two interval matrices A and B
% Outputs. [prod_LB,prod_UB]: interval matrix for the product A*B
function [prod_LB,prod_UB] = Interval_matrix_product(A_LB,A_UB,B_LB,B_UB)
prod_LB = zeros(size(A_LB,1),size(B_LB,2));
prod_UB = zeros(size(A_LB,1),size(B_LB,2));
for i = 1:size(A_LB,1)  % lines of A
    for j = 1:size(B_LB,2)  % columns of B
        prod_LB(i,j) = sum(min([A_LB(i,:)'.*B_LB(:,j) A_UB(i,:)'.*B_LB(:,j) A_LB(i,:)'.*B_UB(:,j) A_UB(i,:)'.*B_UB(:,j)],[],2));
        prod_UB(i,j) = sum(max([A_LB(i,:)'.*B_LB(:,j) A_UB(i,:)'.*B_LB(:,j) A_LB(i,:)'.*B_UB(:,j) A_UB(i,:)'.*B_UB(:,j)],[],2));
    end
end
end

%% Product a*B of scalar interval a with interval matrix B
% Input. [a_LB,a_UB]: scalar interval a
% Input. [B_LB,B_UB]: interval matrices B
% Outputs. [prod_LB,prod_UB]: interval matrix for the product a with each element of B
function [prod_LB,prod_UB] = Interval_matrix_product_with_scalar(a_LB,a_UB,B_LB,B_UB)
prod_LB = min(min(min(a_LB*B_LB,a_LB*B_UB),a_UB*B_LB),a_UB*B_UB);
prod_UB = max(max(max(a_LB*B_LB,a_LB*B_UB),a_UB*B_LB),a_UB*B_UB);
end

%% Power operator of an interval matrix A^n
% Input. [A_LB,A_UB]: interval matrix A
% Input. n: power integer
% Outputs. [power_LB,power_UB]: interval matrix for A^n
function [power_LB,power_UB] = Interval_matrix_power(A_LB,A_UB,n)
if  n == 1  % A^1 = A
    power_LB = A_LB;
    power_UB = A_UB;
else        % A^n = A^(n-1)*A
    [temp_LB,temp_UB] = Interval_matrix_power(A_LB,A_UB,n-1);
    [power_LB,power_UB] = Interval_matrix_product(temp_LB,temp_UB,A_LB,A_UB);
    
    % A*A^(n-1) and A^(n-1)*A yield different results for n>2,
    % but both are guaranteed to over-approximate the real value of A^n
    % To use A^n = A*A^(n-1), replace the last line by the following:
%     [power_LB,power_UB] = Interval_matrix_product(A_LB,A_UB,temp_LB,temp_UB);
end
end
