%% Cybership 3 model
% Dynamic Positioning (DP) model for bool_dp=1
% Simplified DP model for bool_dp=0
%   mass and damping matrices from the maneuvering model,
%   no nonlinear damping term

% List of inputs
%   t: time
%   x: state
%   x_d: input value (desired positions and velocities)

% List of outputs
%   dx: vector field evaluated at time t, state x and input p

function dx = System_description(t,x,x_d)

global bool_dp

%% Persistent variables
persistent CurrentCoeffs direction_step
persistent tau_wind v_c V_c beta_c mu_nom
persistent Mrb Ma M D alpha L Kp Kd
persistent Lpp T

if isempty(direction_step)
    %% Load vessel parameters - these are fullscale from ShipX
    load CS3_20181102.mat
    load CS3ABC_20181102.mat

    %% Scale down to model-scale - CS3
    % Scale of model
    lambda =  1/30; 

    % Scaling matrix for scaling mass and damping matrices, from dimensional
    % analysis
    Lambda = [lambda^3*ones(3), lambda^4*ones(3);
              lambda^4*ones(3), lambda^5*ones(3)];

    % Main particulars
    Modelvessel.Lpp = lambda*vessel.main.Lpp;
    Modelvessel.Lwl = lambda*vessel.main.Lwl;
    Modelvessel.B = lambda*vessel.main.B;
    Modelvessel.T = lambda*vessel.main.T;

    % Rigid body mass
    M_RB_m = Lambda.*vessel.MRB;
    Modelvessel.MRB = M_RB_m;

    % Hydrodynamic coefficients

    M_A0_m = Lambda.*vesselABC.MA_0;
    Sym_A0 = 0.5*(M_A0_m + M_A0_m');

    Modelvessel.MA_0 = Sym_A0;

    M_Ainf_m = Lambda.*vesselABC.MA_inf;
    Sym_Ainf = 0.5*(M_Ainf_m + M_Ainf_m');
    Modelvessel.MA_inf = Sym_Ainf;


    D0_m = Lambda.*vesselABC.B_0;  % vessel.B(:,:,35,5);
    Sym_D0 = 0.5*(D0_m + D0_m');
    Modelvessel.B_0 = Sym_D0;

    Dinf_m = Lambda.*vesselABC.B_inf;
    Sym_Dinf = 0.5*(Dinf_m + Dinf_m');
    Modelvessel.B_inf = Sym_Dinf;

    Bv_m = Lambda.*vessel.Bv;
    Modelvessel.Bv = Bv_m;

    %% Current data - estimated
    % Directions for the current coefficients (deg)
    direction_step = 10;    % Step in degrees for the direction range [0 180] (0 = following sea, 180 = head sea)

    % Current force coefficients for each direction 
    % Surge Sway Yaw
    CurrentCoeffs = [...
     -9.2319e+003            0            0
     -9.4279e+003 -1.9898e+004 -2.4918e+005
     -1.0410e+004 -4.2066e+004 -5.1847e+005
     -1.2376e+004 -6.8636e+004 -7.5088e+005
     -1.4537e+004 -9.7417e+004 -9.4749e+005
     -1.4339e+004 -1.2630e+005 -9.4749e+005
     -1.1982e+004 -1.5057e+005 -6.0786e+005
     -8.8391e+003 -1.6606e+005 -5.1828e+005
     -5.1076e+003 -1.7485e+005 -2.1429e+005
     -1.3748e+003 -1.7930e+005  1.0714e+005
      3.1430e+003 -1.7492e+005  5.0084e+005
      7.2683e+003 -1.6405e+005  8.5840e+005
      1.1000e+004 -1.4607e+005  1.1799e+006
      1.4339e+004 -1.2171e+005  1.4477e+006
      1.6304e+004 -9.5206e+004  1.5013e+006
      1.6304e+004 -7.0808e+004  1.2709e+006
      1.5322e+004 -4.6496e+004  9.4749e+005
      1.3751e+004 -2.4354e+004  5.7185e+005
      1.1786e+004            0            0 ]*[(0.0732/6000) 0 0; 0 (0.0732/6000) 0; 0 0 (0.0732*1.971)/(6000*80)];
  
    %% Environment - current and wind
    % Wind 
    tau_wind = zeros(3,1);
    % tau_wind = 1*0.1*[0 0.5 1]'; % zeros(3,1);

    % Current
    v_c = zeros(3,1);
    % v_c = 1*0.01*[1 0 0]';  % North East current
    V_c = sqrt(v_c(1)^2 + v_c(2)^2); % Current speed [m/s]
    beta_c =  atan2(v_c(2),v_c(1));  % Current direction  0 towards North, 90 towards East, -90 towards west, 180 towards South
    
    %% uncertainty bounds on parameters - not implemented...
    % Uncertainty is of the form p(1)*M, p(2)*D, p(3)*v_c, p(4)*tau_wind
    mu_nom = [1 1 1 1]';
    % mu_low =[1 1 1 1]';
    % mu_up = [1 1 1 1]'; 
    % mu_nom = (mu_low+mu_up)/2;
    
    %% Inertia variables
    % Rigid body inertia and added mass
    Mrb = [Modelvessel.MRB(1,1), 0 , 0 ;
        0, Modelvessel.MRB(2,2), Modelvessel.MRB(2,6);
        0, Modelvessel.MRB(6,2) ,Modelvessel.MRB(6,6)];

    if bool_dp
        Ma = [ Modelvessel.MA_0(1,1), 0 , 0 ;
            0,  Modelvessel.MA_0(2,2),  Modelvessel.MA_0(2,6);
            0,  Modelvessel.MA_0(6,2), Modelvessel.MA_0(6,6)];  % zero frequency for DP
    else
        Ma = [2.2997 0 0; ...
               0 13.1880 2.4827; ...
               0 2.4827 3.5574];
    end

    M = Mrb + Ma;
    
    %% Damping variables 
    % Linear potential damping and viscous damping - Fossen (2011) p. 115
    
    Bv = diag([Modelvessel.Bv(1,1),Modelvessel.Bv(2,2),Modelvessel.Bv(6,6)]);
    
    if bool_dp
        D_L = [Modelvessel.B_0(1,1), Modelvessel.B_0(1,2),Modelvessel.B_0(1,6);
               Modelvessel.B_0(2,1), Modelvessel.B_0(2,2),Modelvessel.B_0(2,6);
               Modelvessel.B_0(6,1), Modelvessel.B_0(6,2),Modelvessel.B_0(6,6)];% zero frequency for DP
    else
        D_L = [4.2151 0 0; ...
               0 24.1719 2.6573; ...
               0 2.6573 6.7726];% zero frequency for DP
    end
    
    D = Bv + D_L;


    % More sophisticated damping model in DP that takes current drag into account
    alpha = 1;  % how fast linear damping should decay for increasing forward speed
    
    %% Coriolis force linearized about surge speed - same expression in maneuvering and DP
    L = [0 0 0;
         0 0 1;
         0 0 0];

    %% Controller
    % DP 3 DOF control
    Kp = 1*diag([1 1 1]'.*diag(M));         % Proportional gain surge, sway, yaw
    Kd = 1*diag([2 2 4]'.*diag(M));
    
    %% Model parameters
    Lpp = Modelvessel.Lpp;
    T = Modelvessel.T;
end

%% More sophisticated damping model in DP that takes current drag into account
D_DP = [D(1,1)*exp(-alpha*abs(x(4)- mu_nom(3)*V_c*cos(beta_c-x(3)))), 0, 0;
        0, D(2,2)*exp(-alpha*abs(x(5)- mu_nom(3)*V_c*sin(beta_c-x(3)))), D(2,3)*exp(-alpha*abs(x(6)));
        0, D(3,2)*exp(-alpha*abs(x(5)- mu_nom(3)*V_c*sin(beta_c-x(3)))), D(3,3)*exp(-alpha*abs(x(6)))];

% Calculate drag angle - relative angle between ship heading and
% current direction
% Drag angle rounded to nearest 10 degrees
if bool_dp
    DragAngle = atan2(-(x(5)- mu_nom(3)*V_c*sin(beta_c-x(3))),  -(x(4)- mu_nom(3)*V_c*cos(beta_c-x(3))));

    % index corresponding to current coefficients
    IDX = round(abs(DragAngle)*180/(pi*direction_step))+1;

    % Relative speed
    V_r = sqrt( (x(4)- mu_nom(3)*V_c*cos(beta_c-x(3)))^2 + (x(5)- mu_nom(3)*V_c*sin(beta_c-x(3)))^2 );
    % Nonlinear damping and current drag, need to add sign(DragAngle) to get correct sign...
    D_NL = sign(DragAngle)*0.5*1025*Lpp*T*...
                   [CurrentCoeffs(IDX,1)*V_r^2;
                    CurrentCoeffs(IDX,2)*V_r^2;
                    Lpp*CurrentCoeffs(IDX,3)*V_r^2;];
else
    D_NL = zeros(3,1);
end

%% Rotation matrix
R =  [cos(x(3)),-sin(x(3)),0;
            sin(x(3)),cos(x(3)),0;
            0 , 0 , 1];
Rt =  [cos(x(3)),sin(x(3)),0;
            -sin(x(3)),cos(x(3)),0;
             0 , 0 , 1];

%% Coriolis force linearized about surge speed - same expression in maneuvering and DP
Crb = x(4)*mu_nom(1)*Mrb*L ;   % With velocity
Ca = (x(4) - [1 0 0]*(Rt*mu_nom(3)*v_c))*mu_nom(1)*Ma*L;    % With relative velocity

%% Controller
tau = Kp*Rt*(x_d(1:3)-x(1:3))+ Kd*(x_d(4:6)-x(4:6));

%% Ship dynamics and state Jacobian
% DP equations of  motion - with nonlinear current drag
dx = [R*x(4:6); 
      (1/mu_nom(1))*M\(- Crb*x(4:6) - Ca*(x(4:6)-Rt*mu_nom(3)*v_c) - mu_nom(2)*D_DP*(x(4:6)-Rt*mu_nom(3)*v_c) - mu_nom(2)*D_NL + tau + Rt*mu_nom(4)*tau_wind)];  
  