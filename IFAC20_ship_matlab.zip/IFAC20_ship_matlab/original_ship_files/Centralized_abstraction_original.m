%% Create a symbolic automaton of the system restricted to an interval

% [X_low,X_up]: state interval of interest
% sym_x: number of symbols per dimension of the state
% [U_low,U_up]: control interval
% sym_x: number of discrete value per dimension of the control
% [W_low,W_up]: disturbance interval
% time_step: time step for the symbolic automaton
% state_dimensions: state dimensions considered for abstraction
% OA_method: reachability method (3: CTMM, 4: SDMM with sampling)

% Symbolic_reduced: symbolic automaton of the model using translational symmetry
% U_discrete: discretization of the control input set

function [Symbolic_reduced,U_discrete,unsafe_trans] = Centralized_abstraction(X_low,X_up,sym_x,U_low,U_up,sym_u,W_low,W_up,time_step,state_dimensions,OA_method)


%% for python calls
%X_low_temp = [X_low{:}]; 
% X_low = cell2mat(X_low_temp); 
% X_up_temp = [X_low{:}]; 
% X_up = cell2mat(X_up_temp); 

 % y = double(reshape(x,1,));
 n_x = length(state_dimensions);
 X_low = reshape(X_low, n_x, 1);
 X_up = reshape(X_up, n_x, 1);
 sym_x = reshape(sym_x, n_x, 1);
 n_u = length(U_low);
 U_low = reshape(U_low, n_u, 1);
 U_up = reshape(U_up, n_u, 1);
 sym_u = reshape(sym_u, n_u, 1);
 n_w = length(W_low);
 W_low = reshape(W_low, n_w, 1);
 W_up = reshape(W_up, n_w, 1);

 filebase = '/Users/hsibai/Downloads/IFAC20_ship_matlab/python_call_Rtree';
    file_index=1;
    while 1
        filename = [filebase num2str(file_index) '.mat'];
        % If the file does not exist, stop looking and compute the automaton
        if ~exist(filename,'file')
            break
        end
        file_index = file_index + 1;
    end

    save(filename,'X_low','X_up','sym_x','U_low','U_up','sym_u','W_low','W_up','time_step','state_dimensions','OA_method','-v7.3');
%%

%% Initialization
tic
n = length(X_low);
% HUSSEIN
% Although I'm keeping it the following statement unchanged from Meyer's
% implementation, I'm using it to define the symbol step in the transformed
% space, i.e., the image of \phi. More formally, it should discretize the 
% set {y \in R^n | y = phi_{gamma(x)}(x), x \in X} \cup {y \in R^n | y = 
% f(x,u,w), x is in the previous set, u and w being instances of the 
% control and disturbance of the reduced model}
symbol_step = (X_up-X_low)./sym_x;

% HUSSEIN
% defining the space of reduced states as well as the quantization
% resolution
% The initial state of the reduced system will always belong to a
% crosssection C = {x \in R^n | \phi_e^a (x) = c}
% However, the successor state under the reduced dynamics might not belong
% to C.
X_low_red = transform_to_frame(X_low, X_low);
X_up_red = transform_to_frame(X_up, X_up);
X_low_red = min(X_low_red, X_up_red);
X_up_red = max(X_up_red, X_up_red); % not needed, but kept for clarity.
symbol_step_red = symbol_step.* state_dimensions';

% % Input set discretization
% angle_discrete = U_low(1):(U_up(1)-U_low(1))/(sym_u(1)-1):U_up(1);
% surge_discrete = U_low(2):(U_up(2)-U_low(2))/(sym_u(2)-1):U_up(2);
% U_discrete = zeros(length(U_low),prod(sym_u));
% for i = 1:sym_u(2)
%     U_discrete(:,sym_u(1)*(i-1)+1:sym_u(1)*i) = [angle_discrete;surge_discrete(i)*ones(1,sym_u(1))];
% end

% Input set discretization (if the values of sym_u are all the same)
% HUSSEIN: here we are still assuming that the control space does not
% change in the reduced model. Otherwise, that should be transformed as 
% done for the state space above.

U_discrete = [];
unsafe_trans = 0;

if range(sym_u)==0
    sym_u = sym_u(1);
    ui_values = 1:sym_u;
    U_discrete = Gray(ui_values,size(U_low,1),sym_u);
    U_discrete = repmat(U_low,1,sym_u^size(U_low,1)) + (U_discrete-1).*repmat((U_up-U_low)/(sym_u-1),1,sym_u^size(U_low,1));
else
    error('Non-homogeneous input discretization cannot be handled yet')
end

%% Variables for the reduced symbolic model (using translational symmetry)

% Reduced symbolic model when using translational symmetry
% HUSSEIN: works for lie groups in general where state_dimension would
% define the states that vary at the cross section C defined by the moving
% frame (see Maidens et al. Automatic, 2018)
sym_x_reduced = sym_x.*state_dimensions' + ~state_dimensions';
matrix_dim_reduced = [prod(sym_x_reduced),2*n, size(U_discrete,2)];
Symbolic_reduced = zeros(matrix_dim_reduced);

% Convert symbol indices to subscripts on each dimension
symbol_subscripts = cell(n,1);
[symbol_subscripts{:}] = ind2sub(sym_x_reduced',1:matrix_dim_reduced(1));
symbol_subscripts = cell2mat(symbol_subscripts);

%% Compute the successor of each symbol for the reduced model
% for full_index = 1:matrix_dim_reduced(1)     % Loop on the source symbol
for full_index = 1:matrix_dim_reduced(1)     % Loop on the source symbol
    
    % Interval of the source symbol
    % HUSSEIN: changed X_low to X_low_red and symbol_step to symbol_step_red
    symbol_subscripts(:,full_index)
    symbol_low = X_low_red'+symbol_step_red.*(symbol_subscripts(:,full_index)-1);
    symbol_up = X_low_red'+symbol_step_red.*symbol_subscripts(:,full_index);
    temp = zeros(1,matrix_dim_reduced(2),2*n);
    for k = 1:matrix_dim_reduced(2)   % Loop on the control input
        u = U_discrete(:,k);
        % Over-approximation of the reachable set
        if OA_method==3
            % Continuous-time mixed-monotonicity
            [J_x_low,J_x_up,J_p_low,J_p_up] = UP_Jacobian_Bounds(0,time_step,symbol_low,symbol_up,[u;W_low],[u;W_up]);
%             [J_x_low,J_x_up,J_p_low,J_p_up] = UP_Jacobian_Bounds(0,time_step,X_low,X_up,[u;W_low],[u;W_up]);      % Global Jacobian bounds actually not needed for the ship example
            [succ_low,succ_up] = OA_3_CT_Mixed_Monotonicity2(0,time_step,symbol_low,symbol_up,[u;W_low],[u;W_up],J_x_low,J_x_up,J_p_low,J_p_up);
        elseif OA_method==4
            % Sampled-data mixed-monotonicity with sampling and falsification
            [S_x_low,S_x_up,S_p_low,S_p_up] = Sensitivity_sampling(0,time_step,symbol_low,symbol_up,[u;W_low],[u;W_up],0);
            [S_x_low,S_x_up,S_p_low,S_p_up] = Sensitivity_falsification(0,time_step,symbol_low,symbol_up,[u;W_low],[u;W_up],S_x_low,S_x_up,S_p_low,S_p_up,0);
            [succ_low,succ_up] = OA_4_CT_Sampled_data_MM(0,time_step,symbol_low,symbol_up,[u;W_low],[u;W_up],S_x_low,S_x_up,S_p_low,S_p_up);
        elseif OA_method==5
            % Sampled-data mixed-monotonicity with interval arithetics
            [J_x_low,J_x_up,J_p_low,J_p_up] = UP_Jacobian_Bounds(0,time_step,symbol_low,symbol_up,[u;W_low],[u;W_up]);
            [S_x_low,S_x_up,S_p_low,S_p_up] = Sensitivity_interval_arithmetics(0,time_step,symbol_low,symbol_up,[u;W_low],[u;W_up],J_x_low,J_x_up,J_p_low,J_p_up);
            [succ_low,succ_up] = OA_4_CT_Sampled_data_MM(0,time_step,symbol_low,symbol_up,[u;W_low],[u;W_up],S_x_low,S_x_up,S_p_low,S_p_up);
        else
            error('Wrong reachability method')
        end

        % HUSSEIN
        % succ_up = succ_up+symbol_step .* ~state_dimensions; 
        % succ_low = succ_low+symbol_step .* ~state_dimensions; 
        % [succ_low, succ_up] = transform_from_frame(succ_low, succ_up, )% X_low + symbol_step.*(symbol_subscripts(:,full_index)-1/2))

        % Convert successor interval into symbols
        % HUSSEIN: here I didn't change symbol_step to symbol_step_red
        % since the successor of a state in the crosssection might not
        % belong to the crosssection.
        % Not sure why there aren't checks if the successor is outside X
        % Also Meyer's version might result in symbols that are not allowed
        % in the reduced model, but maybe that's ok. The successor below is
        % checked if it gets outside the range by checking the third
        % dimension of the symbol if outside the range of symbols for that
        % dimension.
        % Will change the following statement to store the range as is
        % instead of transforming it into symbols.
        temp(1,k,:) = [succ_low;succ_up];
        % the right-hand-side was: ceil(([succ_low;succ_up]-
        % [X_low_red;X_low_red])./[symbol_step;symbol_step]);
    end
    Symbolic_reduced(full_index,:,:) = temp;
end

% HUSSEIN: I commented the following code since in the general case, the
% third dimension is also reduced by the transform_to_frame
% Mark as unsafe the transitions leaving the state space on dimension 3
% if range(sym_x)==0  % if all values of sym_x are the same
%     unsafe_trans = any(Symbolic_reduced(:,:,state_dimensions==1) < 1 | Symbolic_reduced(:,:,[false(n,1);(state_dimensions==1)']) > sym_x(1),3);
% else
%     unsafe_trans = false(matrix_dim_reduced(1),matrix_dim_reduced(2));
%     for i=1:n
%         if state_dimensions(i)
%             unsafe_trans = unsafe_trans | Symbolic_reduced(:,:,i) < 1 | Symbolic_reduced(:,:,n+i) > sym_x(i);
%         end
%     end
% end
unsafe_trans = 0;
fprintf('\nBuilding the reduced symbolic model (using translational symmetry): %f seconds\n',toc)

end

%% Generation of possible values with (k,n)-Gray Code
function x = Gray(xi,n,k)
% From: Guan, Dah-Jyh (1998). "Generalized Gray Codes with Applications". 
% Proc. Natl. Sci. Counc. Repub. Of China (A) 22: 841???848. 
% http://nr.stpi.org.tw/ejournal/ProceedingA/v22n6/841-848.pdf.

x = zeros(n,k^n);   % The matrix with all combinations
a = zeros(n+1,1);   % The current combination following (k,n)-Gray code
b = ones(n+1,1);    % +1 or -1
c = k*ones(n+1,1);  % The maximum for each digit
j=1;
while (a(n+1)==0)
    % Write current combination in the output
    x(:,j) = xi(a(1:n)+1);     
    j = j + 1;
    
    % Compute the next combination
    i = 1;
    l = a(1)+b(1);
    while (l>=c(i)) || (l<0)
        b(i) = -b(i);
        i = i+1;
        l = a(i)+b(i);
    end
    a(i) = l;
end
end