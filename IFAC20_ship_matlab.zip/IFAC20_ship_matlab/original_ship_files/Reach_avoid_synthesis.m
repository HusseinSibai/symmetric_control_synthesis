%% Controller synthesis for the reachability specification on the ship model
% With additional safety conditions of staying in the bounded state space
% and unsafe/obstacle sets within the state space.

% The obstacle avoidance is fully handled by skipping obstacle symbols in
% the loop of symbols to explore, thus ensuring that no obstacle symbol is
% ever added to the expanded list of target symbols.
function Controller = Reach_avoid_synthesis(Symbolic_reduced,unsafe_trans,sym_x,sym_u,state_dimensions,Target_low,Target_up,Obstacle_low,Obstacle_up)

tic
n = numel(state_dimensions);
matrix_dim_full = [prod(sym_x),prod(sym_u),2*n];

%% Target symbol indices

% Extract subscripts (on each dimension) for the corresponding target symbols
Target_width = Target_up - Target_low + ones(n,1);
target_subscripts = cell(n,1);
[target_subscripts{:}] = ind2sub(Target_width',1:prod(Target_width));
target_subscripts = cell2mat(target_subscripts);
target_subscripts = bsxfun(@plus, target_subscripts, Target_low-ones(n,1));

% Convert 3D subscripts into 1D indices
target_indices = sub2ind(sym_x',target_subscripts(1,:),target_subscripts(2,:),target_subscripts(3,:));

%% Obstacle symbol indices

obstacle_indices = [];
for i=1:size(Obstacle_up,2)
    % Extract subscripts (on each dimension) for the corresponding obstacles symbols
    Obstacle_width = Obstacle_up(:,i) - Obstacle_low(:,i) + ones(n,1);
    obstacle_subscripts = cell(n,1);
    [obstacle_subscripts{:}] = ind2sub(Obstacle_width',1:prod(Obstacle_width));
    obstacle_subscripts = cell2mat(obstacle_subscripts);
    obstacle_subscripts = bsxfun(@plus, obstacle_subscripts, Obstacle_low(:,i)-ones(n,1));
    
    % Convert 3D subscripts into 1D indices
    obstacle_indices = [obstacle_indices sub2ind(sym_x',obstacle_subscripts(1,:),obstacle_subscripts(2,:),obstacle_subscripts(3,:))];
end

%% Main synthesis loop

% Initialization of the controller (0 = not controllable or in target)
Controller = zeros(matrix_dim_full(1),1);

% Loop for the reachability synthesis
fprintf('\n%s\tStart of the control synthesis\n',num2str(datestr(now)))
while 1
    % Loop on all symbols to explore (not an obstacle, and not yet in the (expanded) target set)
    symbols_to_explore = setdiff(1:matrix_dim_full(1),target_indices);
    symbols_to_explore = setdiff(symbols_to_explore,obstacle_indices);
    Controller_temp = zeros(numel(symbols_to_explore),1);
    parfor s_ind = 1:numel(symbols_to_explore)
%     for s_ind = 1:numel(symbols_to_explore)
        s = symbols_to_explore(s_ind);
        % Loop on the control inputs
        for u = 1:matrix_dim_full(2)

            % Convert 1D s index to 3D subscript
            [s1,s2,s3] = ind2sub(sym_x',s);
            s_subscript = [s1;s2;s3];

            % Get corresponding 1D index in the reduced model
            s_reduced_ind = 1+(s-s_subscript(1)-(s_subscript(2)-1)*sym_x(1))/(sym_x(1)*sym_x(2));
            
            % Discard pair (s,u) if it leads outside of the state space
            % on the states in state_dimensions
            if unsafe_trans(s_reduced_ind,u)
                continue
            end

            % Get successor interval in the global model
            succ_low = shiftdim(Symbolic_reduced(s_reduced_ind,u,1:n),2) + (s_subscript-1).*(~state_dimensions');
            succ_up = shiftdim(Symbolic_reduced(s_reduced_ind,u,n+1:end),2) + (s_subscript-1).*(~state_dimensions');

            % Discard pair (s,u) if it leads outside of the state space
            % on the states NOT in state_dimensions
            if any(succ_low(~state_dimensions)<1 | succ_up(~state_dimensions)>sym_x(~state_dimensions))
                continue
            end
            
            % Extract subscripts for the covered symbols
            succ_width = succ_up - succ_low + ones(n,1);
            succ_subscripts = cell(n,1);
            [succ_subscripts{:}] = ind2sub(succ_width',1:prod(succ_width));
            succ_subscripts = cell2mat(succ_subscripts);
            succ_subscripts = bsxfun(@plus, succ_subscripts, succ_low-ones(n,1));
            
            % Convert 3D subscripts into 1D indices
            succ_indices = sub2ind(sym_x',succ_subscripts(1,:),succ_subscripts(2,:),succ_subscripts(3,:));
            
            % Check if the pair fully goes into the target set
            if all(ismember(succ_indices,target_indices))
                % Add current control to controller
                Controller_temp(s_ind) = u;
                % Stop looking at other control inputs
                break
            end
        end
    end
    
    % Check if the synthesis progressed during this iteration
    if any(Controller_temp)
        fprintf('%s\t%d new controllable states have been found in this synthesis iteration\n',num2str(datestr(now)),nnz(Controller_temp))
        for s_ind = 1:numel(symbols_to_explore)
            if Controller_temp(s_ind)
                s = symbols_to_explore(s_ind);
                % Write the obtained results in the Controller variable
                Controller(s) = Controller_temp(s_ind);
                % And update the indices of target symbols
                target_indices = [target_indices, s];
            end
        end
    else
        % If not, stop the while loop (no more progress can be obtained)
        fprintf('%s\tNo new controllable state has been found in this synthesis iteration\n',num2str(datestr(now)))
        break
    end
end

disp(['Controller synthesis for reach-avoid specification: ' num2str(toc) ' seconds'])
controllable_states = nnz(Controller);
if controllable_states
    fprintf('%d of %d symbols are controllable to satisfy the reach-avoid specification\n',controllable_states,matrix_dim_full(1))
else
    fprintf('The reach-avoid specification cannot be satisfied from any initial state\n')
end

%% Check that the controller has been created properly
% %     this test needs to be modified, now that the target symbols are 0 instead of -1
% for s = 1:numel(Controller)
%     u = Controller(s);
%     if u > 0
%         % Convert 1D s index to 6D subscript
%         [s1,s2,s3,s4,s5,s6] = ind2sub(sym_x',s);
%         s_subscript = [s1;s2;s3;s4;s5;s6];
% 
%         % Get corresponding 1D index in the reduced model
%         s_reduced_ind = 1+(s-s_subscript(1)-(s_subscript(2)-1)*sym_x(1))/(sym_x(1)*sym_x(2));
% 
%         % Get successor interval in the global model
%         succ_low = shiftdim(Symbolic_reduced(s_reduced_ind,u,1:n),2) + s_subscript.*(~state_dimensions');
%         succ_up = shiftdim(Symbolic_reduced(s_reduced_ind,u,n+1:end),2) + s_subscript.*(~state_dimensions');
%         
%         % Extract subscripts for the covered symbols
%         succ_width = succ_up - succ_low + ones(n,1);
%         succ_subscripts = cell(n,1);
%         [succ_subscripts{:}] = ind2sub(succ_width',1:prod(succ_width));
%         succ_subscripts = cell2mat(succ_subscripts);
%         succ_subscripts = bsxfun(@plus, succ_subscripts, succ_low-ones(n,1));
%         
%         % Convert 6D subscripts into 1D indices
%         succ_indices = sub2ind(sym_x',succ_subscripts(1,:),succ_subscripts(2,:),succ_subscripts(3,:),succ_subscripts(4,:),succ_subscripts(5,:),succ_subscripts(6,:));
%         
%         % Check that all successors are controllable
%         if any(Controller(succ_indices) == 0)
%             error('Synthesized controller does not satisfy the specifications')
%         end
%     end
% end

%% Wrapping on state 3

% Skip safety on orientation:
%     % no safety condition on the orientation (state 3)
%     if any(succ_low([1:2,4:end])<1 | succ_up([1:2,4:end])>sym_x([1:2,4:end]))
%         continue
%     end

% removing safety on psi means that the sub2ind or ind2sub might not work !!
%   if "unsafe" only on the psi dimension
%   => need to shift/wrap before ??

% rename the 3rd dimension of the symbol to one in the bounds ?
%   PB: we might not have an interval anymore, but 2!

% should it be done before converting to symbols ?
% if there is wrapping, this might give weird stuff ???
%   depending on sym_x(3), wrapped symbols might not match the real symbols

% Make something independant of what is considered for the reference/psi_low => so that we can adapt psi_low to the specs
% replace +/- pi by X_low(3) and X_up(3) ?

% % Bring the resulting angles (3rd dimension) to [-pi,pi]
% mod_low = mod(Succ_low(3)+pi,2*pi)-pi;
% mod_up = mod(Succ_up(3)+pi,2*pi)-pi;
% bool_disjoint_modulo = 0;
% if Succ_up(3) - Succ_low(3) >= 2*pi     % Covers the whole interval [-pi,pi]
%     Succ_low(3) = -pi;
%     Succ_up(3) = pi;
% elseif mod_low < mod_up                 % Just shift the successors to [-pi,pi]
%     Succ_low(3) = mod_low;
%     Succ_up(3) = mod_up;
% else                                    % Results in 2 disjoint intervals [-pi mod_up] and [mod_low pi]
%     bool_disjoint_modulo = 1;
%     Succ_low(3) = mod_low;
%     Succ_up(3) = mod_up;
% end

