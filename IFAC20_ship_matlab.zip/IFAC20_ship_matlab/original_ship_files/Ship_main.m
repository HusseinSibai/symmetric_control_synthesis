%% Main call for the abstraction-based control synthesis on the ship
close all
clear
addpath(genpath('./TIRA'))  % Add access to reachability toolbox folder
% addpath(genpath('./multipoly'))  % Add access to polynomial toolbox folder
diary Ship_abstraction_Diary
disp(datestr(now))

% Load error bounds from SOS
SOS_filename = 'result_Ts3.mat';
load(SOS_filename,'e1lbval','e1ubval','e2lbval','e2ubval','e3lbval','e3ubval','e4lbval','e4ubval','e5lbval','e5ubval','e6lbval','e6ubval')
% load(SOS_filename,'e1lbval','e1ubval','e2lbval','e2ubval','e3lbval','e3ubval','e4lbval','e4ubval','e5lbval','e5ubval','e6lbval','e6ubval','Vval','err','gamma_list','kval','uhat','t')

try
    %% Initialization of the problem
    
    % Reachability method (3=CTMM, 4=SDMM with sampling, 5=SDMM with IA)
    OA_method = 3;

    % State space definition
    %   N/E for camera range: 10*6.5m
    %   orientation range [-pi,pi] ; psi=0 is pointing North
    X_up = [10;6.5;pi];
    X_low = [0;0;-pi];
    n_x = numel(X_up);

    % Input space
    %   surge velocity: [-0.18,0.18]m/s
    %   sway velocity: [-0.1,0.1]m/s
    %   yaw rate: [-0.1,0.1]rad/s
%     U_up = [0.18;0.1;0.1];
%     U_low = [-0.18;-0.1;-0.1];
    U_up = [0.18;0.05;0.1];
    U_low = [0;-0.05;-0.1];
    n_u = numel(U_up);

    % Disturbance space: current velocity
    W_up = [0.01;0.01;0.01];  % assume low currents around the docks
    W_low = -W_up;

    % Target interval for the reachability problem
    %   go North towards a West-East docking band (N in [6,10], E in [0,6.5])
    %   with the ship facing East (+/-30° around 90° => [pi/3,2*pi/3])
%     Target_up = [10;6.5;2*pi/3];
%     Target_low = [6;0;pi/3];
    Target_up = [10;6.5;2*pi/3];
    Target_low = [7;0;pi/3];

    % Obstacles
%     Obstacle_up = [[5;2;pi] [3;6;pi]];
%     Obstacle_low = [[3;0;-pi] [0;5;-pi]];
    Obstacle_up = [[2.5;3;pi] [5.5;6.5;pi]];
    Obstacle_low = [[2;0;-pi] [5;3.5;-pi]];
    
    % Error bounds induced by the model reduction
    error_6D_up = [e1ubval;e2ubval;e3ubval;e4ubval;e5ubval;e6ubval];
    error_6D_low = [e1lbval;e2lbval;e3lbval;e4lbval;e5lbval;e6lbval];
    error_6D = max(abs(error_6D_low),abs(error_6D_up));

    % State space partition
    sym_x = 50*ones(n_x,1);

    % Input set discretization
    sym_u = 9*ones(n_u,1);

    % Time step
    time_step = 3;    % seconds

    % State dimensions considered for abstraction
    % state_dimensions = [1 1 1];   % Classical abstraction on all 3 dimensions
    state_dimensions = [0 0 1];   % Exploit translational symmetry on the first 2 dimensions

    %% Create a save file
    filebase = './Saves/Ship_abstraction';
    file_index=1;
    while 1
        filename = [filebase num2str(file_index) '.mat'];
        % If the file does not exist, stop looking and compute the automaton
        if ~exist(filename,'file')
            break
        end
        file_index = file_index + 1;
    end

    save(filename,'X_low','X_up','sym_x','U_low','U_up','sym_u','W_low','W_up','time_step','state_dimensions','Target_low','Target_up','Obstacle_low','Obstacle_up','error_6D','OA_method','SOS_filename','-v7.3');
%     uhat_SOS = uhat;
%     t_SOS = t;
%     save(filename,'Vval','err','gamma_list','kval','uhat_SOS','t_SOS','-append');
    
    %% Update specifications with error bounds
    
    % Shrink state space/safety
    X_up = X_up - error_6D(1:n_x);
    X_low = X_low + error_6D(1:n_x);
    
    % Shrink target set
    Target_up = Target_up - error_6D(1:n_x);
    Target_low = Target_low + error_6D(1:n_x);
    
    % Expand obstacles (with saturations)
    for i=1:size(Obstacle_up,2)
        Obstacle_up(:,i) = min(Obstacle_up(:,i) + error_6D(1:n_x),X_up);
        Obstacle_low(:,i) = max(Obstacle_low(:,i) - error_6D(1:n_x),X_low);
    end
    
    %% Open parallel pool of workers
    poolobj = gcp('nocreate') % If a pool is not open, do not create new one.
    if isempty(poolobj)
        parpool([1 24])
    end
    
    %% Abstraction creation
    tic_abstraction = tic;
    [Symbolic_reduced,U_discrete,unsafe_trans] = Centralized_abstraction(X_low,X_up,sym_x,U_low,U_up,sym_u,W_low,W_up,time_step,state_dimensions,OA_method);
    toc_abstraction = toc(tic_abstraction);
    save(filename,'Symbolic_reduced','U_discrete','unsafe_trans','toc_abstraction','-append');

    %% Control synthesis

    % Convert target interval to the largest set of symbols it fully contains
    symbol_step = (X_up-X_low)./sym_x;
    Target_low = ceil(1+(Target_low-X_low)./symbol_step);
    Target_up = floor((Target_up-X_low)./symbol_step);
    
    % Convert obstacle interval to the set of symbols it intersects
    for i=1:size(Obstacle_up,2)
        Obstacle_low(:,i) = floor(1+(Obstacle_low(:,i)-X_low)./symbol_step);
        Obstacle_up(:,i) =ceil((Obstacle_up(:,i)-X_low)./symbol_step);
    end

    % Synthesize a controller
    tic_synthesis = tic;
    Controller = Reach_avoid_synthesis(Symbolic_reduced,unsafe_trans,sym_x,sym_u,state_dimensions,Target_low,Target_up,Obstacle_low,Obstacle_up);
    toc_synthesis = toc(tic_synthesis);
    save(filename,'Controller','toc_synthesis','-append');

catch Error_message
    Error_message
    save(filename,'Error_message','-append');
end

% Close parallel pool
delete(gcp)

% Display all variables and sizes
whos

% Write console in diary file
diary off

%% Check N/E coverage of the controllable states

% If used alone, recall and update the state space, target and obstacles
filename = './Saves/Ship_abstraction17.mat';
load(filename,'Controller','Obstacle_low','Obstacle_up','Target_low','Target_up','X_low','X_up','sym_x','error_6D')
n_x = numel(X_low);
X_3D_shrunk_up = X_up - error_6D(1:n_x);
X_3D_shrunk_low = X_low + error_6D(1:n_x);
symbol_step = (X_3D_shrunk_up-X_3D_shrunk_low)./sym_x;
Target_shrunk_up = Target_up - error_6D(1:n_x);
Target_shrunk_low = Target_low + error_6D(1:n_x);
Target_sym_low = ceil(1+(Target_shrunk_low-X_3D_shrunk_low)./symbol_step);
Target_sym_up = floor((Target_shrunk_up-X_3D_shrunk_low)./symbol_step);
for i=1:size(Obstacle_up,2)
    Obstacle_shrunk_up(:,i) = min(Obstacle_up(:,i) + error_6D(1:n_x),X_3D_shrunk_up);
    Obstacle_shrunk_low(:,i) = max(Obstacle_low(:,i) - error_6D(1:n_x),X_3D_shrunk_low);
    Obstacle_sym_low(:,i) = floor(1+(Obstacle_shrunk_low(:,i)-X_3D_shrunk_low)./symbol_step);
    Obstacle_sym_up(:,i) =ceil((Obstacle_shrunk_up(:,i)-X_3D_shrunk_low)./symbol_step);
end

% Initialize 2D N/E matrix
Controllable_NE = NaN(sym_x(1),sym_x(2));

% Add '0' for target cells and obstacles
Controllable_NE(Target_sym_low(1):Target_sym_up(1),Target_sym_low(2):Target_sym_up(2)) = 0;
for i=1:size(Obstacle_up,2)
    Controllable_NE(Obstacle_sym_low(1,i):Obstacle_sym_up(1,i),Obstacle_sym_low(2,i):Obstacle_sym_up(2,i)) = 0;
end

% Get controllable states
controllable = find(Controller);
for s_ind = 1:nnz(Controller)
    s = controllable(s_ind);
    
    % Convert 1D s index to 3D subscript
    [s1,s2,s3] = ind2sub(sym_x',s);
    s_subscript = [s1;s2;s3];
    
    Controllable_NE(s1,s2) = 1;
end
Controllable_NE

close all
figure
hold on

% State space
rectangle('Position',[X_low(1) X_low(2) X_up(1)-X_low(1) X_up(2)-X_low(2)],'Linewidth',2)
rectangle('Position',[X_3D_shrunk_low(1) X_3D_shrunk_low(2) X_3D_shrunk_up(1)-X_3D_shrunk_low(1) X_3D_shrunk_up(2)-X_3D_shrunk_low(2)])

% Partition grid
for j=1:sym_x(1)
    plot([X_3D_shrunk_low(1)+j*symbol_step(1) X_3D_shrunk_low(1)+j*symbol_step(1)], [X_3D_shrunk_low(2) X_3D_shrunk_up(2)],':k')
end
for j=1:sym_x(2)
    plot([X_3D_shrunk_low(1) X_3D_shrunk_up(1)],[X_3D_shrunk_low(2)+j*symbol_step(2) X_3D_shrunk_low(2)+j*symbol_step(2)],':k')
end

% Fill target and obstacle symbols
rectangle('Position',[X_3D_shrunk_low(1)+(Target_sym_low(1)-1)*symbol_step(1) X_3D_shrunk_low(2)+(Target_sym_low(2)-1)*symbol_step(2) (Target_sym_up(1)-Target_sym_low(1)+1)*symbol_step(1) (Target_sym_up(2)-Target_sym_low(2)+1)*symbol_step(2)],'FaceColor','g')
for i=1:size(Obstacle_up,2)
    rectangle('Position',[X_3D_shrunk_low(1)+(Obstacle_sym_low(1,i)-1)*symbol_step(1) X_3D_shrunk_low(2)+(Obstacle_sym_low(2,i)-1)*symbol_step(2) (Obstacle_sym_up(1,i)-Obstacle_sym_low(1,i)+1)*symbol_step(1) (Obstacle_sym_up(2,i)-Obstacle_sym_low(2,i)+1)*symbol_step(2)],'FaceColor','k')
end

figure
hold on
for s1=1:sym_x(1)
    for s2=1:sym_x(2)
        if Controllable_NE(s1,s2) == 1
            s_low = X_3D_shrunk_low(1:2) + ([s1;s2]-1).*symbol_step(1:2);
            s_up = s_low + symbol_step(1:2);
            rectangle('Position',[s_low(1) s_low(2) s_up(1)-s_low(1) s_up(2)-s_low(2)],'FaceColor','b')
        end
    end
end

% Controllable symbol indices for the bottom-left corner
a=reshape(Controller,[sym_x(1),sym_x(2),sym_x(3)]);
b=find(a(1,1,:));
for i=1:numel(b)
    b(i)=sub2ind(sym_x,1,1,b(i));
end
b
