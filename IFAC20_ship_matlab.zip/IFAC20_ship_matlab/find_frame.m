% HUSSEIN
% function that tries to find a set of frames (or equivalently, states) in 
% the full coordinates such that when a given set (hyperrectangle) in the
% reduced coordinates is assumed to be represented in the coordinate 
% systems defined by those frames and then transformed accordingly to the
% full coordinates, the resulting sets are included in a given target set
% (represented in full coordinates).
% This function should be implemented by the user based on the symmetries
% that define the moving frame.
% This is an example implementation for the ship coordinates (after being
% reduced through the continuous abstraction in Meyer et al.) 

function rect_curr = find_frame(low_red, up_red, target_full_low, target_full_up, symbol_step)
    if up_red(3) - low_red(3) > target_full_up(3) - target_full_low(3)
%         curr_low = NaN;
%         curr_up = NaN;
          rect_curr = NaN;
%         'up_red(3) - low_red(3)'
%         up_red(3) - low_red(3)
%         'target_full_up(3) - target_full_low(3)'
%         target_full_up(3) - target_full_low(3)
        return
    end
    rect_curr = [];
    theta_low_sys = target_full_low(3) - low_red(3);
    theta_up_sys = target_full_up(3) - up_red(3);
    if 0 && (theta_up_sys - theta_low_sys)/(2 * symbol_step(3)) > 1.1
        target_up_temp = target_full_up;
        target_up_temp(3) = up_red(3) + theta_low_sys + 2 * symbol_step(3); 
        target_low_temp = target_full_low;
        for i = 0:floor((theta_up_sys - theta_low_sys)/(2 * symbol_step(3)))-1
            rect_curr_temp = find_frame(low_red, up_red, target_low_temp, target_up_temp, symbol_step);
            rect_curr = cat(3, rect_curr, rect_curr_temp);
            target_low_temp(3) = target_low_temp(3) + 2 * symbol_step(3);
            target_up_temp(3) = target_up_temp(3) + 2 * symbol_step(3);
        end
        target_low_temp(3) = target_low_temp(3) - 2 * symbol_step(3);
        target_up_temp(3) = target_full_up(3);
        theta_low_sys = target_low_temp(3) - low_red(3);
        theta_up_sys = target_up_temp(3) - up_red(3);
    end
    % x_low_1 = (low_red(1)) * cos(theta_low) - (low_red(2)) * sin(theta_low); % xs1 + x_n #
    % y_low_1 = (low_red(1)) * sin(theta_low) + (low_red(2)) * cos(theta_low); % ys1 + y_n #
    % x_up_1 = (up_red(1)) * cos(theta_low) - (up_red(2)) * sin(theta_low); % xs1 + x_n #
    % y_up_1 = (up_red(1)) * sin(theta_low) + (up_red(2)) * cos(theta_low); % ys1 + y_n #

    % Hussein: in here, we are assuming that the rectangle is being rotated by angle
    % theta_low, however, in transform_to_frame, it is the coordinate
    % systems that is being rotated by theta, or frame(3). this has to be
    % fixed

    % Hussein: fixing it now. After transforming the coordinate
    % system in which the not-necessarily-axis-aligned rectangle 
    % r_1 with upper-right corner [x_target_up_1, y_target_up_1] is
    % represented
    % by translating it with vector ?? and then rotating it with angle 
    % theta_low_sys, the result should be the axis-aligned rectangle
    % [low_red, up_red].
    % Hence, the angle from the x-axis to r_1 is theta_low_sys.
    % Moreover, the translation vector can be computed by rotating the
    % coordinate system in which up_red is represented with angle 
    % -1 * theta_low_sys then subtracting the result from [x_target_up_1, 
    % y_target_up_1]. 
    theta_low = theta_low_sys;
    theta_up = theta_up_sys;

    if theta_low >= 0 && theta_low <= pi/2
        x_target_up_1 = target_full_up(1) - (up_red(2) - low_red(2)) * cos(pi/2 - theta_low);
        y_target_up_1 = target_full_up(2);
    elseif theta_low >= pi/2 && theta_low <= pi
        x_target_up_1 = target_full_up(1) - (up_red(1) - low_red(1)) * sin(theta_low - pi/2) - (up_red(2) - low_red(2)) * cos(theta_low - pi/2);
        y_target_up_1 = target_full_up(2) - (up_red(2) - low_red(2)) * sin(theta_low - pi/2);
    elseif theta_low < 0 && theta_low >= - pi/2
        x_target_up_1 = target_full_up(1);
        y_target_up_1 = target_full_up(2)  - (up_red(1) - low_red(1)) * sin(-1 * theta_low);
    else
        x_target_up_1 = target_full_up(1);
        y_target_up_1 = target_full_up(2)  - (up_red(2) - low_red(2)) * sin(-1 * theta_low - pi/2);
        x_target_up_1 = x_target_up_1 - (up_red(1) - low_red(1)) * sin(-1 * theta_low - pi/2);
        y_target_up_1 = y_target_up_1 - (up_red(1) - low_red(1)) * cos(-1 * theta_low - pi/2);
    end

    if theta_low >= 0 && theta_low <= pi/2
        x_target_low_1 = target_full_low(1) + (up_red(2) - low_red(2)) * cos(pi/2 - theta_low);
        y_target_low_1 = target_full_low(2);

    elseif theta_low >= pi/2 && theta_low <= pi
        x_target_low_1 = target_full_low(1) + (up_red(1) - low_red(1)) * cos(pi - theta_low) + (up_red(2) - low_red(2)) * cos(theta_low - pi/2);
        y_target_low_1 = target_full_low(2) + (up_red(2) - low_red(2)) * sin(theta_low - pi/2);
        
    elseif theta_low < 0 && theta_low >= - pi/2
        x_target_low_1 = target_full_low(1);
        y_target_low_1 = target_full_low(2) + (up_red(1) - low_red(1)) * cos(pi/2 + theta_low);

    else
        x_target_low_1 = target_full_low(1) + (up_red(1) - low_red(1)) * cos(pi + theta_low);
        y_target_low_1 = target_full_low(2) + (up_red(1) - low_red(1)) * sin(pi + theta_low) + (up_red(2) - low_red(2)) * cos(pi + theta_low);
    end
    % curr_low_1 = [x_target_low_1 - (low_red(1)) * cos(theta_low_sys) + (low_red(2)) * sin(theta_low_sys), y_target_low_1 - (low_red(1)) * sin(theta_low_sys) - (low_red(2)) * cos(theta_low_sys), theta_low_sys];
    % curr_up_1 = [x_target_up_1 - (up_red(1)) * cos(theta_low_sys) + (up_red(2)) * sin(theta_low_sys), y_target_up_1 - (up_red(1)) * sin(theta_low_sys) - (up_red(2)) * cos(theta_low_sys), theta_low_sys];
    
    curr_low_1 = [x_target_low_1 - (low_red(1)) * cos(theta_low_sys) + (low_red(2)) * sin(theta_low_sys), y_target_low_1 - (low_red(1)) * sin(theta_low_sys) - (low_red(2)) * cos(theta_low_sys), theta_low_sys];
    curr_up_1 = [x_target_up_1 - (up_red(1)) * cos(theta_low_sys) + (up_red(2)) * sin(theta_low_sys), y_target_up_1 - (up_red(1)) * sin(theta_low_sys) - (up_red(2)) * cos(theta_low_sys), theta_low_sys];

    %%%%%%%%%%%%%%%%%%%%%

    if theta_up >= 0 && theta_up <= pi/2
        x_target_up_2 = target_full_up(1) - (up_red(2) - low_red(2)) * cos(pi/2 - theta_up);
        y_target_up_2 = target_full_up(2);
    elseif theta_up >= pi/2 && theta_up <= pi
        x_target_up_2 = target_full_up(1) - (up_red(1) - low_red(1)) * sin(theta_up - pi/2) - (up_red(2) - low_red(2)) * cos(theta_up - pi/2);
        y_target_up_2 = target_full_up(2) - (up_red(2) - low_red(2)) * sin(theta_up - pi/2);
    elseif theta_up < 0 && theta_up >= - pi/2
        x_target_up_2 = target_full_up(1);
        y_target_up_2 = target_full_up(2)  - (up_red(1) - low_red(1)) * sin(-1 * theta_up);
    else
        x_target_up_2 = target_full_up(1);
        y_target_up_2 = target_full_up(2)  - (up_red(2) - low_red(2)) * sin(-1 * theta_up - pi/2);
        x_target_up_2 = x_target_up_2 - (up_red(1) - low_red(1)) * sin(-1 * theta_up - pi/2);
        y_target_up_2 = y_target_up_2 - (up_red(1) - low_red(1)) * cos(-1 * theta_up - pi/2);
    end

    if theta_up >= 0 && theta_up <= pi/2
        x_target_low_2 = target_full_low(1) + (up_red(2) - low_red(2)) * cos(pi/2 - theta_up);
        y_target_low_2 = target_full_low(2);

    elseif theta_up >= pi/2 && theta_up <= pi
        x_target_low_2 = target_full_low(1) + (up_red(1) - low_red(1)) * cos(pi - theta_up) + (up_red(2) - low_red(2)) * cos(theta_up - pi/2);
        y_target_low_2 = target_full_low(2) + (up_red(2) - low_red(2)) * sin(theta_up - pi/2);
        
    elseif theta_up < 0 && theta_up >= - pi/2
        x_target_low_2 = target_full_low(1);
        y_target_low_2 = target_full_low(2) + (up_red(1) - low_red(1)) * cos(pi/2 + theta_up);

    else
        x_target_low_2 = target_full_low(1) + (up_red(1) - low_red(1)) * cos(pi + theta_up);
        y_target_low_2 = target_full_low(2) + (up_red(1) - low_red(1)) * sin(pi + theta_up) + (up_red(2) - low_red(2)) * cos(pi + theta_up);
    end

    curr_low_2 = [x_target_low_2 - (low_red(1)) * cos(theta_up_sys) + (low_red(2)) * sin(theta_up_sys), y_target_low_2 - (low_red(1)) * sin(theta_up_sys) - (low_red(2)) * cos(theta_up_sys), theta_up_sys];
    curr_up_2 = [x_target_up_2 - (up_red(1)) * cos(theta_up_sys) + (up_red(2)) * sin(theta_up_sys), y_target_up_2 - (up_red(1)) * sin(theta_up_sys) - (up_red(2)) * cos(theta_up_sys), theta_up_sys];
    
    curr_low_temp = max(curr_low_1, curr_low_2);
    curr_up_temp = min(curr_up_1, curr_up_2);
    curr_low = min(curr_low_temp,curr_up_temp);
    curr_up = max(curr_low_temp,curr_up_temp);
    if check_rect_empty([curr_low; curr_up])
        'Result is an empty rectangle!!'
        curr_low
        curr_up
    end
    curr_low_1
    curr_low_2
    curr_up_1
    curr_up_2
    curr_low
    curr_up
    rect_curr = cat(3, rect_curr, [curr_low; curr_up]);
    %curr_low = curr_low';
    %curr_up = curr_up';
end


function empty = check_rect_empty(rect)
    if all(rect(1, :) < rect(2, :))
        empty = 0;
    else
        empty = 1;
    end
    
end 


    % x_mid_1 = (x_low_1 + x_up_1) / 2;
    % y_mid_1 = (y_low_1 + y_up_1) / 2;

    % x_low_2 = (low_red(1)) * cos(theta_up) - (low_red(2)) * sin(theta_up); % xs1 + x_n #
    % y_low_2 = (low_red(1)) * sin(theta_up) + (low_red(2)) * cos(theta_up); % ys1 + y_n #
    % x_up_2 = (up_red(1)) * cos(theta_up) - (up_red(2)) * sin(theta_up); % xs1 + x_n #
    % y_up_2 = (up_red(1)) * sin(theta_up) + (up_red(2)) * cos(theta_up); % ys1 + y_n 

    % x_mid_2 = (x_low_1 + x_up_1) / 2;
    % y_mid_2 = (y_low_1 + y_up_1) / 2;


    % test: [a,b] = find_frame([-0.5,3,-pi/8],[0.5,4,pi/8],[10,50,-pi/2],[20,55,pi/2])
