% HUSSEIN
% function that computes transforms a state from the
% full coordinates to the reduced coordinates.
% This function should be implemented by the user based on the symmetries
% that define the moving frame.
% This is an example implementation for the ship coordinates (after being
% reduced through the continuous abstraction in Meyer et al.) 


function v_transformed = transform_to_frame(v, frame)
    % transforms v to the new coordinate system that is translated by
    % -1 * frame(1:2) and rotated by frame(3), that will make the heading
    % angle being v(3) - frame(3)
    sc = -1 * frame(3);
    translation_vector = -1 * frame(1:2);
    v_transformed = [(v(1) + translation_vector(1)) * cos(sc) - (v(2) + translation_vector(2)) * sin(sc)]; % xs1 + x_n #
    v_transformed = [v_transformed (v(1) + translation_vector(1)) * sin(sc) + (v(2) + translation_vector(2)) * cos(sc)]; % ys1 + y_n #
    v_transformed = [v_transformed (v(3) + sc)];
