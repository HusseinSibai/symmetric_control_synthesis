%% Controller synthesis for the reachability specification on the ship model
% With additional safety conditions of staying in the bounded state space
% and unsafe/obstacle sets within the state space.

% The obstacle avoidance is fully handled by skipping obstacle symbols in
% the loop of symbols to explore, thus ensuring that no obstacle symbol is
% ever added to the expanded list of target symbols.
% HUSSEIN: adding X_low and X_up as parameters since the successor in
% Symbolic_reduced is now an interval and the output of find_frame is an
% (list of?) interval instead of a list of symbols. Same goes for targets 
% and obstacles. They have to be changed from intervals to symbols. The
% same goes to targets and obstacles.
function Controller = Reach_avoid_synthesis(Symbolic_reduced,unsafe_trans,sym_x,sym_u,state_dimensions,Target_low,Target_up,Obstacle_low,Obstacle_up, X_low, X_up, U_low, U_up)

tic
n = numel(state_dimensions);
matrix_dim_full = [prod(sym_x),prod(sym_u),2*n];
sym_x_reduced = sym_x.*state_dimensions' + ~state_dimensions';
if range(sym_u)==0
    sym_u = sym_u(1);
    ui_values = 1:sym_u;
    U_discrete = Gray(ui_values,size(U_low,1),sym_u);
    U_discrete = repmat(U_low,1,sym_u^size(U_low,1)) + (U_discrete-1).*repmat((U_up-U_low)/(sym_u-1),1,sym_u^size(U_low,1));
else
    error('Non-homogeneous input discretization cannot be handled yet')
end
matrix_dim_reduced = [prod(sym_x_reduced),size(U_discrete,2),2*n];

% HUSSEIN: since in the new implementation we go backwards by finding the
% set of frames that will make the transformed version of the successor of 
% a symbol in the reduced coordinates belong to the target, that set of
% frames will be a new target set of states (after excluding obstacles) for
% the following synthesis iterations.
% Since target is updated in the loop, parallel execution of the code might
% be affected. This has to be rethought.
% targets = [Target_low Target_up];
% Target_low = [Target_low];
% Target_up  = [Target_up];
symbol_step = (X_up-X_low)./sym_x; 

% HUSSEIN: pasting these two blocks of code from Ship_main.m. Commenting
% the targets again, since we do not need the discretized values (or symbols
% of the targets, in contrast with the previous implementation.
%% Target symbol indices
Target_low = ceil(1+(Target_low-X_low)./symbol_step);
Target_up = floor((Target_up-X_low)./symbol_step);

% Convert obstacle interval to the set of symbols it intersects
for i=1:size(Obstacle_up,2)
    Obstacle_low(:,i) = floor(1+(Obstacle_low(:,i)-X_low)./symbol_step);
    Obstacle_up(:,i) = ceil((Obstacle_up(:,i)-X_low)./symbol_step);
end

% Extract subscripts (on each dimension) for the corresponding target symbols
Target_width = Target_up - Target_low + ones(n,1);
target_subscripts = cell(n,1);
[target_subscripts{:}] = ind2sub(Target_width',1:prod(Target_width));
target_subscripts = cell2mat(target_subscripts);
target_subscripts = bsxfun(@plus, target_subscripts, Target_low-ones(n,1));

% Convert 3D subscripts into 1D indices
target_indices = sub2ind(sym_x',target_subscripts(1,:),target_subscripts(2,:),target_subscripts(3,:));

%% Obstacle symbol indices

obstacle_indices = [];
for i=1:size(Obstacle_up,2)
    % Extract subscripts (on each dimension) for the corresponding obstacles symbols
    Obstacle_width = Obstacle_up(:,i) - Obstacle_low(:,i) + ones(n,1);
    obstacle_subscripts = cell(n,1);
    [obstacle_subscripts{:}] = ind2sub(Obstacle_width',1:prod(Obstacle_width));
    obstacle_subscripts = cell2mat(obstacle_subscripts);
    obstacle_subscripts = bsxfun(@plus, obstacle_subscripts, Obstacle_low(:,i)-ones(n,1));
    
    % Convert 3D subscripts into 1D indices
    obstacle_indices = [obstacle_indices sub2ind(sym_x',obstacle_subscripts(1,:),obstacle_subscripts(2,:),obstacle_subscripts(3,:))];
end

%% Main synthesis loop

% Initialization of the controller (0 = not controllable or in target)
Controller = zeros(matrix_dim_full(1),1);

% Loop for the reachability synthesis
fprintf('\n%s\tStart of the control synthesis\n',num2str(datestr(now)))
while 1
    % Loop on all symbols to explore (not an obstacle, and not yet in the (expanded) target set)
    % TODO: HUSSEIN: here is a bottleneck, iteration over all symbols 
    % in the global model, it should be only over the reduced/abstract one. 
    % I'm commenting the next couple of lines to loop only over symbols of
    % the reduced model.
    % symbols_to_explore = setdiff(1:matrix_dim_full(1),target_indices);
    % symbols_to_explore = setdiff(symbols_to_explore,obstacle_indices);
    % symbols_to_explore = 1:matrix_dim_reduced(1);
    % Controller_temp = zeros(numel(symbols_to_explore),1);
    % HUSSEIN: initializing the targets_temp and Controller_temp at each
    % iteration
    targets_temp = [];
    % 'Size of target indices'
    % size(target_indices)
    % Controller_temp = [];
    progress_indicator = 0;
    % parfor
    for s_ind = 1:matrix_dim_reduced(1) % numel(symbols_to_explore)
%     for s_ind = 1:numel(symbols_to_explore)
        % s = symbols_to_explore(s_ind);
        % Loop on the control inputs
        for u = 1:matrix_dim_reduced(2) %matrix_dim_full(2)
            % u = U_discrete(:,k);
            % Convert 1D s index to 3D subscript
            % [s1,s2,s3] = ind2sub(sym_x',s);
            % s_subscript = [s1;s2;s3];

            % Get corresponding 1D index in the reduced model
            % HUSSEIN: have to change the following to get 1D index in the
            % generalized model. Actually, the index is already for the
            % reduced model, so we will comment this line since it was
            % transforming the index in the original model to the reduced
            % one.
            % s_reduced_ind = 1+(s-s_subscript(1)-(s_subscript(2)-1)*sym_x(1))/(sym_x(1)*sym_x(2));
            
            % Discard pair (s,u) if it leads outside of the state space
            % on the states in state_dimensions
            % HUSSEIN
            % I commented the following if-condition since as in the
            % centralized_abstraction.m file, the angle is now reduced
            % with the model.
            % if unsafe_trans(s_reduced_ind,u)
            %    continue
            % end

            % Get successor interval in the global model
            % HUSSEIN: I will comment the next couple of lines since we
            % will go backwards in our synthesis
            % We will get the successor interval for the current symbol in
            % the reduced system. Then, we will get the state in the global
            % model such that the succ_up is aligned with the up of the
            % target. Similarly 
            % succ_low = shiftdim(Symbolic_reduced(s_reduced_ind,u,1:n),2) + (s_subscript-1).*(~state_dimensions');
            % succ_up = shiftdim(Symbolic_reduced(s_reduced_ind,u,n+1:end),2) + (s_subscript-1).*(~state_dimensions');
            % targets_size = size(targets);

            for target_ind = 1:length(target_indices) % targets_size(1)
                s = target_indices(target_ind);
                [s1,s2,s3] = ind2sub(sym_x',s);
                % s_subscript = [s1;s2;s3];
                Target_low = X_low'+symbol_step'.*([s1,s2,s3]-1);
                Target_up = X_low'+symbol_step'.*[s1,s2,s3];
                % Target_low =  % targets(target_ind,1:n);
                % Target_up = % targets(target_ind,n+1:end);
                [curr_low,curr_up] = find_frame(Symbolic_reduced(s_ind,u,1:n), Symbolic_reduced(s_ind,u,n+1:end), Target_low, Target_up);
                if ~isnan(curr_low)
                    % 'hit'
                    % targets_temp = [targets_temp; [curr_low curr_up]];
                    % HUSSEIN: these were copy-pasted from below, but they
                    % assume that the Symbolic_reduced store the symbols
                    % not intervals. That has to be fixed. Bringing the
                    % following statement (adjusted to be curr instead of
                    % succ) from Centralized_abstraction.m
                    curr_low = max(curr_low, X_low); % making sure curr is in X
                    curr_up = min(curr_up, X_up);
                    % getting the symbols => this can be more improved
                    % later to not consider symbols at all.
                    curr_low = ceil((curr_low - X_low) ./ symbol_step);
                    curr_up = ceil((curr_up - X_low) ./ symbol_step);
                    % [curr_low;curr_up] = ceil(([curr_low;curr_up]-[X_low;X_low])./[symbol_step;symbol_step])
                    curr_width = curr_up - curr_low + ones(n,1); 
                    curr_subscripts = cell(n,1);
                    [curr_subscripts{:}] = ind2sub(curr_width',1:prod(curr_width));
                    curr_subscripts = cell2mat(curr_subscripts);
                    curr_subscripts = bsxfun(@plus, curr_subscripts, curr_low - ones(n,1)); %  
                    % transforming the subscripts to indices
                    % 'before_sub2ind'
                    % curr_subscripts(1,:)
                    % curr_subscripts(2,:)
                    % curr_subscripts(3,:)
                    for i = 1:size(curr_subscripts,1)
                        for j = 1:size(curr_subscripts,2)
                            if curr_subscripts(i,j) < 1
                                curr_subscripts(i,j) = 1;
                            elseif curr_subscripts(i,j) > sym_x(i)
                                curr_subscripts(i,j) = sym_x(i);
                            end
                        end
                    end
                    curr_indices_temp = sub2ind(sym_x',curr_subscripts(1,:),curr_subscripts(2,:),curr_subscripts(3,:));
                    % 'length_curr_indices'
                    % length(curr_indices)
                    % 'after_sub2ind'
                    % removing the indices that correspond to obstacles.
                    curr_indices_temp = setdiff(curr_indices_temp, obstacle_indices);
                    curr_indices = [];
                    for curr_index_ind = 1:length(curr_indices_temp)
                        curr_index_temp = curr_indices_temp(curr_index_ind);
                        % if not(ismember(curr_index)) % all(ismember(succ_indices,target_indices))
                        % Add current control to controller
                        % HUSSEIN: commenting the following line and adding
                        % an edited one
                        % Controller_temp(s_ind) = u;
                        if Controller(curr_index_temp) == 0
                            Controller(curr_index_temp) = u;
                            curr_indices = [curr_indices curr_index_temp];
                            progress_indicator = progress_indicator + 1;
                            % Controller_temp = [Controller_temp; [curr_index u]];
                        end
                        % Controller(s) = u;
                        % HUSSEIN: DON'T Stop looking at other control
                        % inputs since they might reveal other controllable
                        % states => commenting the break
                        % break
                        % end
                    end
                    targets_temp = [targets_temp curr_indices];
                    % targets_temp = setdiff(targets_temp, target_indices);
                end
            end
            % Discard pair (s,u) if it leads outside of the state space
            % on the states NOT in state_dimensions
            % TODO: HUSSEIN: commenting the following if-condition since
            % the frame is defined so that the successor is in target.
            % if any(succ_low(~state_dimensions)<1 | succ_up(~state_dimensions)>sym_x(~state_dimensions))
            %    continue
            % end
            
            % HUSSEIN: commenting this code block and moving a modified
            % version of it up to get the symbols of the current set of
            % states instead of the successor.
            % Extract subscripts for the covered symbols
            % succ_width = succ_up - succ_low + ones(n,1);
            % succ_subscripts = cell(n,1);
            % [succ_subscripts{:}] = ind2sub(succ_width',1:prod(succ_width));
            % succ_subscripts = cell2mat(succ_subscripts);
            % succ_subscripts = bsxfun(@plus, succ_subscripts, succ_low-ones(n,1));
            
            % Convert 3D subscripts into 1D indices
            % succ_indices = sub2ind(sym_x',succ_subscripts(1,:),succ_subscripts(2,:),succ_subscripts(3,:));
            
            % Check if the pair fully goes into the target set
            % HUSSEIN: commenting the following code.
            % if all(ismember(succ_indices,target_indices))
                % Add current control to controller
            %    Controller_temp(s_ind) = u;
                % Stop looking at other control inputs
            %    break
            % end
        end
    end
    
    % Check if the synthesis progressed during this iteration
    % HUSSEIN: changing the following check
    if progress_indicator % ~isempty(Controller_temp) % any(Controller_temp)
        fprintf('%s\t%d new controllable states have been found in this synthesis iteration\n',num2str(datestr(now)), progress_indicator) % nnz(Controller_temp)
        % HUSSEIN: adding the following line, at each iteration of the
        % while loop, new rectangles are added. No need to explore old
        % targets that have already been explored.
        target_indices = targets_temp; 
        % Controller_temp_size = size(Controller_temp);
        % for ind = 1:Controller_temp_size(1) % s_ind = 1:numel(symbols_to_explore)
            % if Controller_temp(s_ind)
            % s = symbols_to_explore(s_ind);
            % Write the obtained results in the Controller variable
            % Controller(s) = Controller_temp(s_ind);
        %    Controller(Controller_temp(ind,1)) = Controller_temp(ind,2);
            % Controller_temp(s_ind);
            % And update the indices of target symbols
            % HUSSEIN: commented the following line since targets is
            % updated above.
            % target_indices = [target_indices, s];
            % end
        % end
    else
        % If not, stop the while loop (no more progress can be obtained)
        fprintf('%s\tNo new controllable state has been found in this synthesis iteration\n',num2str(datestr(now)))
        break
    end
end

disp(['Controller synthesis for reach-avoid specification: ' num2str(toc) ' seconds'])
controllable_states = nnz(Controller);
if controllable_states
    fprintf('%d of %d symbols are controllable to satisfy the reach-avoid specification\n',controllable_states,matrix_dim_full(1))
else
    fprintf('The reach-avoid specification cannot be satisfied from any initial state\n')
end
end

%% Check that the controller has been created properly
% %     this test needs to be modified, now that the target symbols are 0 instead of -1
% for s = 1:numel(Controller)
%     u = Controller(s);
%     if u > 0
%         % Convert 1D s index to 6D subscript
%         [s1,s2,s3,s4,s5,s6] = ind2sub(sym_x',s);
%         s_subscript = [s1;s2;s3;s4;s5;s6];
% 
%         % Get corresponding 1D index in the reduced model
%         s_reduced_ind = 1+(s-s_subscript(1)-(s_subscript(2)-1)*sym_x(1))/(sym_x(1)*sym_x(2));
% 
%         % Get successor interval in the global model
%         succ_low = shiftdim(Symbolic_reduced(s_reduced_ind,u,1:n),2) + s_subscript.*(~state_dimensions');
%         succ_up = shiftdim(Symbolic_reduced(s_reduced_ind,u,n+1:end),2) + s_subscript.*(~state_dimensions');
%         
%         % Extract subscripts for the covered symbols
%         succ_width = succ_up - succ_low + ones(n,1);
%         succ_subscripts = cell(n,1);
%         [succ_subscripts{:}] = ind2sub(succ_width',1:prod(succ_width));
%         succ_subscripts = cell2mat(succ_subscripts);
%         succ_subscripts = bsxfun(@plus, succ_subscripts, succ_low-ones(n,1));
%         
%         % Convert 6D subscripts into 1D indices
%         succ_indices = sub2ind(sym_x',succ_subscripts(1,:),succ_subscripts(2,:),succ_subscripts(3,:),succ_subscripts(4,:),succ_subscripts(5,:),succ_subscripts(6,:));
%         
%         % Check that all successors are controllable
%         if any(Controller(succ_indices) == 0)
%             error('Synthesized controller does not satisfy the specifications')
%         end
%     end
% end

%% Wrapping on state 3

% Skip safety on orientation:
%     % no safety condition on the orientation (state 3)
%     if any(succ_low([1:2,4:end])<1 | succ_up([1:2,4:end])>sym_x([1:2,4:end]))
%         continue
%     end

% removing safety on psi means that the sub2ind or ind2sub might not work !!
%   if "unsafe" only on the psi dimension
%   => need to shift/wrap before ??

% rename the 3rd dimension of the symbol to one in the bounds ?
%   PB: we might not have an interval anymore, but 2!

% should it be done before converting to symbols ?
% if there is wrapping, this might give weird stuff ???
%   depending on sym_x(3), wrapped symbols might not match the real symbols

% Make something independant of what is considered for the reference/psi_low => so that we can adapt psi_low to the specs
% replace +/- pi by X_low(3) and X_up(3) ?

% % Bring the resulting angles (3rd dimension) to [-pi,pi]
% mod_low = mod(Succ_low(3)+pi,2*pi)-pi;
% mod_up = mod(Succ_up(3)+pi,2*pi)-pi;
% bool_disjoint_modulo = 0;
% if Succ_up(3) - Succ_low(3) >= 2*pi     % Covers the whole interval [-pi,pi]
%     Succ_low(3) = -pi;
%     Succ_up(3) = pi;
% elseif mod_low < mod_up                 % Just shift the successors to [-pi,pi]
%     Succ_low(3) = mod_low;
%     Succ_up(3) = mod_up;
% else                                    % Results in 2 disjoint intervals [-pi mod_up] and [mod_low pi]
%     bool_disjoint_modulo = 1;
%     Succ_low(3) = mod_low;
%     Succ_up(3) = mod_up;
% end

%% Generation of possible values with (k,n)-Gray Code
function x = Gray(xi,n,k)
% From: Guan, Dah-Jyh (1998). "Generalized Gray Codes with Applications". 
% Proc. Natl. Sci. Counc. Repub. Of China (A) 22: 841???848. 
% http://nr.stpi.org.tw/ejournal/ProceedingA/v22n6/841-848.pdf.

x = zeros(n,k^n);   % The matrix with all combinations
a = zeros(n+1,1);   % The current combination following (k,n)-Gray code
b = ones(n+1,1);    % +1 or -1
c = k*ones(n+1,1);  % The maximum for each digit
j=1;
while (a(n+1)==0)
    % Write current combination in the output
    x(:,j) = xi(a(1:n)+1);     
    j = j + 1;
    
    % Compute the next combination
    i = 1;
    l = a(1)+b(1);
    while (l>=c(i)) || (l<0)
        b(i) = -b(i);
        i = i+1;
        l = a(i)+b(i);
    end
    a(i) = l;
end
end
