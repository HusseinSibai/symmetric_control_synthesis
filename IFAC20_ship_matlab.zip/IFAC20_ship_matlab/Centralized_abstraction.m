%% Create a symbolic automaton of the system restricted to an interval

% [X_low,X_up]: state interval of interest
% sym_x: number of symbols per dimension of the state
% [U_low,U_up]: control interval
% sym_x: number of discrete value per dimension of the control
% [W_low,W_up]: disturbance interval
% time_list: time step for the symbolic automaton
% state_dimensions: state dimensions considered for abstraction
% OA_method: reachability method (3: CTMM, 4: SDMM with sampling)

% Symbolic_reduced: symbolic automaton of the model using translational symmetry
% U_discrete: discretization of the control input set

function [Symbolic_reduced,U_discrete,unsafe_trans] = Centralized_abstraction(X_low,X_up,sym_x,U_low,U_up,sym_u,W_low,W_up,time_list,state_dimensions,OA_method)

%% Initialization
tic
n = length(X_low);
symbol_step = (X_up-X_low)./sym_x;

% % Input set discretization
% angle_discrete = U_low(1):(U_up(1)-U_low(1))/(sym_u(1)-1):U_up(1);
% surge_discrete = U_low(2):(U_up(2)-U_low(2))/(sym_u(2)-1):U_up(2);
% U_discrete = zeros(length(U_low),prod(sym_u));
% for i = 1:sym_u(2)
%     U_discrete(:,sym_u(1)*(i-1)+1:sym_u(1)*i) = [angle_discrete;surge_discrete(i)*ones(1,sym_u(1))];
% end

X_low = X_low';
X_up = X_up';
sym_x = sym_x';
U_low = U_low';
U_up = U_up';
sym_u = sym_u';
W_low = W_low';
W_up = W_up';
symbol_step = symbol_step';


% Input set discretization (if the values of sym_u are all the same)
if range(sym_u)==0
    sym_u = sym_u(1);
    ui_values = 1:sym_u;
    U_discrete = Gray(ui_values,size(U_low,1),sym_u);
    U_discrete = repmat(U_low,1,sym_u^size(U_low,1)) + (U_discrete-1).*repmat((U_up-U_low)/(sym_u-1),1,sym_u^size(U_low,1));
else
    error('Non-homogeneous input discretization cannot be handled yet')
end

%% Variables for the reduced symbolic model (using translational symmetry)

% Reduced symbolic model when using translational symmetry
sym_x_reduced = sym_x.*state_dimensions' + ~state_dimensions';
matrix_dim_reduced = [prod(sym_x_reduced),size(U_discrete,2), 2*n, length(time_list)];
% matrix_dim_reduced = [prod(sym_x_reduced),size(U_discrete,2), 2*n];
Symbolic_reduced = zeros(matrix_dim_reduced);

% Convert symbol indices to subscripts on each dimension
symbol_subscripts = cell(n,1);
[symbol_subscripts{:}] = ind2sub(sym_x_reduced',1:matrix_dim_reduced(1));
symbol_subscripts = cell2mat(symbol_subscripts);

%% Compute the successor of each symbol for the reduced model
% for full_index = 1:matrix_dim_reduced(1)     % Loop on the source symbol
for red_index = 1:matrix_dim_reduced(1)     % Loop on the source symbol
    
    % Interval of the source symbol
    % Hussein: the following two lines changed in June 13th, 2022. No need
    % to take an interval in the dimensions that are reduced using
    % symmetry.
    symbol_low = X_low.*state_dimensions' + symbol_step.*state_dimensions'.*(symbol_subscripts(:,red_index)-1);
    symbol_up = X_low.*state_dimensions' + symbol_step.*state_dimensions'.*symbol_subscripts(:,red_index);

%     Symbolic_reduced = X_low;
%     U_discrete = symbol_step;
%     unsafe_trans = symbol_subscripts(:,red_index);
%     return
    
    temp = zeros(1,matrix_dim_reduced(2),2*n, matrix_dim_reduced(4));
    % temp = zeros(1,matrix_dim_reduced(2),2*n);
    for k = 1:matrix_dim_reduced(2)   % Loop on the control input
        u = U_discrete(:,k);

        % Over-approximation of the reachable set
        if OA_method==3
            % Continuous-time mixed-monotonicity

            
            time_list = time_list(end);
            [J_x_low,J_x_up,J_p_low,J_p_up] = UP_Jacobian_Bounds(0,time_list,symbol_low,symbol_up,[u;W_low],[u;W_up]);
%             [J_x_low,J_x_up,J_p_low,J_p_up] = UP_Jacobian_Bounds(0,time_list,X_low,X_up,[u;W_low],[u;W_up]);      % Global Jacobian bounds actually not needed for the ship example
            [succ_low,succ_up] = OA_3_CT_Mixed_Monotonicity2(0,time_list,symbol_low,symbol_up,[u;W_low],[u;W_up],J_x_low,J_x_up,J_p_low,J_p_up);
        elseif OA_method==3.1
            % Continuous-time mixed-monotonicity but time_list is a
            % sequence of time steps and it returns a full reachable set.
            [J_x_low,J_x_up,J_p_low,J_p_up] = UP_Jacobian_Bounds(0,time_list(end),symbol_low,symbol_up,[u;W_low],[u;W_up]);
%             [J_x_low,J_x_up,J_p_low,J_p_up] = UP_Jacobian_Bounds(0,time_list,X_low,X_up,[u;W_low],[u;W_up]);      % Global Jacobian bounds actually not needed for the ship example
            [succ_low,succ_up] = OA_3_CT_Mixed_Monotonicity2_full_reach(time_list,symbol_low,symbol_up,[u;W_low],[u;W_up],J_x_low,J_x_up,J_p_low,J_p_up);
        elseif OA_method==4
            % Sampled-data mixed-monotonicity with sampling and falsification
            [S_x_low,S_x_up,S_p_low,S_p_up] = Sensitivity_sampling(0,time_list,symbol_low,symbol_up,[u;W_low],[u;W_up],0);
            [S_x_low,S_x_up,S_p_low,S_p_up] = Sensitivity_falsification(0,time_list,symbol_low,symbol_up,[u;W_low],[u;W_up],S_x_low,S_x_up,S_p_low,S_p_up,0);
            [succ_low,succ_up] = OA_4_CT_Sampled_data_MM(0,time_list,symbol_low,symbol_up,[u;W_low],[u;W_up],S_x_low,S_x_up,S_p_low,S_p_up);
        elseif OA_method==5
            % Sampled-data mixed-monotonicity with interval arithetics
            [J_x_low,J_x_up,J_p_low,J_p_up] = UP_Jacobian_Bounds(0,time_list,symbol_low,symbol_up,[u;W_low],[u;W_up]);
            [S_x_low,S_x_up,S_p_low,S_p_up] = Sensitivity_interval_arithmetics(0,time_list,symbol_low,symbol_up,[u;W_low],[u;W_up],J_x_low,J_x_up,J_p_low,J_p_up);
            [succ_low,succ_up] = OA_4_CT_Sampled_data_MM(0,time_list,symbol_low,symbol_up,[u;W_low],[u;W_up],S_x_low,S_x_up,S_p_low,S_p_up);
        else
            error('Wrong reachability method')
        end

        % Convert successor interval into symbols
        if OA_method==3.1
            succ_low
            succ_up
            temp(1,k,:,:) = cat(1, succ_low, succ_up);
        else
            temp(1,k,:) = [succ_low;succ_up];
        end
    end
    Symbolic_reduced(red_index,:,:,:) = temp;
end

% Mark as unsafe the transitions leaving the state space on dimension 3

% if range(sym_x)==0  % if all values of sym_x are the same
%     unsafe_trans = any(Symbolic_reduced(:,:,state_dimensions==1) < 1 | Symbolic_reduced(:,:,[false(n,1);(state_dimensions==1)']) > sym_x(1),3);
% else
%     unsafe_trans = false(matrix_dim_reduced(1),matrix_dim_reduced(2));
%     for i=1:n
%         if state_dimensions(i)
%             unsafe_trans = unsafe_trans | Symbolic_reduced(:,:,i) < 1 | Symbolic_reduced(:,:,n+i) > sym_x(i);
%         end
%     end
% end
unsafe_trans = nan;

fprintf('\nBuilding the reduced symbolic model (using translational symmetry): %f seconds\n',toc)

end

%% Generation of possible values with (k,n)-Gray Code
function x = Gray(xi,n,k)
% From: Guan, Dah-Jyh (1998). "Generalized Gray Codes with Applications". 
% Proc. Natl. Sci. Counc. Repub. Of China (A) 22: 841???848. 
% http://nr.stpi.org.tw/ejournal/ProceedingA/v22n6/841-848.pdf.

x = zeros(n,k^n);   % The matrix with all combinations
a = zeros(n+1,1);   % The current combination following (k,n)-Gray code
b = ones(n+1,1);    % +1 or -1
c = k*ones(n+1,1);  % The maximum for each digit
j=1;
while (a(n+1)==0)
    % Write current combination in the output
    x(:,j) = xi(a(1:n)+1);     
    j = j + 1;
    
    % Compute the next combination
    i = 1;
    l = a(1)+b(1);
    while (l>=c(i)) || (l<0)
        b(i) = -b(i);
        i = i+1;
        l = a(i)+b(i);
    end
    a(i) = l;
end
end