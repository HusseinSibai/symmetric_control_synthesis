%% Test file on the obtained controller
close all
clear
addpath(genpath('./TIRA'))  % Add access to reachability toolbox folder
addpath(genpath('./multipoly'))  % Add access to reachability toolbox folder

% Load save file
load('./Saves/Ship_abstraction17.mat','X_low','X_up','U_low','U_up','W_low','W_up','Target_low','Target_up','Obstacle_low','Obstacle_up','error_6D','sym_x','time_step','Controller','U_discrete','SOS_filename')
load(SOS_filename,'Vval','err','gamma_list','kval','uhat','t')
uhat_SOS = uhat;
t_SOS = t;

%% State and input spaces definitions

% State spaces
X_3D_up = X_up;
X_3D_low = X_low;
X_6D_up = [X_up;U_up];
X_6D_low = [X_low;U_low];

% Input spaces
U_6D_up = [5;5;5.1];
U_6D_low = -U_6D_up;

% Disturbance spaces
W_6D_up = [W_up;0.01;0.01;0.05];
W_6D_low = [W_low;-0.01;-0.01;-0.05];

% Shrunk 3D state space
X_3D_shrunk_up = X_3D_up - error_6D(1:3);
X_3D_shrunk_low = X_3D_low + error_6D(1:3);
step_3D = (X_3D_shrunk_up-X_3D_shrunk_low)./sym_x;

%% Create controlled trajectories

% Select random initial symbol for abstraction in domain of Controller
% s_3D = 0;
% while ~s_3D
%     temp = randi(prod(sym_x));
%     if Controller(temp)
%         s_3D = temp;
%     end
% end
s_3D=122501;     % initialize in bottom left corner
% s_3D =112501;
s_3D = 90001;

% Pick random 3D initial state in this symbol
[s1,s2,s3] = ind2sub(sym_x,s_3D);
x_3D_up = X_3D_shrunk_low + step_3D.*[s1;s2;s3];
x_3D_low = x_3D_up - step_3D;
x_3D = x_3D_low + rand(3,1).*step_3D;

% Take 3D control input associated to current symbol
u_3D = U_discrete(:,Controller(s_3D));
    
% Pick random 6D initial state in error ellipsoid around x_3D/u_3D
% while 1
%     e_rand = error_6D.*(2*rand(6,1)-1);     % Pick random error vector in box
%     % Check if it's in ellipsoid
%     if double(subs(Vval, [err;t_SOS], [e_rand;0])) <= gamma_list(end)
%         break
%     end
% end
% x_6D = [x_3D;u_3D] +e_rand;
x_6D = [x_3D;u_3D];

% Loop to create a multi-step trajectory
i = 0;  % loop index
t_3D = [];
t_6D = [];
x_3D_traj = [];
xu_3D_traj = [];
x_3D_traj_DT = x_3D;
x_6D_traj = [];
while 1
    i = i+1;
    
    % Pick random 6D disturbance
    w_6D = W_6D_low + rand(6,1).*(W_6D_up-W_6D_low);
    % Deduce the corresponding 3D disturbance
    w_3D = w_6D(1:3);
    
    % Trajectory of 3D model over one time_step with constant input u_3D
    [t_temp,x_temp] = ode45(@(t,x) System_description(t,x,[u_3D;w_3D]),[time_step*(i-1) time_step*i],x_3D);
    t_3D = [t_3D;t_temp];
    x_3D_traj = [x_3D_traj;x_temp];
    xu_3D_traj = [xu_3D_traj;x_temp repmat(u_3D',numel(t_temp),1)];
    x_3D = x_temp(end,:)';
    x_3D_traj_DT = [x_3D_traj_DT x_3D];
    
    % Trajectory of 6D model over one time_step with internal feedback
    [t_temp,x_temp] = ode45(@(t,x) System_description_6D_SOS_feedback(t,x,t_temp,x_temp,u_3D,w_6D,kval,err,uhat_SOS,t_SOS,time_step),[time_step*(i-1) time_step*i],x_6D);
    t_6D = [t_6D;t_temp];
    x_6D_traj = [x_6D_traj;x_temp];
    x_6D = x_temp(end,:)';

    % Convert 3D state to symbol
    s_3D = floor(1+(x_3D-X_3D_shrunk_low)./step_3D);
    if any(s_3D==0)
        a=1;
    end
    s_3D = sub2ind(sym_x,s_3D(1),s_3D(2),s_3D(3));
    
    % Stop if we reached target set
    if ~Controller(s_3D)
        break
    end
    
    % Take 3D control input associated to current symbol
    u_3D = U_discrete(:,Controller(s_3D));
end

%% Plotting trajectories

% Comparison of the first 3 states
for i = 1:3
    figure
    hold on
    
    % State space bounds and shrunk safety bounds
    plot(t_3D,repmat(X_6D_low(i),size(t_3D)),'k','LineWidth',2)
    plot(t_3D,repmat(X_6D_up(i),size(t_3D)),'k','LineWidth',2)
    plot(t_3D,repmat(X_3D_shrunk_low(i),size(t_3D)),':k')
    plot(t_3D,repmat(X_3D_shrunk_up(i),size(t_3D)),':k')
    
    % Target set for reachability problem, and shrunk set
    plot(t_3D,repmat(Target_low(i),size(t_3D)),'--b')
    plot(t_3D,repmat(Target_up(i),size(t_3D)),'--b')
    plot(t_3D,repmat(Target_low(i)+error_6D(i),size(t_3D)),'--r')
    plot(t_3D,repmat(Target_up(i)-error_6D(i),size(t_3D)),'--r')
    
    % 6D state trajectories
    plot(t_6D,x_6D_traj(:,i),'b','LineWidth',2)
    
    % 3D state trajectories and error bounds around them
    plot(t_3D,x_3D_traj(:,i),'r','LineWidth',2)
    plot(t_3D,x_3D_traj(:,i)+error_6D(i),'--k')
    plot(t_3D,x_3D_traj(:,i)-error_6D(i),'--k')
    
    title(['State comparison x6D(' num2str(i) ') and x3D(' num2str(i) ')'])
end

% Comparison of the last 3 states with their u_3D references
for i = 4:6
    figure
    hold on

    % State space bounds
    plot(t_3D,repmat(X_6D_low(i),size(t_3D)),'k','LineWidth',2)
    plot(t_3D,repmat(X_6D_up(i),size(t_3D)),'k','LineWidth',2)
    
    % 6D state trajectories
    plot(t_6D,x_6D_traj(:,i),'b','LineWidth',2)
    
    % u_3D reference for comparison, and error bounds around it
    plot(t_3D,xu_3D_traj(:,i),'r','LineWidth',2)
    plot(t_3D,xu_3D_traj(:,i)+error_6D(i),'--k')
    plot(t_3D,xu_3D_traj(:,i)-error_6D(i),'--k')
    
    title(['Comparison of state x6D(' num2str(i) ') with u_3D reference'])
end

% Interpolation of xu_3D to t_6D array for error computation
xu_3D_interp = zeros(length(t_6D),6);
for i=1:6
    xu_3D_interp(:,i) = csapi(t_3D,xu_3D_traj(:,i),t_6D);
end

% Plot errors
for i = 1:6
    figure
    hold on
    
    plot(t_6D,x_6D_traj(:,i)-xu_3D_interp(:,i),'r','LineWidth',2)
    plot(t_6D,zeros(size(t_6D))+error_6D(i),'--k')
    plot(t_6D,zeros(size(t_6D))-error_6D(i),'--k')
    
    if i<=2
        title(['Error e(' num2str(i) '), without rotation'])
    else
        title(['Error e(' num2str(i) ')'])
    end
end

% Controller of the 6D model
u_6D_traj = zeros(numel(t_6D),3);
R = eye(6);
for i = 1:numel(t_6D)
    % Reference for error
    xu_hat = xu_3D_interp(i,:)'; % contains [x_3D;u_3D]
    
    % Rotation matrix
    R(1:2,1:2) = [cos(xu_hat(3)) sin(xu_hat(3));-sin(xu_hat(3)) cos(xu_hat(3))];
    
    % Evaluation of the controller
    vec = [R*(x_6D_traj(i,:)'-xu_hat);xu_hat(4:6);mod(t_6D(i),time_step)];
    tau = double(subs(kval, [err; uhat_SOS; t_SOS],vec));
    
    % Update of the control array
    u_6D_traj(i,:) = tau';
end
% Plot control
for i = 1:3
    figure
    hold on
    
    plot(t_6D,u_6D_traj(:,i),'r','LineWidth',2)
    plot(t_6D,repmat(U_6D_up(i),size(t_6D)),'--k')
    plot(t_6D,repmat(U_6D_low(i),size(t_6D)),'--k')
    
    title(['Internal feedback of the 6D model: u6D(' num2str(i) ')'])
end

%% Plot trajectories in 2D state space
figure
hold on

% Update target: shrink it by the error bounds
Target_shrunk_up = Target_up - error_6D(1:3);
Target_shrunk_low = Target_low + error_6D(1:3);

% Update obstacles by expanding them by the error bounds (with saturations)
for i=1:size(Obstacle_up,2)
    Obstacle_shrunk_up(:,i) = min(Obstacle_up(:,i) + error_6D(1:3),X_3D_shrunk_up);
    Obstacle_shrunk_low(:,i) = max(Obstacle_low(:,i) - error_6D(1:3),X_3D_shrunk_low);
end

% Partition grid
for j=1:sym_x(1)
    plot([X_3D_shrunk_low(1)+j*step_3D(1) X_3D_shrunk_low(1)+j*step_3D(1)], [X_3D_shrunk_low(2) X_3D_shrunk_up(2)],':k')
end
for j=1:sym_x(2)
    plot([X_3D_shrunk_low(1) X_3D_shrunk_up(1)],[X_3D_shrunk_low(2)+j*step_3D(2) X_3D_shrunk_low(2)+j*step_3D(2)],':k')
end

% Convert target interval to the largest set of symbols it fully contains
Target_sym_low = ceil(1+(Target_shrunk_low-X_3D_shrunk_low)./step_3D);
Target_sym_up = floor((Target_shrunk_up-X_3D_shrunk_low)./step_3D);

% Convert obstacle interval to the set of symbols it intersects
for i=1:size(Obstacle_up,2)
    Obstacle_sym_low(:,i) = floor(1+(Obstacle_shrunk_low(:,i)-X_3D_shrunk_low)./step_3D);
    Obstacle_sym_up(:,i) = ceil((Obstacle_shrunk_up(:,i)-X_3D_shrunk_low)./step_3D);
end

% % Fill target and obstacle symbols
% rectangle('Position',[X_3D_shrunk_low(1)+(Target_sym_low(1)-1)*step_3D(1) X_3D_shrunk_low(2)+(Target_sym_low(2)-1)*step_3D(2) (Target_sym_up(1)-Target_sym_low(1)+1)*step_3D(1) (Target_sym_up(2)-Target_sym_low(2)+1)*step_3D(2)],'FaceColor','g')
% for i=1:size(Obstacle_up,2)
%     rectangle('Position',[X_3D_shrunk_low(1)+(Obstacle_sym_low(1,i)-1)*step_3D(1) X_3D_shrunk_low(2)+(Obstacle_sym_low(2,i)-1)*step_3D(2) (Obstacle_sym_up(1,i)-Obstacle_sym_low(1,i)+1)*step_3D(1) (Obstacle_sym_up(2,i)-Obstacle_sym_low(2,i)+1)*step_3D(2)],'FaceColor','k')
% end

% Initial and reduced state space
rectangle('Position',[X_3D_low(1) X_3D_low(2) X_3D_up(1)-X_3D_low(1) X_3D_up(2)-X_3D_low(2)],'Linewidth',2)
rectangle('Position',[X_3D_shrunk_low(1) X_3D_shrunk_low(2) X_3D_shrunk_up(1)-X_3D_shrunk_low(1) X_3D_shrunk_up(2)-X_3D_shrunk_low(2)])

% Initial and reduced target set
rectangle('Position',[Target_low(1) Target_low(2) Target_up(1)-Target_low(1) Target_up(2)-Target_low(2)],'FaceColor',[0.3010 0.7450 0.9330])
rectangle('Position',[Target_shrunk_low(1) Target_shrunk_low(2) Target_shrunk_up(1)-Target_shrunk_low(1) Target_shrunk_up(2)-Target_shrunk_low(2)],'Linewidth',2,'EdgeColor',[0.9290 0.6940 0.1250])

% Initial and reduced obstacle sets
for i=1:size(Obstacle_up,2)
    rectangle('Position',[Obstacle_low(1,i) Obstacle_low(2,i) Obstacle_up(1,i)-Obstacle_low(1,i) Obstacle_up(2,i)-Obstacle_low(2,i)],'FaceColor',[0.5, 0.5, 0.5])
    rectangle('Position',[Obstacle_shrunk_low(1,i) Obstacle_shrunk_low(2,i) Obstacle_shrunk_up(1,i)-Obstacle_shrunk_low(1,i) Obstacle_shrunk_up(2,i)-Obstacle_shrunk_low(2,i)],'Linewidth',2,'EdgeColor',[0.9290 0.6940 0.1250])
end

% Plot 2D trajectories
plot(x_3D_traj(:,1),x_3D_traj(:,2),'r','Linewidth',2)
plot(x_6D_traj(:,1),x_6D_traj(:,2),'b','Linewidth',2)

% Plot arrows showing the orientation of the ship at each time step
for i=1:size(x_3D_traj_DT,2)
    quiver(x_3D_traj_DT(1,i),x_3D_traj_DT(2,i),cos(x_3D_traj_DT(3,i)),sin(x_3D_traj_DT(3,i)),'r')
end

% Plot time-variying error bounds
load('result_Ts3','Ts')
gamma_use = gamma_list(end);
for i = 1:10:length(x_6D_traj)
    e_i = x_6D_traj(i,:)-xu_3D_interp(i,:);
    V12 = subs(subs(Vval,err(3:6),e_i(3:6)'),t,mod(t_6D(i),Ts));
    V12_shift = subs(V12,err(1:2),err(1:2)-xu_3D_interp(i,1:2)');
    pcontour(V12_shift, gamma_use, [0, 10, 0, 6.5],'k',[500, 500]);
    hold on
end





%% TODO
% rotate x1 x2 for error plot ?
% change constant disturbance to time-varying


