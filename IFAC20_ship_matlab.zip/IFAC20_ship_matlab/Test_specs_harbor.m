%% Test of conversion of target/obstacles sets to symbols
close all
clear
addpath(genpath('./TIRA'))  % Add access to reachability toolbox folder
addpath(genpath('./multipoly'))  % Add access to polynomial toolbox folder
% Load error bounds from SOS
load('result_Ts3.mat','e1lbval','e1ubval','e2lbval','e2ubval','e3lbval','e3ubval')

%% Initialization

% State space definition
%   N/E for camera range: 10*6.5m
%   orientation range [-pi,pi] ; psi=0 is pointing North
X_up = [10;6.5;pi];
X_low = [0;0;-pi];
n_x = numel(X_up);

sym_x = 50*ones(n_x,1);

% Target interval for the reachability problem
%   go North towards a West-East docking band (N in [6,10], E in [0,6.5])
%   with the ship facing East (+/-30° around 90° => [pi/3,2*pi/3])
Target_up = [10;6.5;2*pi/3];
Target_low = [7;0;pi/3];

% Obstacles
Obstacle_up = [[2.5;3;pi] [5.5;6.5;pi]];
Obstacle_low = [[2;0;-pi] [5;3.5;-pi]];

%% Shrinking
% Error bounds induced by the model reduction
error_up = [e1ubval;e2ubval;e3ubval];
error_low = [e1lbval;e2lbval;e3lbval];
error_abs = max(abs(error_low),abs(error_up));

% Update target: shrink it by the error bounds
Target_shrunk_up = Target_up - error_abs;
Target_shrunk_low = Target_low + error_abs;

% Update state space: shrink it by the error bounds
X_shrunk_up = X_up - error_abs;
X_shrunk_low = X_low + error_abs;

symbol_step = (X_shrunk_up-X_shrunk_low)./sym_x;

% Update obstacles by expanding them by the error bounds (with saturations)
for i=1:size(Obstacle_up,2)
    Obstacle_shrunk_up(:,i) = min(Obstacle_up(:,i) + error_abs,X_shrunk_up);
    Obstacle_shrunk_low(:,i) = max(Obstacle_low(:,i) - error_abs,X_shrunk_low);
end

%% Plotting
figure
hold on

% Partition grid
for j=1:sym_x(1)
    plot([X_shrunk_low(1)+j*symbol_step(1) X_shrunk_low(1)+j*symbol_step(1)], [X_shrunk_low(2) X_shrunk_up(2)],':k')
end
for j=1:sym_x(2)
    plot([X_shrunk_low(1) X_shrunk_up(1)],[X_shrunk_low(2)+j*symbol_step(2) X_shrunk_low(2)+j*symbol_step(2)],':k')
end

% Convert target interval to the largest set of symbols it fully contains
Target_sym_low = ceil(1+(Target_shrunk_low-X_shrunk_low)./symbol_step);
Target_sym_up = floor((Target_shrunk_up-X_shrunk_low)./symbol_step);

% Convert obstacle interval to the set of symbols it intersects
for i=1:size(Obstacle_up,2)
    Obstacle_sym_low(:,i) = floor(1+(Obstacle_shrunk_low(:,i)-X_shrunk_low)./symbol_step);
    Obstacle_sym_up(:,i) = ceil((Obstacle_shrunk_up(:,i)-X_shrunk_low)./symbol_step);
end

% Fill target and obstacle symbols
rectangle('Position',[X_shrunk_low(1)+(Target_sym_low(1)-1)*symbol_step(1) X_shrunk_low(2)+(Target_sym_low(2)-1)*symbol_step(2) (Target_sym_up(1)-Target_sym_low(1)+1)*symbol_step(1) (Target_sym_up(2)-Target_sym_low(2)+1)*symbol_step(2)],'FaceColor','g')
for i=1:size(Obstacle_up,2)
    rectangle('Position',[X_shrunk_low(1)+(Obstacle_sym_low(1,i)-1)*symbol_step(1) X_shrunk_low(2)+(Obstacle_sym_low(2,i)-1)*symbol_step(2) (Obstacle_sym_up(1,i)-Obstacle_sym_low(1,i)+1)*symbol_step(1) (Obstacle_sym_up(2,i)-Obstacle_sym_low(2,i)+1)*symbol_step(2)],'FaceColor','k')
end

rectangle('Position',[X_low(1) X_low(2) X_up(1)-X_low(1) X_up(2)-X_low(2)],'Linewidth',2)
rectangle('Position',[X_shrunk_low(1) X_shrunk_low(2) X_shrunk_up(1)-X_shrunk_low(1) X_shrunk_up(2)-X_shrunk_low(2)])


rectangle('Position',[Target_low(1) Target_low(2) Target_up(1)-Target_low(1) Target_up(2)-Target_low(2)],'Linewidth',2,'EdgeColor','b')
rectangle('Position',[Target_shrunk_low(1) Target_shrunk_low(2) Target_shrunk_up(1)-Target_shrunk_low(1) Target_shrunk_up(2)-Target_shrunk_low(2)],'EdgeColor','b')

for i=1:size(Obstacle_up,2)
    rectangle('Position',[Obstacle_low(1,i) Obstacle_low(2,i) Obstacle_up(1,i)-Obstacle_low(1,i) Obstacle_up(2,i)-Obstacle_low(2,i)],'Linewidth',2,'EdgeColor','r')
    rectangle('Position',[Obstacle_shrunk_low(1,i) Obstacle_shrunk_low(2,i) Obstacle_shrunk_up(1,i)-Obstacle_shrunk_low(1,i) Obstacle_shrunk_up(2,i)-Obstacle_shrunk_low(2,i)],'EdgeColor','r')
end

