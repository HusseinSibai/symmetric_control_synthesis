% HUSSEIN
% function that transforms a reachset successor from the
% reduced coordinates to the full coordinates.
% This function should be implemented by the user based on the symmetries
% that define the moving frame.
% This is an example implementation for the ship coordinates (after being
% reduced through the continuous abstraction in Meyer et al.) 

function [succ_low_global, succ_up_global] = transform_from_frame(succ_low_red, succ_up_red, curr_low_full, curr_up_full)
    sc_low = -1 * curr_low_full(3); % full_state(3)
    sc_up = -1 * curr_up_full(3);
    translation_vector_low = -1 * curr_low_full(1:2); % full_state(1:2)
    translation_vector_up = -1 * curr_up_full(1:2);
    xs1 = succ_low_red(0);  % x_i
    ys1 = succ_low_red(1);  % y_i
    xd1 = succ_up_red(0);
    yd1 = succ_up_red(1);
    x_n_low = translation_vector_low(0);
    y_n_low = translation_vector_low(1);
    x_n_up = translation_vector_up(0);
    y_n_up = translation_vector_up(1);
    xs2 = (xs1) * math.cos(sc_low) - (ys1) * math.sin(sc_low) + x_n_low; % xs1 + x_n #
    ys2 = (xs1) * math.sin(sc_low) + (ys1) * math.cos(sc_low) + y_n_low; % ys1 + y_n #
    xd2 = (xd1) * math.cos(sc_up) - (yd1) * math.sin(sc_up) + x_n_up; % xd1 + x_n #
    yd2 = (xd1) * math.sin(sc_up) + (yd1_up) * math.cos(sc_up) + y_n_up; % yd1 + y_n #
    succ_low_global = [min(xs2,xd2), min(ys2,yd2), succ_low_red(3) + sc_low]; 
    succ_up_global = [max(xs2,xd2), max(ys2,yd2), succ_up_red(3) + sc_up];
